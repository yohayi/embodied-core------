"""
update_concepts.py

增量更新概念中心（适用于图像和音频向量）
定期扫描 per_image_vectors 和 per_audio_vectors 目录中的新向量，
用 MiniBatchKMeans 的 partial_fit 方法更新聚类模型。
保存更新后的概念中心和模型文件。
"""

import numpy as np
import os
import pickle
from sklearn.cluster import MiniBatchKMeans
import glob
import time

# ========== 配置 ==========
IMAGE_VEC_DIR = r'D:\AI_MEMORY\MODELS\per_image_vectors'
AUDIO_VEC_DIR = r'D:\AI_MEMORY\MODELS\per_audio_vectors'
CONCEPT_DIR = r'D:\AI_MEMORY\CONCEPTS'
IMAGE_CONCEPT_FILE = os.path.join(CONCEPT_DIR, 'image_concept_centers.npy')
AUDIO_CONCEPT_FILE = os.path.join(CONCEPT_DIR, 'audio_concept_centers.npy')
IMAGE_KMEANS_MODEL = os.path.join(CONCEPT_DIR, 'image_kmeans_model.pkl')
AUDIO_KMEANS_MODEL = os.path.join(CONCEPT_DIR, 'audio_kmeans_model.pkl')
N_CLUSTERS = 8000          # 图像概念数量
N_CLUSTERS_AUDIO = 2000    # 音频概念数量
BATCH_SIZE = 10000         # 每次 partial_fit 的样本数
UPDATE_INTERVAL = 3600     # 扫描间隔（秒），可根据需要调整

os.makedirs(CONCEPT_DIR, exist_ok=True)

def load_or_init_kmeans(model_path, n_clusters):
    """加载已有的 KMeans 模型，若不存在则返回 None"""
    if os.path.exists(model_path):
        with open(model_path, 'rb') as f:
            kmeans = pickle.load(f)
        print(f"已加载已有模型: {model_path}")
        return kmeans
    else:
        print(f"未找到模型 {model_path}，将初始化新模型")
        return None

def get_all_vectors(vec_dir):
    """获取目录下所有 .npy 向量文件及其修改时间"""
    vec_files = glob.glob(os.path.join(vec_dir, '*.npy'))
    vectors = []
    file_times = []
    for f in vec_files:
        v = np.load(f)
        if v.ndim == 2:
            v = v[0]
        vectors.append(v)
        file_times.append(os.path.getmtime(f))
    if vectors:
        return np.array(vectors), file_times, vec_files
    else:
        return None, None, None

def update_concepts(vec_dir, model_path, centers_path, n_clusters):
    """增量更新指定模态的概念中心"""
    print(f"扫描 {vec_dir} ...")
    vectors, file_times, vec_files = get_all_vectors(vec_dir)
    if vectors is None:
        print("没有找到向量文件")
        return

    # 加载或初始化 KMeans
    kmeans = load_or_init_kmeans(model_path, n_clusters)
    if kmeans is None:
        # 首次运行：用所有数据初始化
        print(f"首次聚类，使用所有 {len(vectors)} 个向量初始化...")
        kmeans = MiniBatchKMeans(n_clusters=n_clusters,
                                 batch_size=min(BATCH_SIZE, len(vectors)),
                                 random_state=42,
                                 n_init=3,
                                 max_iter=100)
        kmeans.fit(vectors)
        print("初始聚类完成")
    else:
        # 增量更新：需要知道哪些向量是新加入的
        # 这里简单实现：每次都重新 partial_fit 所有向量
        # 更高效的做法是记录已处理的文件，但为简化，直接 partial_fit 所有
        print(f"增量更新，使用 {len(vectors)} 个向量 partial_fit...")
        kmeans.partial_fit(vectors)

    # 保存模型和中心
    with open(model_path, 'wb') as f:
        pickle.dump(kmeans, f)
    np.save(centers_path, kmeans.cluster_centers_)
    print(f"概念中心已保存至 {centers_path}")

def main():
    while True:
        print("\n" + "="*50)
        print("开始增量概念更新")
        # 更新图像概念
        update_concepts(IMAGE_VEC_DIR, IMAGE_KMEANS_MODEL, IMAGE_CONCEPT_FILE, N_CLUSTERS)
        # 更新音频概念
        update_concepts(AUDIO_VEC_DIR, AUDIO_KMEANS_MODEL, AUDIO_CONCEPT_FILE, N_CLUSTERS_AUDIO)
        print(f"本次更新完成，等待 {UPDATE_INTERVAL} 秒后下一次扫描...")
        time.sleep(UPDATE_INTERVAL)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("程序已停止")