#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
reflex_actions.py - 快速反射模块（多世界版）
常驻后台，根据实时传感器数据或系统状态触发硬编码的反射行为，
如避障、低电量返航等。反射行为不经过高层认知，直接输出动作指令。
"""

import os
import time
import json
import threading
from pathlib import Path
import numpy as np

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
REFRESH_INTERVAL = 0.1          # 反射检查间隔（秒）
DISTANCE_THRESHOLD = 30.0        # 距离阈值（厘米），小于此值触发避障
BATTERY_LOW_THRESHOLD = 10.5     # 低电量阈值（伏特）
COLLISION_FORCE_THRESHOLD = 2.0  # 碰撞力阈值（触觉传感器）

class ReflexActions:
    def __init__(self, world_path):
        self.world_path = Path(world_path)
        self.sensor_dir = self.world_path / "RAW" / "sensor"
        self.action_dir = self.world_path / "ACTIONS"
        self.action_dir.mkdir(parents=True, exist_ok=True)

        self.running = True
        self.last_sensor_file = None

    def get_latest_sensor(self):
        """获取最新的传感器数据文件"""
        if not self.sensor_dir.exists():
            return None
        files = sorted(self.sensor_dir.glob("*.json"))
        if not files:
            return None
        latest = files[-1]
        # 避免重复读取同一个文件
        if latest == self.last_sensor_file:
            return None
        self.last_sensor_file = latest
        with open(latest, 'r') as f:
            data = json.load(f)
        return data

    def check_and_act(self, sensor_data):
        """根据传感器数据检查是否需要触发反射，并输出动作"""
        actions = []

        # 1. 避障反射（距离传感器）
        distance = sensor_data.get('environment', {}).get('distance', 1000)
        if distance < DISTANCE_THRESHOLD:
            actions.append({
                'type': 'avoid_obstacle',
                'command': 'stop',
                'reason': f'距离过近: {distance:.1f}cm'
            })
            # 可进一步输出具体电机指令，如向后转等

        # 2. 低电量反射
        battery = sensor_data.get('battery', 12.0)
        if battery < BATTERY_LOW_THRESHOLD:
            actions.append({
                'type': 'low_battery',
                'command': 'return_to_base',
                'reason': f'电量低: {battery:.2f}V'
            })

        # 3. 碰撞反射（触觉）
        touch = sensor_data.get('touch', 0)
        if touch > COLLISION_FORCE_THRESHOLD:
            actions.append({
                'type': 'collision',
                'command': 'back_off',
                'reason': f'碰撞力: {touch:.2f}'
            })

        # 如果有动作，保存到 ACTIONS 目录
        if actions:
            timestamp = sensor_data.get('datetime', time.strftime('%Y%m%d_%H%M%S_%f')[:-3])
            action_file = self.action_dir / f"{timestamp}_reflex.json"
            with open(action_file, 'w') as f:
                json.dump({
                    'timestamp': timestamp,
                    'reflex_actions': actions
                }, f, indent=2)
            print(f"反射触发: {actions}")

    def run(self):
        """主循环"""
        print(f"快速反射模块启动，间隔 {REFRESH_INTERVAL} 秒")
        while self.running:
            sensor = self.get_latest_sensor()
            if sensor:
                self.check_and_act(sensor)
            time.sleep(REFRESH_INTERVAL)

    def stop(self):
        self.running = False

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    reflex = ReflexActions(world_path)

    try:
        reflex.run()
    except KeyboardInterrupt:
        print("\n反射模块停止")
        reflex.stop()

if __name__ == "__main__":
    main()