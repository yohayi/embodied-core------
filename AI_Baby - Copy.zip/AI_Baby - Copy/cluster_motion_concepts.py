#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
cluster_motion_concepts.py - 聚类运动向量，生成运动概念中心
用法：
    python cluster_motion_concepts.py --world world_001
"""

import argparse
import numpy as np
import pickle
from pathlib import Path
from sklearn.cluster import MiniBatchKMeans

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    exit(1)

N_CLUSTERS = 2000  # 运动概念数量（可调）
BATCH_SIZE = 10000

def load_all_motion_vectors(vector_dir):
    """加载目录下所有 .npy 运动向量文件，返回数组 (N, dim)"""
    vector_dir = Path(vector_dir)
    files = list(vector_dir.glob("*.npy"))
    if not files:
        return None
    vecs = []
    for f in files:
        v = np.load(f)
        # 每个文件是 (n_frames, dim) 的数组，我们需要将所有帧的向量展开
        if v.ndim == 2:
            vecs.extend(v)
        else:
            vecs.append(v)
    return np.array(vecs, dtype=np.float32)

def main():
    parser = argparse.ArgumentParser(description="运动概念聚类")
    parser.add_argument('--world', required=True, help='世界ID')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    motion_vec_dir = world_path / "MODELS" / "per_motion_vectors"
    concept_dir = world_path / "CONCEPTS"
    concept_dir.mkdir(parents=True, exist_ok=True)

    if not motion_vec_dir.exists():
        print(f"错误：运动向量目录不存在 {motion_vec_dir}")
        return

    print(f"正在加载运动向量: {motion_vec_dir}")
    X = load_all_motion_vectors(motion_vec_dir)
    if X is None:
        print("没有找到运动向量")
        return

    print(f"加载了 {X.shape[0]} 个运动向量，维度 {X.shape[1]}")
    print(f"开始 MiniBatchKMeans 聚类，K={N_CLUSTERS}...")
    kmeans = MiniBatchKMeans(n_clusters=N_CLUSTERS, batch_size=BATCH_SIZE, random_state=42, n_init=3, max_iter=100)
    kmeans.fit(X)

    # 保存模型和中心
    model_path = concept_dir / "motion_kmeans_model.pkl"
    with open(model_path, 'wb') as f:
        pickle.dump(kmeans, f)

    centers_path = concept_dir / "motion_concept_centers.npy"
    np.save(centers_path, kmeans.cluster_centers_)

    print(f"聚类完成！运动概念中心已保存到 {centers_path}")
    print(f"中心矩阵形状: {kmeans.cluster_centers_.shape}")

if __name__ == "__main__":
    main()