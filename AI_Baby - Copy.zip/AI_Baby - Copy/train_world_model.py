#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train_world_model.py - 世界模型训练（多世界版，CPU 模式）
从当前世界的数据中学习预测下一时刻状态。
输入：t 时刻的联合状态（可包括图像、音频、文本、传感器向量及动作）
输出：t+1 时刻的联合状态（预测）
使用 LSTM 编码器-解码器结构。
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import json
import glob

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
SEQ_LEN = 10                       # 输入序列长度
HIDDEN_DIM = 256                    # LSTM 隐藏层维度
LATENT_DIM = 128                     # 状态向量维度（输出维度）
BATCH_SIZE = 32
EPOCHS = 50
LEARNING_RATE = 0.001
SAVE_MODEL_EVERY = 10

# 需要使用的模态（可组合）
USE_IMAGE = True
USE_AUDIO = True
USE_TEXT = True
USE_SENSOR = True
USE_ACTION = True                    # 是否包含动作向量（若没有动作数据，则置为False并使用零动作）

# 动作维度（如果 USE_ACTION=True 且动作数据可用）
ACTION_DIM = 4                        # 假设4个电机速度

def load_vector_file(vec_path):
    """加载单个向量文件，确保为一维"""
    vec = np.load(vec_path)
    if vec.ndim == 2:
        vec = vec[0]
    return vec

class WorldModelDataset(Dataset):
    """从世界数据中构建时序样本"""
    def __init__(self, world_path, seq_len=SEQ_LEN):
        # 获取各模态向量目录
        img_dir = world_path / "MODELS" / "per_image_vectors"
        aud_dir = world_path / "MODELS" / "per_audio_vectors"
        txt_dir = world_path / "MODELS" / "per_text_vectors"
        sen_dir = world_path / "MODELS" / "per_sensor_vectors"
        state_dir = world_path / "STATE"                 # 系统状态 JSON 目录（可选）

        # 收集所有可用的时间点（取所有模态文件名的并集）
        timestamps = set()
        if USE_IMAGE and img_dir.exists():
            for f in img_dir.glob("*.npy"):
                ts = f.stem  # 假设文件名就是时间戳，如 20250315_143022_001
                timestamps.add(ts)
        if USE_AUDIO and aud_dir.exists():
            for f in aud_dir.glob("*.npy"):
                ts = f.stem
                timestamps.add(ts)
        if USE_TEXT and txt_dir.exists():
            for f in txt_dir.glob("*.npy"):
                ts = f.stem
                timestamps.add(ts)
        if USE_SENSOR and sen_dir.exists():
            for f in sen_dir.glob("*.npy"):
                ts = f.stem
                timestamps.add(ts)
        if state_dir.exists():
            for f in state_dir.glob("*_state.json"):
                ts = f.stem.replace("_state", "")
                timestamps.add(ts)

        # 按时间排序
        self.timestamps = sorted(timestamps)
        if len(self.timestamps) < seq_len + 1:
            raise RuntimeError(f"数据点不足，需要至少 {seq_len+1} 个时间点，只有 {len(self.timestamps)}")

        # 预加载所有向量（假设数据量可放入内存）
        self.data = []
        for ts in self.timestamps:
            vec = []
            # 图像
            if USE_IMAGE and img_dir.exists():
                f = img_dir / f"{ts}.npy"
                if f.exists():
                    v = load_vector_file(f)
                else:
                    v = np.zeros(256)  # 假设图像256维
                vec.append(v)
            # 音频
            if USE_AUDIO and aud_dir.exists():
                f = aud_dir / f"{ts}.npy"
                if f.exists():
                    v = load_vector_file(f)
                else:
                    v = np.zeros(128)
                vec.append(v)
            # 文本
            if USE_TEXT and txt_dir.exists():
                f = txt_dir / f"{ts}.npy"
                if f.exists():
                    v = load_vector_file(f)
                else:
                    v = np.zeros(128)
                vec.append(v)
            # 传感器
            if USE_SENSOR and sen_dir.exists():
                f = sen_dir / f"{ts}.npy"
                if f.exists():
                    v = load_vector_file(f)
                else:
                    v = np.zeros(32)
                vec.append(v)
            # 系统状态（可提取部分数值作为向量）
            if state_dir.exists():
                f = state_dir / f"{ts}_state.json"
                if f.exists():
                    with open(f, 'r') as fp:
                        state = json.load(fp)
                    # 提取数值字段（根据实际数据调整）
                    svec = [
                        state.get('battery', 0),
                        state.get('cpu_percent', 0)/100,
                        state.get('memory_percent', 0)/100,
                        1.0 if state.get('power_plugged', False) else 0.0
                    ]
                    vec.append(np.array(svec, dtype=np.float32))
                else:
                    vec.append(np.zeros(4))
            # 动作（如果有动作记录目录）
            if USE_ACTION:
                action_dir = world_path / "ACTIONS"
                if action_dir.exists():
                    f = action_dir / f"{ts}_action.npy"
                    if f.exists():
                        a = np.load(f)
                        if a.ndim == 2:
                            a = a[0]
                    else:
                        a = np.zeros(ACTION_DIM)
                    vec.append(a)
            # 拼接成联合状态向量
            state_vec = np.concatenate(vec)
            self.data.append(state_vec)

        # 计算联合状态维度
        self.state_dim = self.data[0].shape[0]
        print(f"联合状态维度: {self.state_dim}")

    def __len__(self):
        return len(self.timestamps) - SEQ_LEN

    def __getitem__(self, idx):
        # 输入序列 [idx : idx+SEQ_LEN]
        seq = np.array(self.data[idx : idx+SEQ_LEN])
        # 目标 [idx+SEQ_LEN]（下一时刻）
        target = self.data[idx + SEQ_LEN]
        return torch.tensor(seq, dtype=torch.float32), torch.tensor(target, dtype=torch.float32)

class WorldModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # x: [B, seq_len, input_dim]
        _, (h_n, _) = self.lstm(x)
        # 取最后一个时间步的隐藏状态
        last_h = h_n[-1]  # [B, hidden_dim]
        out = self.fc(last_h)  # [B, output_dim]
        return out

def main():
    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    model_dir = world_path / "MODELS"
    model_dir.mkdir(parents=True, exist_ok=True)

    # 创建数据集
    try:
        dataset = WorldModelDataset(world_path, SEQ_LEN)
    except RuntimeError as e:
        print(f"数据集创建失败: {e}")
        return

    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    input_dim = dataset.state_dim
    output_dim = dataset.state_dim

    model = WorldModel(input_dim, HIDDEN_DIM, output_dim).to(device)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()

    # 尝试加载已有模型（按世界内最新）
    model_files = sorted(model_dir.glob("world_model_epoch_*.pth"))
    if model_files:
        latest = model_files[-1]
        model.load_state_dict(torch.load(latest, map_location='cpu'))
        print(f"已加载模型: {latest}")

    print(f"开始训练世界模型，设备 {device}，样本数 {len(dataset)}")

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0
        for seq, target in dataloader:
            seq = seq.to(device)
            target = target.to(device)
            pred = model(seq)
            loss = criterion(pred, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(seq)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            model_path = model_dir / f"world_model_epoch_{epoch}.pth"
            torch.save(model.state_dict(), model_path)
            print(f"模型已保存: {model_path}")

    print("世界模型训练完成！")

if __name__ == "__main__":
    main()