#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
world_classifier.py - 世界分类器
根据数据样本的特征（如潜在向量）自动判断其最可能属于哪个已有世界，
或建议创建新世界。支持增量更新。
"""

import os
import time
import numpy as np
import pickle
from pathlib import Path
from sklearn.mixture import GaussianMixture
import argparse

# 导入世界管理 API
try:
    from world_manager import WorldManager, load_index
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

class FileLock:
    """简单的文件锁，基于原子创建"""
    def __init__(self, lock_path, timeout=10):
        self.lock_path = Path(lock_path)
        self.timeout = timeout
        self.fd = None

    def acquire(self):
        start = time.time()
        while True:
            try:
                # 尝试以独占创建方式打开文件
                self.fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                return True
            except FileExistsError:
                if time.time() - start > self.timeout:
                    raise TimeoutError(f"无法获取锁 {self.lock_path}，超时 {self.timeout} 秒")
                time.sleep(0.1)
            except Exception as e:
                print(f"锁文件操作异常: {e}")
                return False

    def release(self):
        if self.fd is not None:
            os.close(self.fd)
            self.lock_path.unlink(missing_ok=True)
            self.fd = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

class WorldClassifier:
    def __init__(self, global_dir):
        self.global_dir = Path(global_dir)
        self.global_dir.mkdir(parents=True, exist_ok=True)
        self.model_path = self.global_dir / "world_classifier.pkl"
        self.threshold_path = self.global_dir / "world_thresholds.npy"
        self.profiles_path = self.global_dir / "world_profiles.npz"
        self.lock_path = self.global_dir / ".update.lock"
        self.world_profiles = {}  # 世界ID -> 概念中心均值向量
        self.world_names = {}

    def load_or_build_profiles(self):
        """从各世界的概念中心构建世界特征轮廓（带文件锁）"""
        with FileLock(self.lock_path, timeout=30):
            index = load_index()
            worlds = index.get("worlds", {})
            profiles = {}
            names = {}
            for wid, info in worlds.items():
                world_path = Path(info["path"])
                # 使用图像概念中心作为代表
                concept_path = world_path / "CONCEPTS" / "image_concept_centers.npy"
                if concept_path.exists():
                    centers = np.load(concept_path)
                    profile = np.mean(centers, axis=0)
                    profiles[wid] = profile
                    names[wid] = info["name"]
            self.world_profiles = profiles
            self.world_names = names
            print(f"已加载 {len(profiles)} 个世界的特征轮廓")

            # 保存到全局目录，方便下次快速加载
            if profiles:
                ids = list(profiles.keys())
                vecs = np.array([profiles[wid] for wid in ids])
                np.savez(self.profiles_path, world_ids=ids, vectors=vecs)

    def load_profiles_from_file(self):
        """从保存的文件加载轮廓（如果有）"""
        if self.profiles_path.exists():
            data = np.load(self.profiles_path, allow_pickle=True)
            world_ids = data['world_ids']
            vectors = data['vectors']
            for i, wid in enumerate(world_ids):
                self.world_profiles[wid] = vectors[i]
            print(f"从文件加载了 {len(self.world_profiles)} 个世界的轮廓")
            return True
        return False

    def predict_world(self, sample_vector, threshold=0.8):
        """
        预测样本最匹配的世界
        返回 (world_id, confidence) 或 (None, confidence) 表示需要创建新世界
        """
        if not self.world_profiles:
            if not self.load_profiles_from_file():
                self.load_or_build_profiles()
        best_world = None
        best_sim = -1
        for wid, profile in self.world_profiles.items():
            sim = np.dot(sample_vector, profile) / (np.linalg.norm(sample_vector) * np.linalg.norm(profile) + 1e-8)
            if sim > best_sim:
                best_sim = sim
                best_world = wid
        if best_sim > threshold:
            return best_world, best_sim
        else:
            return None, best_sim

    def train_gmm(self, n_components=None):
        """训练高斯混合模型用于更精细的世界分配（可选）"""
        X = []
        world_ids = []
        for wid, profile in self.world_profiles.items():
            X.append(profile)
            world_ids.append(wid)
        if len(X) < 2:
            print("世界数量不足，无法训练GMM")
            return
        X = np.array(X)
        if n_components is None:
            n_components = len(X)
        gmm = GaussianMixture(n_components=n_components, random_state=42)
        gmm.fit(X)
        with open(self.model_path, 'wb') as f:
            pickle.dump(gmm, f)
        print(f"GMM 已训练，保存至 {self.model_path}")

    def predict_gmm(self, sample_vector):
        """使用 GMM 预测世界归属"""
        if not self.model_path.exists():
            print("GMM 模型不存在，请先训练")
            return None, 0
        with open(self.model_path, 'rb') as f:
            gmm = pickle.load(f)
        probs = gmm.predict_proba(sample_vector.reshape(1, -1))[0]
        best_idx = np.argmax(probs)
        return best_idx, probs[best_idx]

def main():
    parser = argparse.ArgumentParser(description="世界分类器")
    parser.add_argument('--update', action='store_true', help='更新世界轮廓')
    parser.add_argument('--sample', help='样本向量文件路径 (npy)')
    parser.add_argument('--threshold', type=float, default=0.8, help='匹配阈值')
    parser.add_argument('--train_gmm', action='store_true', help='训练GMM')
    args = parser.parse_args()

    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("警告：当前没有激活的世界，将使用全局目录")
        global_dir = Path("D:/AI_MEMORY/global")
    else:
        global_dir = Path("D:/AI_MEMORY/global")

    classifier = WorldClassifier(global_dir)

    if args.update:
        classifier.load_or_build_profiles()
        np.save(classifier.threshold_path, list(classifier.world_profiles.values()))

    if args.sample:
        sample_path = Path(args.sample)
        if not sample_path.exists():
            print(f"错误：样本文件不存在 {sample_path}")
            return
        vec = np.load(sample_path)
        if vec.ndim == 2:
            vec = vec[0]
        world_id, conf = classifier.predict_world(vec, args.threshold)
        if world_id:
            print(f"样本属于世界 {world_id}，置信度 {conf:.4f}")
        else:
            print(f"样本不属于任何已知世界，最高置信度 {conf:.4f}，建议创建新世界")

    if args.train_gmm:
        classifier.load_or_build_profiles()
        classifier.train_gmm()

if __name__ == "__main__":
    main()