#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
pc_receiver_master.py - 电脑端 MQTT 总接收器（多世界版）
接收树莓派发送的传感器数据，根据当前世界保存到对应世界的 RAW/sensor 目录。

使用说明：
    python pc_receiver_master.py --broker <树莓派IP> [--port 1883] [--world world_id] [--topic TOPIC]

如果不指定 --world，则使用当前活动世界。
默认主题为 "raspberrypi/sensor/data"。
"""

import json
import argparse
import logging
from pathlib import Path
from datetime import datetime
import paho.mqtt.client as mqtt

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("pc_receiver.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class MQTTReceiver:
    def __init__(self, broker, port, world_id=None, topic="raspberrypi/sensor/data"):
        self.broker = broker
        self.port = port
        self.topic = topic
        self.world_id = world_id
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

        # 获取世界路径
        self.world_path = self.get_world_path()

    def get_world_path(self):
        wm = WorldManager()
        if self.world_id:
            wm.switch_world(self.world_id)
            current = wm.get_current_world()
            if not current:
                raise ValueError(f"世界 {self.world_id} 不存在")
        else:
            current = wm.get_current_world()
            if not current:
                raise ValueError("没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
        logging.info(f"目标世界: {current['world_id']} - {current['name']}")
        return Path(current["path"])

    def on_connect(self, client, userdata, flags, rc):
        logging.info(f"已连接 MQTT 服务器，返回码: {rc}")
        client.subscribe(self.topic)
        logging.info(f"已订阅主题: {self.topic}")

    def on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            logging.debug(f"收到消息: {payload}")
            self.save_sensor_data(payload)
        except json.JSONDecodeError:
            logging.error(f"无法解析 JSON: {msg.payload}")
        except Exception as e:
            logging.error(f"处理消息时出错: {e}")

    def save_sensor_data(self, data):
        """保存传感器数据到当前世界的 RAW/sensor 目录"""
        # 确保有时间戳
        if 'timestamp' not in data:
            data['timestamp'] = datetime.now().timestamp()
        # 生成文件名
        dt_str = datetime.fromtimestamp(data['timestamp']).strftime('%Y%m%d_%H%M%S_%f')[:-3]
        filename = f"{dt_str}_sensor.json"
        sensor_dir = self.world_path / "RAW" / "sensor"
        sensor_dir.mkdir(parents=True, exist_ok=True)
        filepath = sensor_dir / filename

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logging.info(f"已保存传感器数据: {filename}")
        except Exception as e:
            logging.error(f"保存文件失败: {e}")

    def run(self):
        self.client.connect(self.broker, self.port, 60)
        logging.info(f"启动 MQTT 接收器，服务器 {self.broker}:{self.port}")
        self.client.loop_forever()

def main():
    parser = argparse.ArgumentParser(description="电脑端 MQTT 总接收器（多世界版）")
    parser.add_argument('--broker', required=True, help='MQTT 服务器地址（树莓派IP）')
    parser.add_argument('--port', type=int, default=1883, help='MQTT 端口，默认 1883')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    parser.add_argument('--topic', default='raspberrypi/sensor/data', help='订阅的主题，默认 raspberrypi/sensor/data')
    args = parser.parse_args()

    try:
        receiver = MQTTReceiver(args.broker, args.port, args.world, args.topic)
        receiver.run()
    except KeyboardInterrupt:
        logging.info("用户手动停止接收器")
    except Exception as e:
        logging.error(f"运行出错: {e}")

if __name__ == "__main__":
    main()