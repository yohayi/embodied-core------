import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
from pix2text import Pix2Text

p2t = Pix2Text(device='cpu')  # 先用 CPU 测试，也可以去掉 device 参数自动选择 GPU
img_path = r"E:\你的公式图片.jpg"   # 替换为真实图片路径
result = p2t.recognize(img_path, return_type='latex')
print("识别结果：")
print(result)