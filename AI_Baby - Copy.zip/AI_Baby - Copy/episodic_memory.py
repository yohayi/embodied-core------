#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
episodic_memory.py - 情节记忆模块（多世界版）
将重要事件（高好奇心、高奖励、高预测误差等）压缩存储为情节记忆，
支持后续回忆和反思。使用 FAISS 进行高效相似性检索。
"""

import os
import numpy as np
import json
import pickle
import faiss
from pathlib import Path
from datetime import datetime
import argparse

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

class EpisodicMemory:
    def __init__(self, memory_dir, dim=512):
        """
        初始化情节记忆
        memory_dir: 存储索引和元数据的目录
        dim: 事件向量的维度（应与世界模型联合状态维度一致）
        """
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.dim = dim
        self.index_path = self.memory_dir / "episodic.index"
        self.metadata_path = self.memory_dir / "episodes.pkl"

        # 加载或创建 FAISS 索引
        if self.index_path.exists():
            self.index = faiss.read_index(str(self.index_path))
        else:
            self.index = faiss.IndexFlatL2(dim)  # L2距离索引

        # 加载元数据
        if self.metadata_path.exists():
            with open(self.metadata_path, 'rb') as f:
                self.episodes = pickle.load(f)
        else:
            self.episodes = []  # 每个元素为字典：{vector, timestamp, type, description, ...}

    def add_event(self, vector, metadata):
        """
        添加事件
        vector: 事件向量 (numpy array, shape=(dim,))
        metadata: 字典，包含时间戳、类型、描述等
        """
        # 确保向量为 float32 且形状正确
        vec = np.array(vector, dtype=np.float32).reshape(1, -1)
        self.index.add(vec)
        # 记录元数据
        self.episodes.append(metadata)
        # 保存索引和元数据
        faiss.write_index(self.index, str(self.index_path))
        with open(self.metadata_path, 'wb') as f:
            pickle.dump(self.episodes, f)
        print(f"事件已添加: {metadata.get('type', 'unknown')} @ {metadata.get('timestamp', 'now')}")

    def recall(self, query_vector, k=5):
        """
        根据查询向量回忆最相似的 k 个事件
        返回列表，每个元素为 (距离, 元数据)
        """
        query = np.array(query_vector, dtype=np.float32).reshape(1, -1)
        distances, indices = self.index.search(query, k)
        results = []
        for i, idx in enumerate(indices[0]):
            if idx != -1 and idx < len(self.episodes):
                results.append((distances[0][i], self.episodes[idx]))
        return results

    def get_all_events(self):
        """返回所有事件元数据"""
        return self.episodes

    def clear(self):
        """清空记忆（谨慎使用）"""
        self.index = faiss.IndexFlatL2(self.dim)
        self.episodes = []
        if self.index_path.exists():
            self.index_path.unlink()
        if self.metadata_path.exists():
            self.metadata_path.unlink()
        print("情节记忆已清空")

def main():
    parser = argparse.ArgumentParser(description="情节记忆管理工具")
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    parser.add_argument('--add', nargs=3, metavar=('TYPE', 'DESC', 'VECTOR_FILE'),
                        help='添加事件：类型 描述 向量文件路径（npy）')
    parser.add_argument('--query', metavar='VECTOR_FILE', help='查询向量文件')
    parser.add_argument('--k', type=int, default=5, help='返回结果数量')
    parser.add_argument('--list', action='store_true', help='列出所有事件')
    parser.add_argument('--clear', action='store_true', help='清空记忆')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    memory_dir = world_path / "EPISODIC"
    memory_dir.mkdir(parents=True, exist_ok=True)

    # 假设联合状态维度为 256+128+128+32+... 需根据实际调整，这里简单设为 512
    mem = EpisodicMemory(memory_dir, dim=512)

    if args.add:
        etype, desc, vec_file = args.add
        vec_path = Path(vec_file)
        if not vec_path.exists():
            print(f"错误：向量文件不存在 {vec_path}")
            return
        vector = np.load(vec_path)
        if vector.ndim == 2:
            vector = vector[0]
        metadata = {
            'timestamp': datetime.now().isoformat(),
            'type': etype,
            'description': desc,
            'vector_file': str(vec_path)
        }
        mem.add_event(vector, metadata)

    elif args.query:
        qpath = Path(args.query)
        if not qpath.exists():
            print(f"错误：查询向量文件不存在 {qpath}")
            return
        query_vec = np.load(qpath)
        if query_vec.ndim == 2:
            query_vec = query_vec[0]
        results = mem.recall(query_vec, args.k)
        print(f"找到 {len(results)} 个相似事件:")
        for dist, meta in results:
            print(f"  距离: {dist:.4f} | 类型: {meta['type']} | 时间: {meta['timestamp']} | 描述: {meta['description']}")

    elif args.list:
        events = mem.get_all_events()
        print(f"共有 {len(events)} 个事件:")
        for i, ev in enumerate(events):
            print(f"{i+1}. [{ev['type']}] {ev['timestamp']} - {ev['description']}")

    elif args.clear:
        confirm = input("确定要清空所有情节记忆吗？(y/N): ")
        if confirm.lower() == 'y':
            mem.clear()

    else:
        parser.print_help()

if __name__ == "__main__":
    main()