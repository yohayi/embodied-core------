@echo off
chcp 65001 >nul
title AI Baby 全能启动器

:: 切换到脚本目录
cd /d C:\AI_Baby

:: ========== 数据下载器 ==========
:: 图片下载器（每60秒下载10张，并发8个世界）
echo 正在启动图片下载器...
start "图片下载器" python auto_downloader.py --interval 60 --count 10 --max-workers 8 --modality image

:: 音频下载器（每60秒下载10个音频，并发8个世界）
echo 正在启动音频下载器...
start "音频下载器" python auto_downloader.py --interval 60 --count 10 --max-workers 8 --modality audio

:: 视频下载器（每200秒下载4个视频，并发8个世界）
echo 正在启动视频下载器...
start "视频下载器" python auto_downloader.py --interval 200 --count 4 --max-workers 8 --modality video

:: ========== 传感器数据（二选一，根据硬件情况启用） ==========
:: 选项A：模拟传感器数据（无真实硬件时使用）
echo 正在启动传感器模拟器...
start "传感器模拟器" python simulate_sensors.py --interval 0.1

:: 选项B：真实传感器接收器（若有树莓派等硬件，取消下面注释，并注释掉模拟器）
:: echo 正在启动传感器接收器...
:: start "传感器接收器" python sensor_receiver.py

:: ========== 学习与认知核心 ==========
:: 自动学习守护进程（含教师模型）
echo 正在启动自动学习器（含教师）...
start "自动学习器" python auto_learner_parallel.py --interval 120 --threshold 12 --workers 4 --teacher_interval 300

:: 内驱力更新（好奇心、疲劳等，影响行为）
echo 正在启动内驱力更新...
start "内驱力更新" python internal_drive.py

:: ========== 感知与状态记录 ==========
:: 图片接收器（用于实时图片分类）
echo 正在启动图片接收器...
start "图片接收器" python image_receiver.py

:: 系统状态记录（记录 CPU、内存等，作为内感觉数据）
echo 正在启动系统状态记录...
start "系统状态记录" python record_system_state.py

:: ========== 外部知识导入 ==========
:: 文档自动导入（将源文件夹的多媒体导入所有世界）
echo 正在启动文档自动导入器...
start "文档自动导入器" python auto_doc_importer_per_world.py --interval 3600

echo ========================================
echo 所有核心服务已启动，每个服务都有独立窗口。
echo 关闭对应窗口即可停止相应服务。
echo 如需调整参数，请直接修改本批处理中的命令行参数。
echo ========================================
pause