#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
internal_drive.py - 内部驱动力计算服务（多世界版）
根据系统状态、世界模型预测误差、碰撞检测等动态更新内部驱动力。
驱动力包括：好奇心、疲劳、饥饿、疼痛。
可常驻运行，定期更新并将当前驱动力写入 STATE 目录下的 latest_drive.json。
"""

import os
import time
import json
import argparse
import signal
import sys
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    sys.exit(1)

class InternalDrive:
    def __init__(self, world_path):
        self.world_path = Path(world_path)
        self.state_dir = self.world_path / "STATE"
        self.state_dir.mkdir(parents=True, exist_ok=True)

        # 内部状态初始化
        self.curiosity = 0.5          # 好奇心
        self.fatigue = 0.0             # 疲劳
        self.hunger = 0.0               # 饥饿（与电池关联）
        self.pain = 0.0                  # 疼痛（碰撞等）
        self.last_update = time.time()
        self.running = True

        # 注册信号处理以便优雅退出
        signal.signal(signal.SIGINT, self.stop)
        signal.signal(signal.SIGTERM, self.stop)

    def stop(self, signum=None, frame=None):
        print("正在停止 internal_drive...")
        self.running = False

    def get_latest_state(self):
        """从 STATE 目录获取最新的系统状态 JSON"""
        state_files = sorted(self.state_dir.glob("*_state.json"))
        if not state_files:
            return None
        latest = state_files[-1]
        with open(latest, 'r') as f:
            return json.load(f)

    def get_prediction_error(self):
        """
        模拟获取当前世界模型预测误差（实际应调用世界模型接口）
        这里用模拟值替代，可后续替换为真实接口
        """
        # TODO: 实际调用世界模型计算当前感知与预测的误差
        # 临时实现：返回一个在0.2~0.8之间缓慢变化的模拟值
        t = time.time()
        import math
        error = 0.5 + 0.3 * math.sin(t * 0.1) + 0.1 * (hash(str(t)) % 100) / 100
        return error

    def get_collision_status(self):
        """获取碰撞检测状态（从传感器或快速反射模块）"""
        # TODO: 从硬件或反射模块获取真实碰撞状态
        # 模拟：小概率碰撞
        import random
        return random.random() < 0.01

    def update(self):
        """更新内驱力值"""
        now = time.time()
        dt = now - self.last_update
        self.last_update = now

        # 获取当前系统状态（如果可用）
        state = self.get_latest_state()
        battery_level = 0.5  # 默认值
        if state:
            battery_level = state.get('battery_percent', 50) / 100.0

        # 获取预测误差（0~1）
        pred_error = self.get_prediction_error()

        # 获取碰撞状态
        collision = self.get_collision_status()

        # 好奇心：误差大则好奇心增加，但随时间缓慢衰减
        self.curiosity += 0.1 * (pred_error - 0.5) * dt
        self.curiosity = max(0.0, min(1.0, self.curiosity))

        # 疲劳：随时间线性增加（模拟每10分钟疲劳0.1）
        self.fatigue += dt / 600  # 每600秒（10分钟）增加0.1
        self.fatigue = min(1.0, self.fatigue)

        # 饥饿：电池越低饥饿感越强
        target_hunger = max(0.0, 1.0 - battery_level)
        self.hunger += (target_hunger - self.hunger) * 0.1 * dt
        self.hunger = max(0.0, min(1.0, self.hunger))

        # 疼痛：碰撞后激增，然后缓慢衰减
        if collision:
            self.pain = min(1.0, self.pain + 0.3)
        else:
            self.pain *= 0.99  # 指数衰减

        return {
            'timestamp': now,
            'datetime': datetime.fromtimestamp(now).isoformat(),
            'curiosity': round(self.curiosity, 4),
            'fatigue': round(self.fatigue, 4),
            'hunger': round(self.hunger, 4),
            'pain': round(self.pain, 4)
        }

    def save_drive(self, drive_data):
        """保存当前内驱力到文件"""
        # 保存为最新文件（供其他模块实时查询）
        latest_path = self.state_dir / "latest_drive.json"
        with open(latest_path, 'w') as f:
            json.dump(drive_data, f, indent=2)

        # 同时按时间戳保存历史记录
        ts = datetime.fromtimestamp(drive_data['timestamp']).strftime("%Y%m%d_%H%M%S_%f")[:-3]
        hist_path = self.state_dir / f"{ts}_drive.json"
        with open(hist_path, 'w') as f:
            json.dump(drive_data, f, indent=2)

    def run(self, interval=1.0):
        """主循环，每隔 interval 秒更新一次"""
        print(f"内部驱动力服务启动，更新间隔 {interval} 秒，保存至 {self.state_dir}")
        while self.running:
            drive = self.update()
            self.save_drive(drive)
            print(f"[{drive['datetime']}] 好奇心:{drive['curiosity']:.3f} 疲劳:{drive['fatigue']:.3f} 饥饿:{drive['hunger']:.3f} 疼痛:{drive['pain']:.3f}")
            time.sleep(interval)

def main():
    parser = argparse.ArgumentParser(description="内部驱动力计算服务")
    parser.add_argument('--interval', type=float, default=1.0, help='更新间隔（秒），默认1秒')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    drive = InternalDrive(current["path"])
    try:
        drive.run(interval=args.interval)
    except KeyboardInterrupt:
        print("服务已停止")

if __name__ == "__main__":
    main()