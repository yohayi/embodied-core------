import cv2
import sys
from pathlib import Path

IMG_SIZE = 32

def preprocess_world(world_id):
    raw_dir = Path(f"D:/AI_MEMORY/worlds/{world_id}/RAW/image")
    proc_dir = Path(f"D:/AI_MEMORY/worlds/{world_id}/PROCESSED/image")
    proc_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    # 同时支持 jpg 和 png
    for img_file in list(raw_dir.glob("*.jpg")) + list(raw_dir.glob("*.png")) + list(raw_dir.glob("*.jpeg")):
        img = cv2.imread(str(img_file))
        if img is None:
            print(f"警告：无法读取 {img_file.name}，跳过")
            continue
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
        out_path = proc_dir / img_file.name
        cv2.imwrite(str(out_path), resized)
        count += 1
        print(f"已处理 {img_file.name}")

    print(f"预处理完成，共处理 {count} 张图片到 {proc_dir}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python preprocess_world.py <世界ID>")
        sys.exit(1)
    preprocess_world(sys.argv[1])