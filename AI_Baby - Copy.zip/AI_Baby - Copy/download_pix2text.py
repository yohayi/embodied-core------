import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from pix2text import Pix2Text
p2t = Pix2Text(device='cpu')
print("模型加载成功！")