#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
observation.py - 统一物理数据观测接口（多世界版）
提供从当前世界获取最新传感器数据的统一入口。
支持自动回退到历史文件，并包含数据校验。
"""

import json
import time
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)


class Observation:
    """物理观测接口，从当前世界的传感器数据中读取最新值"""

    def __init__(self, world_id=None):
        """
        初始化观测对象
        :param world_id: 世界ID，若为None则使用当前活动世界
        """
        self.wm = WorldManager()
        if world_id:
            self.wm.switch_world(world_id)
        self.current = self.wm.get_current_world()
        if not self.current:
            raise RuntimeError("没有当前世界，请先切换或指定 world_id")
        self.world_path = Path(self.current["path"])
        self.sensor_dir = self.world_path / "RAW" / "sensor"
        self._data = None
        self._timestamp = 0
        self.update()

    def _read_latest(self):
        """读取最新的传感器数据，优先使用 latest_sensor.json，否则取最新历史文件"""
        if not self.sensor_dir.exists():
            return None
        latest_file = self.sensor_dir / "latest_sensor.json"
        if latest_file.exists():
            try:
                with open(latest_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"警告：读取 {latest_file} 失败: {e}")
        # 回退：扫描所有 *_sensor.json 文件，取最新的
        sensor_files = sorted(self.sensor_dir.glob("*_sensor.json"))
        if not sensor_files:
            return None
        try:
            with open(sensor_files[-1], 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"警告：读取历史文件失败: {e}")
            return None

    def _validate_data(self, data):
        """校验数据合理性，返回布尔值"""
        if data is None:
            return False
        # 检查必要字段
        if 'environment' not in data or 'battery' not in data:
            return False
        # 检查电池电压范围
        battery = data.get('battery', 0)
        if battery < 10.0 or battery > 13.0:
            print(f"警告：电池电压异常 {battery}V")
            return False
        # 检查温度范围
        temp = data.get('environment', {}).get('temperature', 0)
        if temp < -40 or temp > 80:
            print(f"警告：温度异常 {temp}°C")
            return False
        # 检查湿度范围
        hum = data.get('environment', {}).get('humidity', 0)
        if hum < 0 or hum > 100:
            print(f"警告：湿度异常 {hum}%")
            return False
        return True

    def update(self):
        """强制重新读取最新数据"""
        data = self._read_latest()
        if data is None:
            print("错误：无法读取传感器数据")
            self._data = None
            self._timestamp = 0
            return
        if self._validate_data(data):
            self._data = data
            self._timestamp = data.get('timestamp', time.time())
        else:
            print("警告：传感器数据校验失败，保留旧数据")
            # 不更新，保留之前的有效数据

    def get_all(self):
        """返回完整的传感器数据字典（只读副本）"""
        return dict(self._data) if self._data else None

    def get_temperature(self):
        """获取温度（摄氏度）"""
        return self._data.get('environment', {}).get('temperature') if self._data else None

    def get_humidity(self):
        """获取湿度（百分比）"""
        return self._data.get('environment', {}).get('humidity') if self._data else None

    def get_distance(self):
        """获取距离（厘米）"""
        return self._data.get('environment', {}).get('distance') if self._data else None

    def get_pressure(self):
        """获取气压（hPa）"""
        return self._data.get('environment', {}).get('pressure') if self._data else None

    def get_battery(self):
        """获取电池电压（伏特）"""
        return self._data.get('battery') if self._data else None

    def get_imu(self):
        """获取 IMU 数据（ax, ay, az, gx, gy, gz）"""
        return self._data.get('imu', {}) if self._data else None

    def get_touch(self):
        """获取触觉传感器值"""
        return self._data.get('touch') if self._data else None

    def get_timestamp(self):
        """获取数据的时间戳（Unix时间）"""
        return self._timestamp

    def get_datetime(self):
        """获取数据的可读时间字符串"""
        return self._data.get('datetime') if self._data else None


# 便捷函数：直接获取当前世界的观测对象
def get_observation(world_id=None):
    """返回当前世界的 Observation 实例"""
    return Observation(world_id)


# 命令行测试
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="测试物理数据观测接口")
    parser.add_argument('--world', help='世界ID')
    args = parser.parse_args()

    try:
        obs = Observation(args.world)
        print(f"世界: {obs.current['world_id']}")
        print(f"时间戳: {obs.get_timestamp()}")
        print(f"温度: {obs.get_temperature()}°C")
        print(f"湿度: {obs.get_humidity()}%")
        print(f"距离: {obs.get_distance()} cm")
        print(f"电池: {obs.get_battery()}V")
        print(f"IMU: {obs.get_imu()}")
        print(f"触觉: {obs.get_touch()}")
    except Exception as e:
        print(f"错误: {e}")