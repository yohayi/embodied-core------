#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
extract_text_from_pdf.py - 从 PDF 提取文本（多世界版）
支持普通 PDF 和扫描版 PDF（OCR），将提取的文本保存到当前世界的 RAW/text 目录。

使用说明：
    python extract_text_from_pdf.py --input <PDF文件或目录> [--world world_id] [--dpi DPI]
    
如果不指定 --world，则使用当前活动世界。
"""

import os
import argparse
import fitz  # pymupdf
import pytesseract
from PIL import Image
import io
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

def extract_text_from_pdf(pdf_path, use_ocr=False):
    """
    从 PDF 提取文本，如果 use_ocr=True 则对扫描页进行 OCR。
    返回完整文本。
    """
    doc = fitz.open(pdf_path)
    full_text = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        # 尝试提取文本
        text = page.get_text()
        if text.strip() and not use_ocr:
            full_text.append(text)
        else:
            # 使用 OCR
            pix = page.get_pixmap()
            img = Image.open(io.BytesIO(pix.tobytes()))
            ocr_text = pytesseract.image_to_string(img, lang='eng+chi_sim')
            full_text.append(ocr_text)
    return '\n'.join(full_text)

def process_pdf(pdf_path, output_dir, dpi=200, use_ocr=False):
    """处理单个 PDF 文件，将提取的文本保存为 .txt 文件"""
    print(f"正在处理 PDF: {pdf_path}")
    try:
        text = extract_text_from_pdf(pdf_path, use_ocr)
        # 按段落拆分（简单按空行）
        paragraphs = text.split('\n\n')
        base_name = os.path.splitext(os.path.basename(pdf_path))[0]
        for i, para in enumerate(paragraphs):
            if len(para) < 50:  # 忽略过短段落
                continue
            out_file = output_dir / f"{base_name}_para{i}.txt"
            with open(out_file, 'w', encoding='utf-8') as fw:
                fw.write(para)
        print(f"  ✅ 已保存 {len([p for p in paragraphs if len(p)>=50])} 个段落")
    except Exception as e:
        print(f"处理 PDF 失败 {pdf_path}: {e}")

def main():
    parser = argparse.ArgumentParser(description="从 PDF 提取文本（多世界版）")
    parser.add_argument('--input', '-i', required=True, help='输入 PDF 文件或目录')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    parser.add_argument('--dpi', type=int, default=200, help='PDF 转图片的 DPI（用于 OCR，默认 200）')
    parser.add_argument('--ocr', action='store_true', help='强制对所有页面使用 OCR（即使有文本）')
    args = parser.parse_args()

    # 获取目标世界
    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    output_dir = world_path / "RAW" / "text"
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"输出目录: {output_dir}")

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：输入路径不存在 {input_path}")
        return

    # 收集所有 PDF 文件
    pdf_files = []
    if input_path.is_file():
        if input_path.suffix.lower() == '.pdf':
            pdf_files.append(input_path)
        else:
            print("错误：输入文件不是 PDF 格式")
            return
    else:
        pdf_files.extend(input_path.glob("*.pdf"))
        pdf_files.extend(input_path.glob("*.PDF"))

    if not pdf_files:
        print(f"在 {input_path} 中未找到 PDF 文件")
        return

    print(f"找到 {len(pdf_files)} 个 PDF 文件，开始处理...")
    for pdf_path in pdf_files:
        process_pdf(pdf_path, output_dir, args.dpi, args.ocr)

    print("所有 PDF 处理完成！")

if __name__ == '__main__':
    main()