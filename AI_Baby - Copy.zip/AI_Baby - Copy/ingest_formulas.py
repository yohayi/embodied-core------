#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
完整版文档导入工具：
- PDF/图片 → 用 PaddleOCR 定位文本和公式区域
- 公式区域裁剪后交给 pix2tex 转 LaTeX
- 普通文本由 PaddleOCR 识别
- 音频由 Whisper 转文字
"""

import os
import sys
import argparse
from pathlib import Path
import numpy as np
from PIL import Image
from pdf2image import convert_from_path

# 强制 CPU 模式（针对 pix2tex 和 Whisper）
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

# 导入核心库
try:
    from paddleocr import PaddleOCR
    from pix2tex import model as pix2tex_model
    import whisper
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请先安装: pip install paddleocr pix2tex openai-whisper pdf2image pillow")
    sys.exit(1)

# 全局配置
USE_GPU = False      # PaddleOCR 强制 CPU
TMP_DIR = Path("D:/AI_MEMORY/tmp")
TMP_DIR.mkdir(parents=True, exist_ok=True)

# 懒加载实例
_paddle_ocr = None
_pix2tex_model = None
_whisper_model = None

def get_paddle_ocr():
    global _paddle_ocr
    if _paddle_ocr is None:
        print("加载 PaddleOCR (CPU)...")
        _paddle_ocr = PaddleOCR(use_angle_cls=True, lang='ch', use_gpu=USE_GPU)
    return _paddle_ocr

def get_pix2tex():
    global _pix2tex_model
    if _pix2tex_model is None:
        print("加载 pix2tex large 模型（首次运行自动下载，CPU 模式）...")
        # 注意：pix2tex 可能仍会尝试 GPU，但通过环境变量已屏蔽
        _pix2tex_model = pix2tex_model.load_model(model_name="large")
    return _pix2tex_model

def get_whisper():
    global _whisper_model
    if _whisper_model is None:
        print("加载 Whisper (CPU)...")
        _whisper_model = whisper.load_model("medium", device="cpu")
    return _whisper_model

def is_math_region(text):
    """判断一行文本是否包含数学符号"""
    math_symbols = ['∫', '∑', '∏', '√', '∂', '∞', 'α', 'β', 'γ', 'θ', 'λ', 'μ', 'π', 'σ', 'ω',
                    '∈', '∉', '⊂', '⊆', '∪', '∩', '∀', '∃', '→', '⇒', '⇔', '≠', '≈', '≤', '≥',
                    '±', '×', '÷', '·', '\\', '^', '_', '{', '}']
    return any(sym in text for sym in math_symbols)

def ocr_and_extract_formulas(image):
    """
    对单张图片进行 OCR：
    - 普通文本 → 直接记录
    - 疑似公式区域 → 裁剪小图 → pix2tex 识别 → 输出 $$LaTeX$$
    """
    ocr = get_paddle_ocr()
    img_np = np.array(image)
    result = ocr.ocr(img_np, cls=True)
    if not result or not result[0]:
        return ""

    texts = []
    for line in result[0]:
        box, (text, conf) = line
        if is_math_region(text):
            # 裁剪公式区域
            points = np.array(box, dtype=np.int32)
            x_min = max(0, min(points[:, 0]) - 5)
            x_max = min(image.width, max(points[:, 0]) + 5)
            y_min = max(0, min(points[:, 1]) - 5)
            y_max = min(image.height, max(points[:, 1]) + 5)
            if x_max > x_min and y_max > y_min:
                formula_img = image.crop((x_min, y_min, x_max, y_max))
                model = get_pix2tex()
                latex = model(formula_img)
                if latex:
                    texts.append(f"$${latex}$$")
                else:
                    texts.append(text)  # 降级保留原文本
            else:
                texts.append(text)
        else:
            texts.append(text)
    return "\n".join(texts)

def process_pdf(pdf_path):
    """将 PDF 转为图片，逐页处理"""
    print(f"处理 PDF: {pdf_path.name}")
    try:
        images = convert_from_path(pdf_path, dpi=200)
    except Exception as e:
        print(f"PDF 转图片失败: {e}")
        return None
    full_text = []
    for i, img in enumerate(images):
        print(f"  第 {i+1}/{len(images)} 页")
        page_text = ocr_and_extract_formulas(img)
        if page_text:
            full_text.append(f"## 第 {i+1} 页\n\n{page_text}\n")
    return "\n".join(full_text)

def process_image(img_path):
    """处理单张图片"""
    img = Image.open(img_path)
    return ocr_and_extract_formulas(img)

def process_audio(audio_path):
    """处理音频文件"""
    model = get_whisper()
    result = model.transcribe(str(audio_path))
    return result["text"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--world', required=True, help='世界ID')
    parser.add_argument('--input', required=True, help='文件或目录路径')
    args = parser.parse_args()

    from world_manager import WorldManager
    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    text_dir = world_path / "RAW" / "text"
    text_dir.mkdir(parents=True, exist_ok=True)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：路径不存在 {input_path}")
        return

    # 收集所有待处理文件
    files = []
    if input_path.is_file():
        files = [input_path]
    else:
        for ext in ['*.pdf', '*.jpg', '*.jpeg', '*.png', '*.bmp', '*.wav', '*.mp3']:
            files.extend(input_path.rglob(ext))

    print(f"找到 {len(files)} 个文件，开始处理...")
    for f in files:
        suffix = f.suffix.lower()
        try:
            if suffix == '.pdf':
                text = process_pdf(f)
            elif suffix in ('.jpg', '.jpeg', '.png', '.bmp'):
                text = process_image(f)
            elif suffix in ('.wav', '.mp3'):
                text = process_audio(f)
            else:
                continue

            if text and text.strip():
                out_name = f.stem + '.txt'
                out_path = text_dir / out_name
                cnt = 1
                while out_path.exists():
                    out_path = text_dir / f"{f.stem}_{cnt}.txt"
                    cnt += 1
                with open(out_path, 'w', encoding='utf-8') as out:
                    out.write(text)
                print(f"已保存: {out_path}")
            else:
                print(f"未提取到文本: {f.name}")
        except Exception as e:
            print(f"处理 {f.name} 时出错: {e}")

    print("所有文件处理完成！")

if __name__ == "__main__":
    main()