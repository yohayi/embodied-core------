#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train_from_processed.py - 图像自编码器（PyTorch CPU 版）
从指定世界的 PROCESSED/image 读取所有图片，训练自编码器，
保存模型到 MODELS/，向量保存到 MODELS/per_image_vectors/。
支持从全局目录复制预训练模型。
"""

import argparse
import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import shutil

# ========== 配置 ==========
IMG_SIZE = 32
LATENT_DIM = 256
BATCH_SIZE = 64
LEARNING_RATE = 0.001
EPOCHS = 50
SAVE_MODEL_EVERY = 5
GLOBAL_MODEL_DIR = Path(r"D:\AI_MEMORY\MODELS")

class ImageDataset(Dataset):
    def __init__(self, image_dir):
        self.files = list(Path(image_dir).glob("*.jpg")) + list(Path(image_dir).glob("*.png")) + \
                     list(Path(image_dir).glob("*.jpeg")) + list(Path(image_dir).glob("*.bmp"))
        if not self.files:
            raise RuntimeError(f"在 {image_dir} 中没有找到图片文件")
        self.features = []
        for f in self.files:
            img = cv2.imread(str(f))
            if img is None:
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
            normalized = resized.astype(np.float32) / 255.0
            self.features.append(normalized.flatten())

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        return torch.tensor(self.features[idx], dtype=torch.float32)

class ImageAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        recon = self.decoder(latent)
        return recon, latent

def load_latest_model(model, model_dir):
    """加载当前世界的最新模型，如果没有则从全局复制"""
    model_files = sorted(model_dir.glob("image_ae_epoch_*.pth"))
    if model_files:
        latest = model_files[-1]
        model.load_state_dict(torch.load(latest, map_location='cpu'))
        print(f"已加载模型: {latest.name}")
        return True

    # 当前世界没有模型，尝试从全局复制
    global_models = list(GLOBAL_MODEL_DIR.glob("image_ae_epoch_*.pth"))
    if global_models:
        latest_global = max(global_models, key=lambda p: int(p.stem.split('_')[-1]))
        print(f"从全局复制 {latest_global.name}")
        shutil.copy(latest_global, model_dir / latest_global.name)
        model.load_state_dict(torch.load(model_dir / latest_global.name, map_location='cpu'))
        return True

    print("未找到任何模型，随机初始化")
    return False

def main():
    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    parser = argparse.ArgumentParser(description="图像自编码器训练（可指定世界）")
    parser.add_argument('--world', help='世界ID，如 world_001')
    args = parser.parse_args()

    if args.world:
        world_path = Path(f"D:/AI_MEMORY/worlds/{args.world}")
    else:
        CURRENT_WORLD_FILE = Path(r"D:\AI_MEMORY\current_world.txt")
        if not CURRENT_WORLD_FILE.exists():
            raise RuntimeError("未设置当前世界，请指定 --world 或先运行 world_manager.py switch")
        with open(CURRENT_WORLD_FILE, 'r') as f:
            world_id = f.read().strip()
        world_path = Path(f"D:/AI_MEMORY/worlds/{world_id}")

    image_dir = world_path / "PROCESSED" / "image"
    model_dir = world_path / "MODELS"
    vector_dir = model_dir / "per_image_vectors"

    if not image_dir.exists():
        print(f"错误：图片目录不存在 {image_dir}")
        return
    model_dir.mkdir(parents=True, exist_ok=True)
    vector_dir.mkdir(parents=True, exist_ok=True)

    dataset = ImageDataset(image_dir)
    if len(dataset) == 0:
        print("错误：没有有效的图片数据")
        return
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    input_dim = IMG_SIZE * IMG_SIZE
    model = ImageAutoencoder(input_dim, 256, LATENT_DIM).to(device)
    load_latest_model(model, model_dir)

    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()

    print(f"开始训练，设备 {device}，样本数 {len(dataset)}")
    for epoch in range(1, EPOCHS+1):
        model.train()
        total_loss = 0
        for batch in dataloader:
            batch = batch.to(device)
            recon, latent = model(batch)
            loss = criterion(recon, batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(batch)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            torch.save(model.state_dict(), model_dir / f"image_ae_epoch_{epoch}.pth")

    # 保存所有图片向量
    print("正在保存图片向量...")
    model.eval()
    with torch.no_grad():
        for i, f in enumerate(dataset.files):
            x = dataset[i].unsqueeze(0).to(device)
            _, latent = model(x)
            vec_path = vector_dir / (f.stem + ".npy")
            np.save(vec_path, latent.cpu().numpy().flatten())
    print("图片向量保存完成")

if __name__ == "__main__":
    main()