#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
cluster_audio.py - 音频概念聚类（多世界版，支持从全局继承）
读取当前世界的 MODELS/per_audio_vectors 下的所有 .npy 向量文件，
如果存在全局概念中心，则进行增量更新；否则重新训练。
保存模型和中心到当前世界的 CONCEPTS/ 目录。
"""

import numpy as np
import pickle
import shutil
from pathlib import Path
from sklearn.cluster import MiniBatchKMeans

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
N_CLUSTERS = 2000                # 音频概念数量
BATCH_SIZE = 10000
RANDOM_STATE = 42
# 全局音频概念中心路径（如果没有单独文件，可先创建）
GLOBAL_AUDIO_CONCEPTS_PATH = Path(r"D:\AI_MEMORY\CONCEPTS\audio_concept_centers.npy")

def load_all_vectors(vector_dir):
    """加载目录下所有 .npy 向量文件，返回数组 (N, dim)"""
    vector_dir = Path(vector_dir)
    files = list(vector_dir.glob("*.npy"))
    if not files:
        return None
    vecs = []
    for f in files:
        vec = np.load(f)
        if vec.ndim == 2 and vec.shape[0] == 1:
            vec = vec[0]
        vecs.append(vec)
    return np.array(vecs, dtype=np.float32)

def main():
    # 获取当前世界
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    vector_dir = world_path / "MODELS" / "per_audio_vectors"
    concept_dir = world_path / "CONCEPTS"
    concept_dir.mkdir(parents=True, exist_ok=True)

    if not vector_dir.exists():
        print(f"错误：向量目录不存在 {vector_dir}")
        return

    print(f"正在加载音频向量: {vector_dir}")
    X = load_all_vectors(vector_dir)
    if X is None:
        print("没有找到任何向量文件")
        return

    n_samples = X.shape[0]
    print(f"加载了 {n_samples} 个向量，维度 {X.shape[1]}")

    # 处理全局概念中心
    do_train = False
    if GLOBAL_AUDIO_CONCEPTS_PATH.exists():
        global_centers = np.load(GLOBAL_AUDIO_CONCEPTS_PATH)
        if global_centers.shape[0] == N_CLUSTERS and global_centers.shape[1] == X.shape[1]:
            if n_samples < N_CLUSTERS:
                print(f"警告：样本数 {n_samples} 小于聚类数 {N_CLUSTERS}，无法进行增量更新。")
                print("直接复制全局概念中心到当前世界（不更新）。")
                shutil.copy(GLOBAL_AUDIO_CONCEPTS_PATH, concept_dir / "audio_concept_centers.npy")
                print("概念中心已复制，跳过聚类。")
                return
            else:
                print("使用全局概念中心初始化 KMeans，然后进行增量更新")
                kmeans = MiniBatchKMeans(n_clusters=N_CLUSTERS,
                                         init=global_centers,
                                         n_init=1,
                                         max_iter=100,
                                         batch_size=BATCH_SIZE,
                                         random_state=RANDOM_STATE)
                kmeans.partial_fit(X)   # 增量更新
        else:
            print("全局概念中心维度不匹配，将重新训练")
            do_train = True
    else:
        print("未找到全局音频概念中心，将重新训练")
        do_train = True

    # 如果需要重新训练，也要检查样本数
    if do_train:
        if n_samples < N_CLUSTERS:
            print(f"错误：样本数 {n_samples} 小于聚类数 {N_CLUSTERS}，无法训练。")
            print("请先收集更多音频数据，或增加全局概念中心。")
            return
        print(f"开始 MiniBatchKMeans 重新训练，K={N_CLUSTERS}...")
        kmeans = MiniBatchKMeans(n_clusters=N_CLUSTERS,
                                 batch_size=BATCH_SIZE,
                                 random_state=RANDOM_STATE,
                                 n_init=3,
                                 max_iter=100,
                                 verbose=1)
        kmeans.fit(X)

    # 保存模型和中心
    if 'kmeans' in locals():
        model_path = concept_dir / "audio_kmeans_model.pkl"
        with open(model_path, 'wb') as f:
            pickle.dump(kmeans, f)

        centers_path = concept_dir / "audio_concept_centers.npy"
        np.save(centers_path, kmeans.cluster_centers_)
        print(f"聚类完成！概念中心已保存到 {centers_path}")
        print(f"中心矩阵形状: {kmeans.cluster_centers_.shape}")

if __name__ == "__main__":
    main()