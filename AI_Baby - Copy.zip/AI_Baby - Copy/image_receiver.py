import socket
import os
import logging
from datetime import datetime
from pathlib import Path

# 导入世界管理器和分类器
try:
    from world_manager import WorldManager
    from world_classifier import WorldClassifier
except ImportError:
    print("错误：无法导入 WorldManager 或 WorldClassifier，请确保相关脚本在当前目录")
    exit(1)

# ===================== 配置项 =====================
LISTEN_PORT = 8888  # 图像传输端口
BUFFER_SIZE = 4096
SAVE_DIR = r"D:\AI_MEMORY\image"  # 图像独立保存文件夹
BUFFER_SIZE = 4096  # 接收缓冲区大小
LOG_FILE = r"D:\AI_MEMORY\image_receiver.log"  # 日志文件
CLASSIFIER_THRESHOLD = 0.8   # 分类阈值，低于此值则创建新世界
# ==================================================

# 1. 初始化日志（记录所有操作和错误）
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()  # 同时输出到控制台
    ]
)

# 初始化世界管理器和分类器
wm = WorldManager()
classifier = WorldClassifier(Path("D:/AI_MEMORY/global"))

def get_image_vector(image_data):
    """
    从图像数据生成潜在向量
    这里简化：需要调用图像自编码器进行编码。由于接收器是实时接收，最好使用已训练好的自编码器。
    这里我们假设有一个预训练的自编码器可以实时编码。
    为了简化，你可以先使用一个占位函数，返回随机向量（仅用于演示）。
    实际应用中，你需要加载图像自编码器模型，对图像进行编码。
    """
    # TODO: 实现真正的图像编码，使用训练好的自编码器
    # 临时返回一个随机向量（维度需与概念中心一致，这里假设256维）
    return np.random.randn(256).astype(np.float32)

def save_image_with_world_classification(image_data, original_filename):
    """
    根据图像内容自动分类世界并保存
    """
    # 1. 生成图像向量
    vec = get_image_vector(image_data)

    # 2. 用分类器判断世界
    world_id, confidence = classifier.predict_world(vec, CLASSIFIER_THRESHOLD)

    if world_id is None:
        # 置信度低，自动创建新世界
        new_world_name = f"auto_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        logging.info(f"创建新世界: {new_world_name} (置信度 {confidence:.4f} 低于阈值)")
        wm.create_world(name=new_world_name, description="自动创建的世界", source="image_receiver")
        # 获取刚创建的世界ID（假设最后一个）
        # 更可靠的方法是让create_world返回ID，但这里简化，重新获取当前世界
        wm.switch_world(new_world_name)  # 注意：create_world后世界不会自动切换，需要手动切换
        # 重新获取当前世界
        current = wm.get_current_world()
        if not current:
            logging.error("无法切换到新创建的世界")
            return None
        world_id = current["world_id"]
    else:
        # 确保当前世界是匹配到的世界（可选：如果不需切换则可以直接存入目标世界路径）
        # 这里我们切换当前世界，以便后续处理
        wm.switch_world(world_id)

    # 3. 获取当前世界路径
    current = wm.get_current_world()
    if not current:
        logging.error("无法获取当前世界路径")
        return None

    world_path = Path(current["path"])
    image_save_dir = world_path / "RAW" / "image"
    image_save_dir.mkdir(parents=True, exist_ok=True)

    # 4. 保存图片
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    final_path = image_save_dir / f"{timestamp}.jpg"
    try:
        with open(final_path, 'wb') as f:
            f.write(image_data)
        logging.info(f"图片已保存到世界 {world_id}: {final_path}")
        return final_path
    except Exception as e:
        logging.error(f"保存图片失败: {e}")
        return None

def recvall(sock, size):
    data = b''
    while len(data) < size:
        packet = sock.recv(size - len(data))
        if not packet:
            return None
        data += packet
    return data

def main():
    logging.info(f"图像接收器启动，监听端口 {LISTEN_PORT}，分类阈值 {CLASSIFIER_THRESHOLD}")

    # 创建TCP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
        server_socket.bind(('0.0.0.0', LISTEN_PORT))
        server_socket.listen(5)
        logging.info(f"开始监听端口 {LISTEN_PORT}...")

        while True:
            try:
                conn, addr = server_socket.accept()
                logging.info(f"接收到连接：{addr}")
                conn.settimeout(10)

                # 接收文件名长度（4字节）
                name_len_data = conn.recv(4)
                if not name_len_data:
                    logging.warning(f"{addr} 未发送文件名长度")
                    conn.close()
                    continue
                name_len = int.from_bytes(name_len_data, 'big')

                # 接收文件名
                file_name = conn.recv(name_len).decode('utf-8', errors='ignore')

                # 接收文件大小（4字节）
                file_size_data = conn.recv(4)
                if not file_size_data:
                    logging.warning(f"{addr} 未发送文件大小")
                    conn.close()
                    continue
                file_size = int.from_bytes(file_size_data, 'big')
                logging.debug(f"待接收文件：{file_name}，大小：{file_size}字节")

                # 接收文件内容
                img_data = b''
                received_size = 0
                while received_size < file_size:
                    chunk = conn.recv(min(BUFFER_SIZE, file_size - received_size))
                    if not chunk:
                        logging.warning(f"{addr} 数据传输中断，已接收 {received_size}/{file_size}")
                        break
                    img_data += chunk
                    received_size += len(chunk)

                if received_size == file_size:
                    # 根据图像内容分类世界并保存
                    saved_path = save_image_with_world_classification(img_data, file_name)
                    if saved_path:
                        conn.send(b'OK')
                    else:
                        conn.send(b'ER')
                else:
                    logging.error(f"数据不完整，已接收 {received_size}/{file_size}")
                    conn.send(b'ER')

            except socket.timeout:
                logging.warning(f"连接 {addr} 超时")
            except Exception as e:
                logging.error(f"处理连接时出错：{str(e)}")
            finally:
                if 'conn' in locals():
                    conn.close()
                    logging.info(f"已断开与 {addr} 的连接")

    except PermissionError:
        logging.error(f"无权限监听端口 {LISTEN_PORT}（需管理员权限）")
    except OSError as e:
        logging.error(f"端口 {LISTEN_PORT} 已被占用：{str(e)}")
    except KeyboardInterrupt:
        logging.info("用户手动停止程序")
    finally:
        server_socket.close()
        logging.info("图像接收器已关闭")

if __name__ == "__main__":
    main()