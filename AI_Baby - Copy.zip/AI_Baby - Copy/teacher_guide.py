#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
teacher_guide.py - 教师模型指导模块（全局单例）
使用开源 LLM 为当前世界生成文本解释，并保存到该世界的 RAW/text。
支持通过 FORCE_CPU 变量切换 CPU/GPU 模式。
"""

import json
import torch
import time
import argparse
from pathlib import Path
from transformers import AutoTokenizer, AutoModelForCausalLM

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    exit(1)

# ========== 配置 ==========
MODEL_NAME = "D:/AI_MEMORY/models/Qwen2.5-3B-Instruct"
FORCE_CPU = True   # 当前强制使用 CPU（RTX 5070 暂不兼容），设为 False 可切回 GPU

class Teacher:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        if FORCE_CPU:
            self.device = torch.device('cpu')
            self.dtype = torch.float32
            self.device_map = "cpu"
        else:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            self.dtype = torch.float16
            self.device_map = "auto"

        print(f"教师模型使用设备: {self.device} (模式: {'CPU' if FORCE_CPU else 'GPU'})")
        self.tokenizer, self.model = self._load_model()
        self.wm = WorldManager()

    def _load_model(self):
        """加载模型和分词器"""
        print("正在加载模型...")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_NAME,
            device_map=self.device_map,
            trust_remote_code=True,
            dtype=self.dtype
        )
        print("模型加载完成")
        return tokenizer, model

    def _generate_text(self, prompt, max_new_tokens=150):
        """内部方法：根据提示生成文本，供其他方法调用"""
        messages = [{"role": "user", "content": prompt}]
        inputs = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            return_tensors="pt"
        )
        input_ids = inputs['input_ids'].to(self.device)
        attention_mask = inputs.get('attention_mask')
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)

        outputs = self.model.generate(
            input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            temperature=0.7,
            do_sample=True,
            top_p=0.9
        )
        answer = self.tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        return answer.strip()

    def _read_latest_sensor_data(self, sensor_dir):
        """读取最新传感器数据，优先使用 latest_sensor.json，否则取最新历史文件"""
        latest_file = sensor_dir / "latest_sensor.json"
        if latest_file.exists():
            try:
                with open(latest_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"警告：读取 {latest_file} 失败: {e}，回退到扫描历史文件")
        # 回退：扫描所有 *_sensor.json 文件，取最新的
        sensor_files = sorted(sensor_dir.glob("*_sensor.json"))
        if not sensor_files:
            return None
        with open(sensor_files[-1], 'r', encoding='utf-8') as f:
            return json.load(f)

    def _validate_sensor_data(self, data):
        """校验传感器数据合理性，返回 (是否有效, 修正后的数据)"""
        valid = True
        # 检查电池电压
        battery = data.get('battery', 0)
        if battery < 10.0 or battery > 13.0:
            print(f"警告：电池电压异常 {battery}V，可能数据有误")
            valid = False
        # 检查温度
        temp = data.get('environment', {}).get('temperature', 0)
        if temp < -40 or temp > 80:
            print(f"警告：温度异常 {temp}°C，可能数据有误")
            valid = False
        # 检查湿度
        hum = data.get('environment', {}).get('humidity', 0)
        if hum < 0 or hum > 100:
            print(f"警告：湿度异常 {hum}%，可能数据有误")
            valid = False
        return valid, data

    def generate_guide_for_world(self, world_id=None):
        """
        为指定世界生成指导。如果 world_id 为 None，则使用当前活动世界。
        返回生成的文本，如果失败则返回 None。
        """
        # 确定世界
        if world_id:
            self.wm.switch_world(world_id)
            current = self.wm.get_current_world()
            if not current:
                print(f"错误：世界 {world_id} 不存在")
                return None
        else:
            current = self.wm.get_current_world()
            if not current:
                print("错误：没有当前世界")
                return None

        world_path = Path(current["path"])
        sensor_dir = world_path / "RAW" / "sensor"
        if not sensor_dir.exists():
            print(f"警告：传感器目录不存在 {sensor_dir}")
            return None

        # 读取最新传感器数据
        data = self._read_latest_sensor_data(sensor_dir)
        if data is None:
            print(f"警告：在 {sensor_dir} 中没有找到传感器文件")
            return None

        # 校验数据
        valid, data = self._validate_sensor_data(data)
        if not valid:
            print("警告：传感器数据存在异常，仍将尝试生成指导（但可能不准确）")

        # 提取关键字段（兼容不同数据结构）
        env = data.get('environment', {})
        temp = env.get('temperature', '未知')
        hum = env.get('humidity', '未知')
        dist = env.get('distance', '未知')
        battery = data.get('battery', '未知')

        # 构建提示词
        prompt = f"""你是一个AI教师，帮助一个正在学习物理世界的小孩理解传感器数据。
当前传感器读数：
- 温度：{temp}°C
- 湿度：{hum}%
- 距离：{dist} cm
- 电池电压：{battery}V

请用中文给出简短的分析和建议（2-3句话）。"""

        # 调用内部生成方法
        answer = self._generate_text(prompt)
        return answer

    def save_guide(self, world_id=None):
        """生成指导并保存到对应世界的 RAW/text 目录"""
        guide = self.generate_guide_for_world(world_id)
        if not guide:
            return

        # 获取世界路径
        if world_id:
            self.wm.switch_world(world_id)
            current = self.wm.get_current_world()
        else:
            current = self.wm.get_current_world()
        world_path = Path(current["path"])
        text_dir = world_path / "RAW" / "text"
        text_dir.mkdir(parents=True, exist_ok=True)

        timestamp = int(time.time())
        filename = f"teacher_{timestamp}.txt"
        with open(text_dir / filename, 'w', encoding='utf-8') as f:
            f.write(guide)
        print(f"教师指导已保存: {filename}\n{guide}")

def main():
    parser = argparse.ArgumentParser(description="教师模型指导生成")
    parser.add_argument('--world', help='指定世界ID（可选）')
    args = parser.parse_args()
    teacher = Teacher()
    teacher.save_guide(args.world)

if __name__ == "__main__":
    main()