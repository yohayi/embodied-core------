#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
auto_downloader.py - 自动下载图片/音频守护进程（支持多模态）
定期为每个世界（根据config中的keyword）下载新图片/音频到对应目录。
"""

import os
import time
import json
import argparse
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import logging

try:
    from world_manager import load_index
except ImportError:
    print("错误：无法导入 world_manager，请确保 world_manager.py 在当前目录")
    exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("auto_downloader.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# 定义各模态的下载配置
MODALITIES = {
    'image': {
        'script': 'download_images_for_world.py',
        'raw_dir': 'RAW/image',
    },
    'audio': {
        'script': 'download_audio_for_world.py',
        'raw_dir': 'RAW/audio',
    },
    'video': {
        'script': 'download_videos_for_world.py',
        'raw_dir': 'RAW/video',
    },
}

class AutoDownloader:
    def __init__(self, interval=3600, count=10, max_workers=4, modality='all'):
        self.interval = interval
        self.count = count
        self.max_workers = max_workers
        self.modality = modality  # 'all', 'image', 'audio'
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.running = True

    def get_all_worlds_with_keyword(self):
        """返回所有包含 keyword 的世界ID及其keyword"""
        index = load_index()
        worlds = []
        for wid, info in index['worlds'].items():
            config_path = Path(info['path']) / 'config.json'
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                keyword = config.get('keyword')
                if keyword:
                    worlds.append({'id': wid, 'keyword': keyword})
        return worlds

    def download_for_world(self, world_id, keyword, modality_config):
        """为单个世界下载指定模态的数据"""
        logging.info(f"为世界 {world_id} 下载 {modality_config['raw_dir']}，关键词：{keyword}，数量：{self.count}")
        try:
            subprocess.run([
                "python", modality_config['script'],
                "--world", world_id,
                "--keyword", keyword,
                "--count", str(self.count)
            ], check=True)
            logging.info(f"世界 {world_id} 的 {modality_config['raw_dir']} 下载完成")
        except subprocess.CalledProcessError as e:
            logging.error(f"世界 {world_id} 的 {modality_config['raw_dir']} 下载失败: {e}")

    def scan_and_download(self):
        """扫描所有世界，为每个世界提交下载任务（多模态）"""
        worlds = self.get_all_worlds_with_keyword()
        if not worlds:
            logging.info("没有找到配置了关键词的世界，跳过本次下载")
            return

        # 确定要下载的模态
        if self.modality == 'all':
            modalities_to_run = MODALITIES.items()
        elif self.modality in MODALITIES:
            modalities_to_run = [(self.modality, MODALITIES[self.modality])]
        else:
            logging.error(f"无效的模态: {self.modality}，支持: all, image, audio")
            return

        futures = []
        for world in worlds:
            for mod_name, mod_config in modalities_to_run:
                future = self.executor.submit(self.download_for_world, world['id'], world['keyword'], mod_config)
                futures.append(future)

        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                logging.error(f"下载任务异常: {e}")

    def run(self):
        logging.info(f"自动下载守护进程启动，间隔 {self.interval} 秒，每次下载 {self.count} 张，并发 {self.max_workers}，模态：{self.modality}")
        while self.running:
            try:
                self.scan_and_download()
            except Exception as e:
                logging.error(f"扫描过程中发生异常: {e}")
            time.sleep(self.interval)

    def stop(self):
        self.running = False
        self.executor.shutdown(wait=True)

def main():
    parser = argparse.ArgumentParser(description="自动下载图片/音频守护进程")
    parser.add_argument('--interval', type=int, default=3600, help='扫描间隔（秒）')
    parser.add_argument('--count', type=int, default=10, help='每次每个世界下载数量')
    parser.add_argument('--max-workers', type=int, default=4, help='并发下载线程数')
    parser.add_argument('--modality', choices=['all', 'image', 'audio', 'video'], default='all', help='下载模态')
    args = parser.parse_args()

    downloader = AutoDownloader(interval=args.interval, count=args.count, max_workers=args.max_workers, modality=args.modality)
    try:
        downloader.run()
    except KeyboardInterrupt:
        logging.info("用户手动停止下载守护进程")
        downloader.stop()

if __name__ == "__main__":
    main()