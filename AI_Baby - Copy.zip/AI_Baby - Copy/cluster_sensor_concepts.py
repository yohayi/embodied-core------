#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
cluster_sensor_concepts.py - 传感器概念聚类（多世界版）
读取当前世界的 MODELS/per_sensor_vectors 下的所有 .npy 向量文件，
使用 MiniBatchKMeans 聚类，生成传感器概念中心，保存到 CONCEPTS/ 目录。
"""

import os
import numpy as np
import pickle
from pathlib import Path
from sklearn.cluster import MiniBatchKMeans

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
N_CLUSTERS = 500            # 传感器概念数量（可根据数据量调整）
BATCH_SIZE = 1000            # MiniBatch 批大小
RANDOM_STATE = 42

def load_all_vectors(vector_dir):
    """加载目录下所有 .npy 向量文件，返回数组 (N, dim)"""
    vector_dir = Path(vector_dir)
    files = list(vector_dir.glob("*.npy"))
    if not files:
        print(f"错误：在 {vector_dir} 中没有找到 .npy 向量文件")
        return None
    vecs = []
    for f in files:
        vec = np.load(f)
        if vec.ndim == 2 and vec.shape[0] == 1:
            vec = vec[0]
        vecs.append(vec)
    return np.array(vecs, dtype=np.float32)

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    vector_dir = world_path / "MODELS" / "per_sensor_vectors"
    concept_dir = world_path / "CONCEPTS"
    concept_dir.mkdir(parents=True, exist_ok=True)

    if not vector_dir.exists():
        print(f"错误：向量目录不存在 {vector_dir}")
        return

    print(f"正在加载传感器向量: {vector_dir}")
    X = load_all_vectors(vector_dir)
    if X is None:
        return

    print(f"加载了 {X.shape[0]} 个向量，维度 {X.shape[1]}")

    print(f"开始 MiniBatchKMeans 聚类，K={N_CLUSTERS}...")
    kmeans = MiniBatchKMeans(n_clusters=N_CLUSTERS,
                             batch_size=BATCH_SIZE,
                             random_state=RANDOM_STATE,
                             n_init=3,
                             max_iter=100,
                             verbose=1)
    kmeans.fit(X)

    # 保存模型和中心
    model_path = concept_dir / "sensor_kmeans_model.pkl"
    with open(model_path, 'wb') as f:
        pickle.dump(kmeans, f)

    centers_path = concept_dir / "sensor_concept_centers.npy"
    np.save(centers_path, kmeans.cluster_centers_)

    print(f"聚类完成！概念中心已保存到 {centers_path}")
    print(f"中心矩阵形状: {kmeans.cluster_centers_.shape}")

if __name__ == "__main__":
    main()