#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
align_av.py - 图像-音频对比对齐训练（多世界版）
从当前世界的 SYNC_DATA 读取同步图像和音频片段，训练投影网络，
将映射后的向量和模型保存到当前世界的 ALIGNED 目录。
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import cv2
import librosa
import glob
import re
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
COMMON_DIM = 128                     # 公共空间维度
BATCH_SIZE = 32                       # 批次大小
EPOCHS = 50
LEARNING_RATE = 0.001
TEMPERATURE = 0.1                     # InfoNCE 温度参数
SAVE_MODEL_EVERY = 10                  # 每多少轮保存模型
IMG_SIZE = 32                          # 图像预处理尺寸（与自编码器一致）
SAMPLE_RATE = 16000                     # 音频采样率
N_MELS = 128                            # 梅尔频带数
TIME_STEPS = 64                         # 音频时间步数

class SyncAVDataset(Dataset):
    """从当前世界的 SYNC_DATA 目录读取同步数据，每个样本是一对 (image_tensor, audio_tensor)"""
    def __init__(self, sync_dir):
        self.pairs = []  # 每个元素是 (img_path, audio_path)
        if not sync_dir.exists():
            print(f"错误：同步数据目录不存在 {sync_dir}")
            return

        # 遍历 sync_dir 下的每个子文件夹
        subdirs = [d for d in sync_dir.iterdir() if d.is_dir()]
        for sub in subdirs:
            # 获取所有图像文件（假设为 jpg/png）
            img_files = sorted(sub.glob("*.jpg")) + sorted(sub.glob("*.png"))
            # 获取所有音频文件（假设为 wav）
            audio_files = sorted(sub.glob("*.wav"))
            # 按文件名中的数字索引配对
            def extract_number(fname):
                match = re.search(r'(\d+)', fname.name)
                return int(match.group(1)) if match else -1
            img_dict = {extract_number(f): f for f in img_files}
            aud_dict = {extract_number(f): f for f in audio_files}
            common_keys = set(img_dict.keys()) & set(aud_dict.keys())
            for k in sorted(common_keys):
                self.pairs.append((img_dict[k], aud_dict[k]))

        print(f"加载了 {len(self.pairs)} 对同步数据")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img_path, aud_path = self.pairs[idx]

        # 加载图像并预处理
        img = cv2.imread(str(img_path))
        if img is None:
            img_tensor = torch.zeros(IMG_SIZE * IMG_SIZE)
        else:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
            normalized = resized.astype(np.float32) / 255.0
            img_tensor = torch.tensor(normalized.flatten(), dtype=torch.float32)

        # 加载音频并预处理
        try:
            y, sr = librosa.load(str(aud_path), sr=SAMPLE_RATE)
            mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=N_MELS)
            log_mel = librosa.power_to_db(mel, ref=np.max)
            if log_mel.shape[1] < TIME_STEPS:
                pad_width = TIME_STEPS - log_mel.shape[1]
                log_mel = np.pad(log_mel, ((0, 0), (0, pad_width)), mode='constant')
            else:
                log_mel = log_mel[:, :TIME_STEPS]
            log_mel = (log_mel - log_mel.min()) / (log_mel.max() - log_mel.min() + 1e-8)
            resized = cv2.resize(log_mel, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_LINEAR)
            aud_tensor = torch.tensor(resized.flatten(), dtype=torch.float32)
        except Exception as e:
            print(f"音频加载失败 {aud_path}: {e}")
            aud_tensor = torch.zeros(IMG_SIZE * IMG_SIZE)

        return img_tensor, aud_tensor

class ImageProjector(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.fc = nn.Linear(input_dim, output_dim)
    def forward(self, x):
        return self.fc(x)

class AudioProjector(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.fc = nn.Linear(input_dim, output_dim)
    def forward(self, x):
        return self.fc(x)

def main():
    # 获取当前世界
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    sync_dir = world_path / "SYNC_DATA"
    if not sync_dir.exists():
        print(f"错误：同步数据目录不存在 {sync_dir}")
        print("请先运行 extract_video_pairs.py 将视频拆解到该目录，或手动放置同步数据。")
        return

    img_vec_dir = world_path / "MODELS" / "per_image_vectors"
    aud_vec_dir = world_path / "MODELS" / "per_audio_vectors"
    aligned_dir = world_path / "ALIGNED"
    aligned_dir.mkdir(parents=True, exist_ok=True)

    # 检查向量目录是否存在（仅用于最后的映射，训练时不直接使用）
    if not img_vec_dir.exists():
        print(f"警告：图像向量目录不存在 {img_vec_dir}，将无法映射图像向量。")
    if not aud_vec_dir.exists():
        print(f"警告：音频向量目录不存在 {aud_vec_dir}，将无法映射音频向量。")

    # 创建数据集
    dataset = SyncAVDataset(sync_dir)
    if len(dataset) == 0:
        print("错误：没有找到有效的同步数据。")
        return

    # 初始化投影网络
    input_dim = IMG_SIZE * IMG_SIZE
    img_proj = ImageProjector(input_dim, COMMON_DIM)
    aud_proj = AudioProjector(input_dim, COMMON_DIM)

    # 强制使用 CPU
    device = torch.device('cpu')
    img_proj.to(device)
    aud_proj.to(device)

    optimizer = optim.Adam(list(img_proj.parameters()) + list(aud_proj.parameters()), lr=LEARNING_RATE)
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    print(f"开始训练，公共维度 {COMMON_DIM}，设备 {device}，配对数量 {len(dataset)}")

    for epoch in range(1, EPOCHS + 1):
        total_loss = 0.0
        for img_batch, aud_batch in dataloader:
            img_batch = img_batch.to(device)
            aud_batch = aud_batch.to(device)

            img_emb = img_proj(img_batch)
            aud_emb = aud_proj(aud_batch)

            img_emb = nn.functional.normalize(img_emb, dim=1)
            aud_emb = nn.functional.normalize(aud_emb, dim=1)

            logits = img_emb @ aud_emb.T / TEMPERATURE
            labels = torch.arange(len(img_batch), device=device)

            loss_i2a = nn.functional.cross_entropy(logits, labels)
            loss_a2i = nn.functional.cross_entropy(logits.T, labels)
            loss = (loss_i2a + loss_a2i) / 2

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(img_batch)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d}, 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            torch.save(img_proj.state_dict(), aligned_dir / f"img_proj_epoch{epoch}.pth")
            torch.save(aud_proj.state_dict(), aligned_dir / f"aud_proj_epoch{epoch}.pth")
            print(f"模型已保存至 {aligned_dir}")

    print("训练完成！")

    # 映射所有图像和音频向量并保存
    print("正在映射所有向量...")
    def map_and_save(proj, vec_dir, out_name):
        if not vec_dir.exists():
            print(f"跳过 {out_name}：向量目录不存在")
            return
        files = list(vec_dir.glob("*.npy"))
        if not files:
            return
        vecs = []
        fnames = []
        for f in files:
            v = np.load(f)
            if v.ndim == 2:
                v = v[0]
            vecs.append(v)
            fnames.append(f.name)
        X = torch.tensor(np.array(vecs), dtype=torch.float32).to(device)
        with torch.no_grad():
            mapped = proj(X).cpu().numpy()
        out_dir = aligned_dir / out_name
        out_dir.mkdir(exist_ok=True)
        for fn, mv in zip(fnames, mapped):
            np.save(out_dir / fn, mv)
        print(f"  已映射 {len(fnames)} 个向量到 {out_dir}")

    map_and_save(img_proj, img_vec_dir, 'mapped_image_vectors')
    map_and_save(aud_proj, aud_vec_dir, 'mapped_audio_vectors')

    print("图像-音频对齐完成！")

if __name__ == "__main__":
    main()