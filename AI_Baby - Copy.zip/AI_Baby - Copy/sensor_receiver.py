#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
sensor_receiver.py - 传感器数据接收器（多世界版）
监听端口，接收树莓派发送的传感器数据（JSON格式），
按时间戳保存到当前世界的 RAW/sensor 目录，同时更新 latest_sensor.json。
"""

import socket
import json
import os
from pathlib import Path
import threading
import time

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
HOST = '0.0.0.0'
PORT = 8889
BUFFER_SIZE = 4096

def recvall(sock, size):
    """接收指定字节数"""
    data = b''
    while len(data) < size:
        packet = sock.recv(size - len(data))
        if not packet:
            return None
        data += packet
    return data

def handle_client(conn, addr, sensor_dir):
    """处理单个客户端连接"""
    print(f"传感器客户端 {addr} 已连接")
    try:
        while True:
            # 先接收4字节长度
            len_data = recvall(conn, 4)
            if not len_data:
                break
            msg_len = int.from_bytes(len_data, 'big')
            # 接收消息内容
            msg_data = recvall(conn, msg_len)
            if not msg_data:
                break
            # 解析JSON
            try:
                data = json.loads(msg_data.decode('utf-8'))
                # 确保有时间戳
                if 'timestamp' not in data:
                    print("警告：收到数据缺少 timestamp 字段，使用当前时间")
                    data['timestamp'] = time.time()
                # 生成文件名
                if 'datetime' in data:
                    filename = f"{data['datetime']}_sensor.json"
                else:
                    # 从时间戳生成可读格式
                    from datetime import datetime
                    dt_str = datetime.fromtimestamp(data['timestamp']).strftime('%Y%m%d_%H%M%S_%f')[:-3]
                    filename = f"{dt_str}_sensor.json"
                filepath = sensor_dir / filename
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                print(f"已保存传感器数据: {filename}")

                # 更新最新状态文件
                latest_path = sensor_dir / "latest_sensor.json"
                with open(latest_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)

                # 发送确认
                conn.send(b'OK')
            except Exception as e:
                print(f"处理数据时出错: {e}")
                conn.send(b'ERR')
    except Exception as e:
        print(f"连接异常: {e}")
    finally:
        conn.close()

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    sensor_dir = world_path / "RAW" / "sensor"
    sensor_dir.mkdir(parents=True, exist_ok=True)

    # 创建TCP服务器
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"传感器接收器启动，监听 {HOST}:{PORT}")
    print(f"数据将保存到: {sensor_dir}")

    try:
        while True:
            conn, addr = server.accept()
            # 为每个客户端开新线程处理
            thread = threading.Thread(target=handle_client, args=(conn, addr, sensor_dir))
            thread.daemon = True
            thread.start()
    except KeyboardInterrupt:
        print("接收器停止")
    finally:
        server.close()

if __name__ == '__main__':
    main()