#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
extract_video_features.py - 从视频提取帧向量和运动向量（CPU版）
使用图像自编码器提取帧特征，计算帧差分作为运动特征，
保存到世界的 MODELS/per_video_vectors 和 MODELS/per_motion_vectors。
用法：
    python extract_video_features.py --world world_001 [--video_dir RAW/video]
"""

import argparse
import numpy as np
import cv2
import torch
import torch.nn as nn
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    exit(1)

# 导入图像自编码器模型定义（从 train_from_processed.py 复制）
class ImageAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        recon = self.decoder(latent)
        return recon, latent

def load_image_ae(world_path, device):
    """加载世界最新的图像自编码器模型（PyTorch）"""
    model_dir = world_path / "MODELS"
    model_files = list(model_dir.glob("image_ae_epoch_*.pth"))
    if not model_files:
        # 回退到全局模型
        global_model_dir = Path(r"D:\AI_MEMORY\MODELS")
        model_files = list(global_model_dir.glob("image_ae_epoch_*.pth"))
        if not model_files:
            raise RuntimeError("未找到图像自编码器模型")
    latest = max(model_files, key=lambda p: int(p.stem.split('_')[-1]))
    model = ImageAutoencoder(32*32, 256, 256).to(device)
    model.load_state_dict(torch.load(latest, map_location='cpu'))
    model.eval()
    print(f"已加载图像自编码器模型: {latest}")
    return model

def compute_motion(prev_frame, curr_frame):
    """计算两帧之间的运动向量（简单帧差分）"""
    diff = cv2.absdiff(prev_frame, curr_frame)
    diff = diff.astype(np.float32) / 255.0   # 归一化到 [0,1]
    return diff

def extract_video_features(video_path, ae, device):
    """从单个视频提取帧向量和运动向量"""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频 {video_path}")

    frame_vectors = []
    motion_vectors = []
    prev_frame = None

    with torch.no_grad():
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            resized = cv2.resize(gray, (32, 32))
            normalized = resized.astype(np.float32) / 255.0
            flat = normalized.flatten()
            # 使用 CPU 编码
            x = torch.tensor(flat, dtype=torch.float32).unsqueeze(0).to(device)
            _, latent = ae(x)
            frame_vec = latent.cpu().numpy().flatten()
            frame_vectors.append(frame_vec)

            if prev_frame is not None:
                motion = compute_motion(prev_frame, resized)
                motion_vec = motion.flatten()
                motion_vectors.append(motion_vec)
            else:
                # 第一帧没有运动，用零向量
                motion_vectors.append(np.zeros(32 * 32))

            prev_frame = resized

    cap.release()
    return np.array(frame_vectors), np.array(motion_vectors)

def main():
    parser = argparse.ArgumentParser(description="从视频提取特征（CPU版）")
    parser.add_argument('--world', required=True, help='世界ID')
    parser.add_argument('--video_dir', default='RAW/video', help='视频目录（相对于世界）')
    args = parser.parse_args()

    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    video_dir = world_path / args.video_dir
    if not video_dir.exists():
        print(f"视频目录不存在 {video_dir}")
        return

    # 加载图像自编码器
    ae = load_image_ae(world_path, device)

    # 收集所有视频文件
    video_files = list(video_dir.glob("*.mp4")) + list(video_dir.glob("*.mov"))
    for vfile in video_files:
        print(f"处理 {vfile.name}...")
        frame_vecs, motion_vecs = extract_video_features(vfile, ae, device)

        # 保存帧向量
        frame_vec_dir = world_path / "MODELS" / "per_video_vectors"
        frame_vec_dir.mkdir(parents=True, exist_ok=True)
        frame_out = frame_vec_dir / (vfile.stem + ".npy")
        np.save(frame_out, frame_vecs)

        # 保存运动向量
        motion_vec_dir = world_path / "MODELS" / "per_motion_vectors"
        motion_vec_dir.mkdir(parents=True, exist_ok=True)
        motion_out = motion_vec_dir / (vfile.stem + ".npy")
        np.save(motion_out, motion_vecs)

        print(f"  帧向量: {frame_vecs.shape}，运动向量: {motion_vecs.shape}")

if __name__ == "__main__":
    main()