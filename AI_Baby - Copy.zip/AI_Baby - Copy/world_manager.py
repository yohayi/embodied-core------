#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
world_manager.py - 多世界管理脚本

功能：
- 创建新世界（自动分配ID、创建目录结构、生成config.json）
- 列出所有世界
- 切换当前活动世界
- 显示当前世界信息
- 删除世界（可选）
- 自动化创建世界（下载图片、预处理、训练、聚类、更新分类器）

使用方式：
    python world_manager.py create --name "世界名称" --desc "描述" [--source "数据源"] [--auto] [--keyword KEYWORD] [--count N]
    python world_manager.py list
    python world_manager.py switch <世界ID>
    python world_manager.py show
    python world_manager.py delete <世界ID>   # 谨慎使用
"""

import os
import json
import shutil
import argparse
import datetime
import subprocess
from pathlib import Path

# ========== 全局配置 ==========
BASE_DIR = Path(r"D:\AI_MEMORY")
WORLDS_DIR = BASE_DIR / "worlds"
INDEX_FILE = BASE_DIR / "world_index.json"
CURRENT_WORLD_FILE = BASE_DIR / "current_world.txt"

# 世界目录结构模板（相对于世界根目录）
WORLD_SUBDIRS = [
    "RAW/image",
    "RAW/audio",
    "RAW/sensor",
    "RAW/text",
    "PROCESSED/image",
    "PROCESSED/audio",
    "PROCESSED/sensor",
    "PROCESSED/text",
    "MODELS/per_image_vectors",
    "MODELS/per_audio_vectors",
    "MODELS/per_sensor_vectors",
    "MODELS/per_text_vectors",
    "CONCEPTS",
    "ALIGNED",
    "STATE",
]

def init_index():
    if not INDEX_FILE.exists():
        data = {"current_world": None, "worlds": {}}
        with open(INDEX_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"✅ 已创建索引文件: {INDEX_FILE}")

def load_index():
    with open(INDEX_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_index(index):
    with open(INDEX_FILE, 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=2, ensure_ascii=False)

def get_next_world_id(index):
    existing = set(index["worlds"].keys())
    i = 1
    while f"world_{i:03d}" in existing:
        i += 1
    return f"world_{i:03d}"

def create_world(name, description, source="", download=False, keyword=None, count=30):
    init_index()
    index = load_index()
    world_id = get_next_world_id(index)
    world_path = WORLDS_DIR / world_id

    world_path.mkdir(parents=True, exist_ok=True)
    for sub in WORLD_SUBDIRS:
        (world_path / sub).mkdir(parents=True, exist_ok=True)

    # 关键修改：无条件写入 keyword
    config = {
        "world_id": world_id,
        "name": name,
        "description": description,
        "source": source,
        "keyword": keyword,          # 无论是否 --auto，都写入 keyword（若 None 则为 null）
        "created": datetime.datetime.now().isoformat(),
        "path": str(world_path)
    }
    with open(world_path / "config.json", 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

    index["worlds"][world_id] = {
        "name": name,
        "description": description,
        "source": source,
        "created": config["created"],
        "path": str(world_path)
    }
    save_index(index)

    print(f"✅ 世界创建成功！")
    print(f"   ID: {world_id}")
    print(f"   名称: {name}")
    print(f"   路径: {world_path}")
    print(f"   描述: {description}")

    # 如果启用了自动初始化（包含下载、训练等）
    if download and keyword:
        print("\n🚀 开始自动初始化世界...")
        print("\n[0/5] 切换到新世界...")
        subprocess.run(["python", "world_manager.py", "switch", world_id], check=True)

        print("\n[1/5] 下载图片...")
        subprocess.run(["python", "download_images_for_world.py", "--world", world_id, "--keyword", keyword, "--count", str(count)], check=True)

        print("\n[2/5] 预处理图片...")
        subprocess.run(["python", "preprocess_world.py", world_id], check=True)

        print("\n[3/5] 训练图像自编码器...")
        subprocess.run(["python", "train_from_processed.py"], check=True)

        print("\n[4/5] 聚类生成概念中心...")
        subprocess.run(["python", "cluster_image_concepts.py"], check=True)

        print("\n[5/5] 更新世界分类器...")
        subprocess.run(["python", "world_classifier.py", "--update"], check=True)

        print("✅ 世界初始化完成！")

def list_worlds():
    init_index()
    index = load_index()
    worlds = index["worlds"]
    if not worlds:
        print("📭 暂无世界。")
        return
    print(f"\n📋 世界列表（共 {len(worlds)} 个）：")
    print("=" * 60)
    for wid, info in worlds.items():
        current_mark = " ★ 当前" if index.get("current_world") == wid else ""
        print(f"ID: {wid}{current_mark}")
        print(f"   名称: {info['name']}")
        print(f"   描述: {info['description']}")
        print(f"   创建时间: {info['created']}")
        print(f"   路径: {info['path']}")
        print("-" * 40)

def switch_world(world_id):
    init_index()
    index = load_index()
    if world_id not in index["worlds"]:
        print(f"❌ 世界 {world_id} 不存在！")
        return
    index["current_world"] = world_id
    save_index(index)
    with open(CURRENT_WORLD_FILE, 'w', encoding='utf-8') as f:
        f.write(world_id)
    world_path = index["worlds"][world_id]["path"]
    print(f"✅ 已切换到世界: {world_id}")
    print(f"   名称: {index['worlds'][world_id]['name']}")
    print(f"   路径: {world_path}")

def show_current():
    init_index()
    index = load_index()
    current = index.get("current_world")
    if not current:
        print("⚠️ 当前没有激活的世界。请先用 `switch` 切换。")
        return
    info = index["worlds"].get(current)
    if not info:
        print(f"❌ 当前世界 {current} 在索引中不存在，可能已被删除。")
        return
    print(f"\n🌟 当前世界：")
    print(f"   ID: {current}")
    print(f"   名称: {info['name']}")
    print(f"   描述: {info['description']}")
    print(f"   创建时间: {info['created']}")
    print(f"   路径: {info['path']}")

def delete_world(world_id, confirm=False):
    init_index()
    index = load_index()
    if world_id not in index["worlds"]:
        print(f"❌ 世界 {world_id} 不存在！")
        return
    if not confirm:
        print(f"⚠️  此操作将永久删除世界 {world_id} 及其所有数据！")
        answer = input("请输入世界名称以确认删除: ")
        if answer != index["worlds"][world_id]["name"]:
            print("❌ 名称不匹配，取消删除。")
            return
    world_path = Path(index["worlds"][world_id]["path"])
    if world_path.exists():
        shutil.rmtree(world_path)
        print(f"🗑️ 已删除目录: {world_path}")
    del index["worlds"][world_id]
    if index.get("current_world") == world_id:
        index["current_world"] = None
        if CURRENT_WORLD_FILE.exists():
            CURRENT_WORLD_FILE.unlink()
    save_index(index)
    print(f"✅ 世界 {world_id} 已从索引中移除。")

def main():
    parser = argparse.ArgumentParser(description="多世界管理工具")
    subparsers = parser.add_subparsers(dest="command", required=True, help="子命令")

    # create
    parser_create = subparsers.add_parser("create", help="创建新世界")
    parser_create.add_argument("--name", required=True, help="世界名称")
    parser_create.add_argument("--desc", required=True, help="世界描述")
    parser_create.add_argument("--source", default="", help="数据来源（可选）")
    parser_create.add_argument("--auto", action="store_true", help="创建后自动下载图片、训练并聚类")
    parser_create.add_argument("--keyword", help="下载关键词（与--auto配合使用）")
    parser_create.add_argument("--count", type=int, default=30, help="下载图片数量（默认30）")

    # list
    subparsers.add_parser("list", help="列出所有世界")

    # switch
    parser_switch = subparsers.add_parser("switch", help="切换当前世界")
    parser_switch.add_argument("world_id", help="世界ID (如 world_001)")

    # show
    subparsers.add_parser("show", help="显示当前世界信息")

    # delete
    parser_delete = subparsers.add_parser("delete", help="删除世界（谨慎）")
    parser_delete.add_argument("world_id", help="世界ID")
    parser_delete.add_argument("--force", action="store_true", help="强制删除（跳过确认）")

    args = parser.parse_args()

    if args.command == "create":
        create_world(args.name, args.desc, args.source,
                     download=args.auto,
                     keyword=args.keyword,
                     count=args.count)
    elif args.command == "list":
        list_worlds()
    elif args.command == "switch":
        switch_world(args.world_id)
    elif args.command == "show":
        show_current()
    elif args.command == "delete":
        delete_world(args.world_id, confirm=args.force)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

# ========== 新增 API 类 ==========
class WorldManager:
    def __init__(self):
        init_index()
        self.index = load_index()

    def get_current_world(self):
        current = self.index.get("current_world")
        if not current:
            return None
        info = self.index["worlds"].get(current)
        if not info:
            return None
        return {
            "world_id": current,
            "name": info["name"],
            "description": info["description"],
            "path": info["path"]
        }

    def list_worlds(self):
        return list(self.index["worlds"].items())

    def create_world(self, name, description, source=""):
        create_world(name, description, source)
        self.index = load_index()
        worlds = list(self.index["worlds"].keys())
        return worlds[-1] if worlds else None

    def switch_world(self, world_id):
        switch_world(world_id)
        self.index = load_index()

    def delete_world(self, world_id, force=False):
        delete_world(world_id, confirm=not force)
        self.index = load_index()

    def suggest_world(self, data_sample):
        raise NotImplementedError("suggest_world 方法尚未实现")

default_manager = WorldManager()