#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
record_system_state.py - 记录系统硬件状态和内部驱动力（多世界版）
将状态记录保存到当前世界的 STATE 目录下。

使用说明：
    python record_system_state.py [--interval 秒] [--world world_id]
    
如果不指定 --world，则使用当前活动世界。
"""

import os
import json
import time
import psutil
import numpy as np
import argparse
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
RECORD_INTERVAL = 1.0          # 记录间隔（秒），与图像采集频率对齐
IMAGE_DIR = r'D:\AI_MEMORY\image'  # 图像目录（仅用于对齐，可选）

def get_system_state():
    """采集当前系统状态（真实硬件 + 模拟数据）"""
    state = {}

    # 真实系统状态（通过psutil获取）
    state['timestamp'] = datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]  # 毫秒级时间戳
    state['cpu_percent'] = psutil.cpu_percent(interval=0.1)
    state['memory_percent'] = psutil.virtual_memory().percent
    state['disk_usage'] = psutil.disk_usage('D:').percent

    # 电池信息（如果存在）
    battery = psutil.sensors_battery()
    if battery:
        state['battery_percent'] = battery.percent
        state['power_plugged'] = battery.power_plugged
    else:
        state['battery_percent'] = 100  # 模拟台式机
        state['power_plugged'] = True

    # 以下为模拟数据（需替换为实际硬件读数）
    # 飞行姿态（roll, pitch, yaw）
    state['attitude'] = {
        'roll': np.random.uniform(-180, 180),
        'pitch': np.random.uniform(-90, 90),
        'yaw': np.random.uniform(-180, 180)
    }
    # 摄像头角度（pan, tilt）
    state['camera_angle'] = {
        'pan': np.random.uniform(-180, 180),
        'tilt': np.random.uniform(-90, 90)
    }
    # 电机电流（左、右）
    state['motor_current'] = {
        'left': np.random.uniform(0, 5),
        'right': np.random.uniform(0, 5)
    }
    # 操作手状态（如果存在）
    state['hand_sensors'] = {
        'finger_pressure': np.random.uniform(0, 10),
        'palm_temperature': np.random.uniform(20, 40)
    }

    # 内部驱动力（模拟）
    state['internal_drive'] = {
        'curiosity': np.random.uniform(0, 1),      # 好奇心
        'fatigue': np.random.uniform(0, 1),        # 疲劳度
        'hunger': np.random.uniform(0, 1)          # 能量需求（低电量对应高饥饿）
    }

    return state

def align_timestamp_with_image():
    """
    可选：将状态时间戳与最新图像的时间戳对齐
    这里简单返回当前时间，但可以扩展为从图像目录读取最新文件的时间
    """
    return datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]

def main():
    parser = argparse.ArgumentParser(description="系统状态记录（多世界版）")
    parser.add_argument('--interval', type=float, default=RECORD_INTERVAL,
                        help=f'记录间隔（秒），默认 {RECORD_INTERVAL}')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    # 获取目标世界
    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    state_dir = world_path / "STATE"
    state_dir.mkdir(parents=True, exist_ok=True)

    print(f"系统状态记录启动，目标世界: {current['world_id']} - {current['name']}")
    print(f"状态保存目录: {state_dir}")
    print(f"记录间隔: {args.interval} 秒，按 Ctrl+C 停止")

    try:
        while True:
            state = get_system_state()
            filename = f"{state['timestamp']}_state.json"
            filepath = state_dir / filename
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, ensure_ascii=False)
            print(f"已记录状态: {filename}")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n状态记录停止")

if __name__ == '__main__':
    main()