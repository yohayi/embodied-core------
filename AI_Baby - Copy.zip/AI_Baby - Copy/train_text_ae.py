#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train_text_ae.py - 字符级文本自编码器（PyTorch CPU 版）
从当前世界的 RAW/text 读取所有 .txt 文件，训练自编码器，
保存模型到 MODELS/，向量保存到 MODELS/per_text_vectors/。
支持从全局目录复制预训练模型。
"""

import os
import glob
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from collections import Counter
import shutil

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
LATENT_DIM = 128
HIDDEN_DIM = 256
EMBEDDING_DIM = 64
MAX_LEN = 200
BATCH_SIZE = 64
EPOCHS = 50
LEARNING_RATE = 0.001
SAVE_MODEL_EVERY = 5
MIN_CHAR_FREQ = 2
GLOBAL_MODEL_DIR = Path(r"D:\AI_MEMORY\MODELS")  # 全局模型目录

def build_char_map(text_files, min_freq=MIN_CHAR_FREQ):
    """扫描所有文本文件，统计字符频率，构建字符到索引的映射"""
    counter = Counter()
    for file in text_files:
        with open(file, 'r', encoding='utf-8') as f:
            text = f.read()
            counter.update(text)
    chars = ['<PAD>', '<UNK>'] + [ch for ch, cnt in counter.items() if cnt >= min_freq]
    char2idx = {ch: i for i, ch in enumerate(chars)}
    idx2char = {i: ch for i, ch in enumerate(chars)}
    print(f"字符集大小: {len(chars)}")
    return char2idx, idx2char, len(chars)

class TextDataset(Dataset):
    def __init__(self, text_files, char2idx, max_len=MAX_LEN):
        self.text_files = text_files
        self.char2idx = char2idx
        self.max_len = max_len
        self.vocab_size = len(char2idx)

    def __len__(self):
        return len(self.text_files)

    def __getitem__(self, idx):
        file = self.text_files[idx]
        with open(file, 'r', encoding='utf-8') as f:
            text = f.read()
        indices = [self.char2idx.get(ch, self.char2idx['<UNK>']) for ch in text]
        if len(indices) > self.max_len:
            indices = indices[:self.max_len]
        else:
            indices = indices + [self.char2idx['<PAD>']] * (self.max_len - len(indices))
        return torch.tensor(indices, dtype=torch.long)

class TextEncoder(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, latent_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.fc_mu = nn.Linear(hidden_dim * 2, latent_dim)

    def forward(self, x):
        embedded = self.embedding(x)
        _, (hidden, _) = self.lstm(embedded)
        # hidden: (num_layers * num_directions, batch, hidden_dim)
        # 取最后一层双向的拼接
        hidden = torch.cat((hidden[-2], hidden[-1]), dim=1)
        latent = self.fc_mu(hidden)
        return latent

class TextDecoder(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, latent_dim, max_len):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, vocab_size)
        self.latent_to_hidden = nn.Linear(latent_dim, hidden_dim)
        self.max_len = max_len

    def forward(self, latent, targets=None):
        batch_size = latent.size(0)
        h0 = self.latent_to_hidden(latent).unsqueeze(0)  # (1, batch, hidden)
        c0 = torch.zeros_like(h0)
        if targets is not None:
            embedded = self.embedding(targets)
            outputs, _ = self.lstm(embedded, (h0, c0))
            logits = self.fc(outputs)
            return logits
        else:
            # 推理模式（训练时不使用）
            raise NotImplementedError("推理模式未实现，训练请提供 targets")

class TextAutoencoder(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, latent_dim, max_len):
        super().__init__()
        self.encoder = TextEncoder(vocab_size, embed_dim, hidden_dim, latent_dim)
        self.decoder = TextDecoder(vocab_size, embed_dim, hidden_dim, latent_dim, max_len)

    def forward(self, x):
        latent = self.encoder(x)
        logits = self.decoder(latent, targets=x)
        return logits, latent

def load_latest_model(model, model_dir):
    """加载当前世界的最新模型，如果没有则从全局复制"""
    model_files = sorted(model_dir.glob("text_ae_epoch_*.pth"))
    if model_files:
        latest = model_files[-1]
        model.load_state_dict(torch.load(latest, map_location='cpu'))
        print(f"已加载当前世界最新模型: {latest.name}")
        return True

    # 当前世界没有模型，尝试从全局复制
    global_models = list(GLOBAL_MODEL_DIR.glob("text_ae_epoch_*.pth"))
    if global_models:
        latest_global = max(global_models, key=lambda p: int(p.stem.split('_')[-1]))
        print(f"当前世界无模型，从全局复制 {latest_global.name} 到 {model_dir}")
        shutil.copy(latest_global, model_dir / latest_global.name)
        model.load_state_dict(torch.load(model_dir / latest_global.name, map_location='cpu'))
        return True

    print("未找到任何模型，从随机初始化开始训练。")
    return False

def main():
    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    # 获取当前世界
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    text_dir = world_path / "RAW" / "text"
    model_dir = world_path / "MODELS"
    vector_dir = model_dir / "per_text_vectors"

    if not text_dir.exists():
        print(f"错误：文本目录不存在 {text_dir}")
        return

    os.makedirs(vector_dir, exist_ok=True)
    os.makedirs(model_dir, exist_ok=True)

    # 获取所有文本文件
    text_files = glob.glob(str(text_dir / "*.txt"))
    if len(text_files) == 0:
        print(f"错误：在 {text_dir} 中没有找到 .txt 文件")
        return
    print(f"找到 {len(text_files)} 个文本文件")

    # 构建字符映射
    char2idx, idx2char, vocab_size = build_char_map(text_files)

    # 创建数据集
    dataset = TextDataset(text_files, char2idx, MAX_LEN)
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    # 初始化模型
    model = TextAutoencoder(vocab_size, EMBEDDING_DIM, HIDDEN_DIM, LATENT_DIM, MAX_LEN).to(device)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.CrossEntropyLoss(ignore_index=char2idx['<PAD>'])

    # 加载已有模型（优先当前世界，其次全局）
    load_latest_model(model, model_dir)

    print(f"开始训练，设备 {device}，样本数 {len(dataset)}")
    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0
        for batch in dataloader:
            batch = batch.to(device)
            logits, latent = model(batch)
            loss = criterion(logits.view(-1, vocab_size), batch.view(-1))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * batch.size(0)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            model_path = model_dir / f"text_ae_epoch_{epoch}.pth"
            torch.save(model.state_dict(), model_path)
            print(f"模型已保存: {model_path}")

    # 保存所有文本的潜在向量
    print("正在保存所有文本向量...")
    model.eval()
    with torch.no_grad():
        for file in text_files:
            base = os.path.splitext(os.path.basename(file))[0]
            vec_path = vector_dir / f"{base}.npy"
            if vec_path.exists():
                continue  # 已存在则跳过
            with open(file, 'r', encoding='utf-8') as f:
                text = f.read()
            indices = [char2idx.get(ch, char2idx['<UNK>']) for ch in text]
            if len(indices) > MAX_LEN:
                indices = indices[:MAX_LEN]
            else:
                indices = indices + [char2idx['<PAD>']] * (MAX_LEN - len(indices))
            x = torch.tensor([indices], dtype=torch.long).to(device)
            _, latent = model(x)
            np.save(vec_path, latent.cpu().numpy().flatten())
    print("所有文本向量保存完成。")

if __name__ == "__main__":
    main()