#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
download_videos_for_world.py - 为指定世界自动下载视频（Pixabay Video API）
使用 Pixabay Video API，需提前获取 API Key。
用法：
    python download_videos_for_world.py --world world_001 --keyword outdoor --count 5
"""

import os
import time
import requests
import argparse
import subprocess
import shutil
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
PIXABAY_VIDEO_API_KEY = "54028123-871c7bbccb0da0e0cde73fcaf"
PIXABAY_VIDEO_API_URL = "https://pixabay.com/api/videos/"
RATE_LIMIT_INTERVAL = 0.6

_last_request_time = 0
_request_lock = __import__('threading').Lock()

def _rate_limited_sleep():
    global _last_request_time
    with _request_lock:
        now = time.time()
        elapsed = now - _last_request_time
        if elapsed < RATE_LIMIT_INTERVAL:
            time.sleep(RATE_LIMIT_INTERVAL - elapsed)
        _last_request_time = time.time()

def download_pixabay_videos(keyword, save_dir, count=5):
    """从 Pixabay 下载关键词相关的视频"""
    os.makedirs(save_dir, exist_ok=True)
    params = {
        "key": PIXABAY_VIDEO_API_KEY,
        "q": keyword,
        "video_type": "film",
        "per_page": 20,
        "page": 1
    }
    downloaded = 0
    page = 1
    while downloaded < count:
        params["page"] = page
        _rate_limited_sleep()
        try:
            resp = requests.get(PIXABAY_VIDEO_API_URL, params=params, timeout=10)
            if resp.status_code != 200:
                print(f"请求失败，状态码 {resp.status_code}，等待后重试...")
                time.sleep(5)
                continue
            data = resp.json()
            hits = data.get("hits", [])
            if not hits:
                print("没有更多视频了")
                break
            for item in hits:
                if downloaded >= count:
                    break
                videos = item.get("videos", {})
                video_info = videos.get("medium") or videos.get("small") or videos.get("large")
                if not video_info:
                    continue
                video_url = video_info.get("url")
                if not video_url:
                    continue
                _rate_limited_sleep()
                video_data = requests.get(video_url).content
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
                filename = f"{keyword}_{timestamp}.mp4"
                filepath = os.path.join(save_dir, filename)
                with open(filepath, 'wb') as f:
                    f.write(video_data)
                print(f"下载 {filename}")
                downloaded += 1
            page += 1
        except Exception as e:
            print(f"下载出错: {e}")
            time.sleep(5)
    print(f"完成，共下载 {downloaded} 个视频到 {save_dir}")
    return downloaded

def extract_videos(world_path, keyword):
    """拆解指定世界中新下载的视频（文件名含 keyword）"""
    video_dir = world_path / "RAW" / "video"
    if not video_dir.exists():
        return
    # 查找刚下载的视频（以 keyword_ 开头）
    for video_file in video_dir.glob(f"{keyword}_*.mp4"):
        # 避免重复拆解（可根据文件名判断是否已拆解）
        sync_dir = world_path / "SYNC_DATA" / video_file.stem
        if sync_dir.exists():
            continue
        print(f"拆解 {video_file.name}...")
        try:
            subprocess.run([
                "python", "extract_video_pairs.py",
                "--video", str(video_file),
                "--output", str(sync_dir)
            ], check=True)
            # 移动帧和音频到对应 RAW 目录
            for img in sync_dir.glob("*.jpg"):
                shutil.move(str(img), world_path / "RAW/image" / img.name)
            for aud in sync_dir.glob("*.wav"):
                shutil.move(str(aud), world_path / "RAW/audio" / aud.name)
            shutil.rmtree(sync_dir)
        except Exception as e:
            print(f"拆解 {video_file.name} 失败: {e}")

def main():
    parser = argparse.ArgumentParser(description="为指定世界自动下载视频（Pixabay）")
    parser.add_argument('--world', required=True, help='世界ID，如 world_001')
    parser.add_argument('--keyword', required=True, help='搜索关键词，如 outdoor')
    parser.add_argument('--count', type=int, default=5, help='下载数量，默认5')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    video_dir = world_path / "RAW" / "video"
    video_dir.mkdir(parents=True, exist_ok=True)

    print(f"为世界 {args.world} 下载视频，关键词：{args.keyword}，数量：{args.count}")
    downloaded = download_pixabay_videos(args.keyword, str(video_dir), args.count)
    if downloaded > 0:
        extract_videos(world_path, args.keyword)

if __name__ == "__main__":
    main()