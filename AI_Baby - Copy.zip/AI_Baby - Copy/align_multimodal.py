#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
align_multimodal.py - 三模态对比对齐（图像、音频、文本）
从当前世界的 MODELS/ 下读取各模态向量，以及 ALIGNED/triplets.txt，
训练投影网络将各模态映射到公共空间，保存映射后的向量和模型。
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
COMMON_DIM = 128
BATCH_SIZE = 64
EPOCHS = 50
LEARNING_RATE = 0.001
TEMPERATURE = 0.1
SAVE_MODEL_EVERY = 10

def load_vector_file(vec_path):
    """加载单个向量文件，确保为一维"""
    vec = np.load(vec_path)
    if vec.ndim == 2:
        vec = vec[0]
    return vec

class TripletDataset(Dataset):
    """读取 triplets.txt 文件，每行格式：图像文件名,音频文件名,文本文件名（可缺失）"""
    def __init__(self, triplet_file, img_vec_dir, aud_vec_dir, txt_vec_dir):
        self.samples = []
        with open(triplet_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split(',')
                if len(parts) < 2:
                    continue
                img_name = parts[0].strip()
                aud_name = parts[1].strip() if len(parts) > 1 else None
                txt_name = parts[2].strip() if len(parts) > 2 else None

                img_path = img_vec_dir / img_name if img_name else None
                aud_path = aud_vec_dir / aud_name if aud_name else None
                txt_path = txt_vec_dir / txt_name if txt_name else None

                # 至少有两种模态存在
                if (img_path and img_path.exists()) or (aud_path and aud_path.exists()) or (txt_path and txt_path.exists()):
                    self.samples.append((img_path, aud_path, txt_path))

        print(f"加载了 {len(self.samples)} 条配对数据")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, aud_path, txt_path = self.samples[idx]

        img_vec = load_vector_file(img_path) if img_path and img_path.exists() else np.zeros(256)
        aud_vec = load_vector_file(aud_path) if aud_path and aud_path.exists() else np.zeros(128)
        txt_vec = load_vector_file(txt_path) if txt_path and txt_path.exists() else np.zeros(128)

        return (torch.tensor(img_vec, dtype=torch.float32),
                torch.tensor(aud_vec, dtype=torch.float32),
                torch.tensor(txt_vec, dtype=torch.float32))

class Projector(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.fc = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        return self.fc(x)

def main():
    # 获取当前世界
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    img_vec_dir = world_path / "MODELS" / "per_image_vectors"
    aud_vec_dir = world_path / "MODELS" / "per_audio_vectors"
    txt_vec_dir = world_path / "MODELS" / "per_text_vectors"
    aligned_dir = world_path / "ALIGNED"
    aligned_dir.mkdir(parents=True, exist_ok=True)

    triplet_file = aligned_dir / "triplets.txt"
    if not triplet_file.exists():
        print(f"错误：找不到配对文件 {triplet_file}，请先准备 triplets.txt")
        print("你可以运行 generate_triplets.py 自动生成。")
        return

    # 检查目录是否存在（仅警告）
    for d in [img_vec_dir, aud_vec_dir, txt_vec_dir]:
        if not d.exists():
            print(f"警告：目录不存在 {d}，将使用零向量填充")

    # 创建数据集
    dataset = TripletDataset(triplet_file, img_vec_dir, aud_vec_dir, txt_vec_dir)
    if len(dataset) == 0:
        print("错误：没有有效配对数据")
        return

    # 获取维度（使用第一个样本）
    sample_img, sample_aud, sample_txt = dataset[0]
    img_dim = sample_img.shape[0]
    aud_dim = sample_aud.shape[0]
    txt_dim = sample_txt.shape[0]

    # 初始化投影网络
    img_proj = Projector(img_dim, COMMON_DIM)
    aud_proj = Projector(aud_dim, COMMON_DIM)
    txt_proj = Projector(txt_dim, COMMON_DIM)

    # 强制使用 CPU
    device = torch.device('cpu')
    img_proj.to(device)
    aud_proj.to(device)
    txt_proj.to(device)

    optimizer = optim.Adam(list(img_proj.parameters()) + list(aud_proj.parameters()) + list(txt_proj.parameters()), lr=LEARNING_RATE)

    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    print(f"开始训练，公共维度 {COMMON_DIM}，设备 {device}，样本数 {len(dataset)}")

    for epoch in range(1, EPOCHS + 1):
        total_loss = 0.0
        for img_batch, aud_batch, txt_batch in dataloader:
            img_batch = img_batch.to(device)
            aud_batch = aud_batch.to(device)
            txt_batch = txt_batch.to(device)

            img_emb = nn.functional.normalize(img_proj(img_batch), dim=1)
            aud_emb = nn.functional.normalize(aud_proj(aud_batch), dim=1)
            txt_emb = nn.functional.normalize(txt_proj(txt_batch), dim=1)

            # 计算两两相似度（图像-音频、图像-文本、音频-文本）
            logits_ia = img_emb @ aud_emb.T / TEMPERATURE
            logits_it = img_emb @ txt_emb.T / TEMPERATURE
            logits_at = aud_emb @ txt_emb.T / TEMPERATURE

            labels = torch.arange(len(img_batch), device=device)

            loss_ia = (nn.functional.cross_entropy(logits_ia, labels) + nn.functional.cross_entropy(logits_ia.T, labels)) / 2
            loss_it = (nn.functional.cross_entropy(logits_it, labels) + nn.functional.cross_entropy(logits_it.T, labels)) / 2
            loss_at = (nn.functional.cross_entropy(logits_at, labels) + nn.functional.cross_entropy(logits_at.T, labels)) / 2

            loss = (loss_ia + loss_it + loss_at) / 3

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(img_batch)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            torch.save(img_proj.state_dict(), aligned_dir / f"img_proj_epoch{epoch}.pth")
            torch.save(aud_proj.state_dict(), aligned_dir / f"aud_proj_epoch{epoch}.pth")
            torch.save(txt_proj.state_dict(), aligned_dir / f"txt_proj_epoch{epoch}.pth")
            print(f"模型已保存至 {aligned_dir}")

    # 映射所有向量并保存
    print("正在映射所有向量...")
    def map_and_save(proj, vec_dir, out_name):
        if not vec_dir.exists():
            print(f"跳过 {out_name}：目录不存在 {vec_dir}")
            return
        files = list(vec_dir.glob("*.npy"))
        if not files:
            print(f"跳过 {out_name}：目录为空")
            return
        vecs = []
        fnames = []
        for f in files:
            v = np.load(f)
            if v.ndim == 2:
                v = v[0]
            vecs.append(v)
            fnames.append(f.name)
        X = torch.tensor(np.array(vecs), dtype=torch.float32).to(device)
        with torch.no_grad():
            mapped = proj(X).cpu().numpy()
        out_dir = aligned_dir / out_name
        out_dir.mkdir(exist_ok=True)
        for fn, mv in zip(fnames, mapped):
            np.save(out_dir / fn, mv)
        print(f"  已映射 {len(fnames)} 个向量到 {out_dir}")

    map_and_save(img_proj, img_vec_dir, 'mapped_image_vectors')
    map_and_save(aud_proj, aud_vec_dir, 'mapped_audio_vectors')
    map_and_save(txt_proj, txt_vec_dir, 'mapped_text_vectors')

    print("三模态对齐完成！")

if __name__ == "__main__":
    main()