#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ingest_documents.py - 使用 PaddleOCR 提取文档文本，支持 PDF、Word、图片。
支持多语言（中、英、日、韩）和公式占位符。
"""

import argparse
import json
import os
import sys
from pathlib import Path
import traceback

try:
    import cv2
    import numpy as np
    from paddleocr import PaddleOCR
    from pdf2image import convert_from_path
    from PIL import Image
    from docx import Document
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请先安装: pip install paddlepaddle paddleocr pdf2image pillow python-docx")
    sys.exit(1)

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    sys.exit(1)

# ========== 配置 ==========
DEFAULT_LANG = 'ch'  # 主语言，可设为 ['ch', 'en', 'japan', 'korean'] 列表
USE_GPU = False       # 强制使用 CPU
OCR_THRESHOLD = 0.5  # 置信度阈值

class MultiLangOCR:
    def __init__(self, lang_list=None, use_gpu=False):
        if lang_list is None:
            lang_list = ['ch', 'en', 'japan', 'korean']
        self.ocr = PaddleOCR(
            use_angle_cls=True,
            lang='ch',           # 主语言，但会同时加载其他语言
            use_gpu=use_gpu,
            show_log=False
        )
        # 实际上 PaddleOCR 可以同时加载多种语言，但需要设置 det_db_thresh 等参数。
        # 简单起见，我们使用默认配置，它会自动识别多种语言。
        print(f"OCR 初始化完成，语言: {lang_list}, GPU: {use_gpu}")

    def ocr_image(self, image):
        """对 PIL Image 进行 OCR，返回文本（带公式占位）"""
        # 将 PIL 转换为 numpy 数组
        img_np = np.array(image)
        result = self.ocr.ocr(img_np, cls=True)
        if not result or not result[0]:
            return ""
        texts = []
        for line in result[0]:
            text = line[1][0]  # 识别出的文本
            confidence = line[1][1]
            if confidence < OCR_THRESHOLD:
                # 低置信度区域可能包含公式，用占位符替换
                # 简单策略：用 [公式] 替换整行
                texts.append("[公式]")
            else:
                texts.append(text)
        return "\n".join(texts)

ocr_engine = None

def get_ocr_engine():
    global ocr_engine
    if ocr_engine is None:
        ocr_engine = MultiLangOCR(use_gpu=USE_GPU)
    return ocr_engine

def extract_text_from_pdf(pdf_path, dpi=200):
    """PDF 转图片后 OCR"""
    images = convert_from_path(pdf_path, dpi=dpi)
    full_text = []
    ocr = get_ocr_engine()
    for i, img in enumerate(images):
        print(f"  处理第 {i+1}/{len(images)} 页...")
        text = ocr.ocr_image(img)
        full_text.append(text)
    return "\n\n".join(full_text)

def extract_text_from_word(docx_path):
    """提取 Word 文档中的段落文本（不 OCR，直接读取）"""
    doc = Document(docx_path)
    texts = [para.text for para in doc.paragraphs if para.text.strip()]
    return "\n".join(texts)

def extract_text_from_image(image_path):
    """图片 OCR"""
    img = Image.open(image_path)
    ocr = get_ocr_engine()
    return ocr.ocr_image(img)

def process_file(file_path, world_text_dir, ocr_pdf=False):
    """处理单个文件，保存文本到世界文本目录"""
    suffix = file_path.suffix.lower()
    if suffix == '.pdf':
        text = extract_text_from_pdf(file_path)
    elif suffix in ('.docx', '.doc'):
        text = extract_text_from_word(file_path)
    elif suffix in ('.jpg', '.jpeg', '.png', '.bmp', '.tiff'):
        text = extract_text_from_image(file_path)
    else:
        return

    if text and text.strip():
        out_name = file_path.stem + '.txt'
        out_path = world_text_dir / out_name
        # 避免文件名冲突
        counter = 1
        while out_path.exists():
            out_path = world_text_dir / f"{file_path.stem}_{counter}.txt"
            counter += 1
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(text)
        print(f"已保存: {out_path}")
    else:
        print(f"未能提取文本: {file_path}")

def main():
    parser = argparse.ArgumentParser(description="使用 PaddleOCR 提取文档文本到世界")
    parser.add_argument('--world', required=True, help='目标世界ID')
    parser.add_argument('--input', required=True, help='输入文件或目录')
    parser.add_argument('--dpi', type=int, default=200, help='PDF 转图片的 DPI')
    parser.add_argument('--ocr', action='store_true', help='强制对 PDF 使用 OCR（默认对所有 PDF 进行 OCR）')
    args = parser.parse_args()

    # 获取世界路径
    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    text_dir = world_path / "RAW" / "text"
    text_dir.mkdir(parents=True, exist_ok=True)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：输入路径不存在 {input_path}")
        return

    # 收集文件
    if input_path.is_file():
        files = [input_path]
    else:
        files = []
        for ext in ['.pdf', '.docx', '.doc', '.jpg', '.jpeg', '.png', '.bmp', '.tiff']:
            files.extend(input_path.rglob(f'*{ext}'))
            files.extend(input_path.rglob(f'*{ext.upper()}'))

    print(f"找到 {len(files)} 个文件，开始处理...")
    for f in files:
        process_file(f, text_dir, ocr_pdf=args.ocr)

    print("处理完成！")

if __name__ == "__main__":
    main()