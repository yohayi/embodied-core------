#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
hand_learner.py - 手部技能学习模块（电脑端）
通过强化学习或模仿学习，让AI学会控制手部执行器。
与 hand_controller.py 配合，发送动作指令并接收反馈（如视觉、触觉）。
使用简单的 DQN 或 PPO 算法，可接入 Stable-Baselines3。
"""

import os
import time
import json
import socket
import numpy as np
from pathlib import Path
import gym
from gym import spaces
import torch
import torch.nn as nn
import torch.optim as optim

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
HAND_CONTROLLER_IP = '192.168.1.xxx'  # 树莓派IP，需修改
HAND_CONTROLLER_PORT = 8891
USE_REAL_HARDWARE = False  # 若为False，则模拟手部反馈（用于仿真）
MAX_EPISODES = 1000
MAX_STEPS = 50
LEARNING_RATE = 0.001
GAMMA = 0.99
EPSILON = 1.0
EPSILON_DECAY = 0.995
EPSILON_MIN = 0.01
BATCH_SIZE = 32
MEMORY_SIZE = 10000

# 动作空间：每个电机的速度（-100 ~ 100），假设4个电机
ACTION_DIM = 4
ACTION_LOW = -100
ACTION_HIGH = 100

# 状态空间：图像向量（256）+ 触觉（1）+ 当前关节角度（4）等，这里简化
STATE_DIM = 256 + 1 + 4

class HandEnv(gym.Env):
    """手部环境（与真实硬件或模拟交互）"""
    def __init__(self):
        super().__init__()
        self.action_space = spaces.Box(low=ACTION_LOW, high=ACTION_HIGH, shape=(ACTION_DIM,), dtype=np.float32)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(STATE_DIM,), dtype=np.float32)
        self.sock = None
        self.steps = 0

    def connect(self):
        if USE_REAL_HARDWARE:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((HAND_CONTROLLER_IP, HAND_CONTROLLER_PORT))

    def send_action(self, action):
        """发送动作指令，返回下一状态和奖励"""
        if USE_REAL_HARDWARE:
            # 发送指令
            cmd = ','.join([f'MOTOR{i+1}:{int(action[i])}' for i in range(ACTION_DIM)])
            self.sock.send(cmd.encode())
            # 等待响应
            resp = self.sock.recv(1024).decode()
            # 请求状态
            self.sock.send(b'status')
            status_data = self.sock.recv(4096).decode()
            try:
                status = json.loads(status_data)
                angles = status.get('angles', [0]*ACTION_DIM)
            except:
                angles = [0]*ACTION_DIM
            # 模拟图像向量和触觉（实际应从世界读取）
            # 这里简化，用随机向量
            img_vec = np.random.randn(256)
            touch = np.random.rand()
            state = np.concatenate([img_vec, [touch], angles])
            # 奖励：例如触觉为正则鼓励抓取，这里用随机
            reward = np.random.rand()
            done = False
            return state, reward, done
        else:
            # 仿真模式：模拟手部动力学
            # 这里简化：根据动作更新角度（积分）
            self.sim_angles = getattr(self, 'sim_angles', np.zeros(ACTION_DIM))
            self.sim_angles += action * 0.01  # 简单积分
            self.sim_angles = np.clip(self.sim_angles, -100, 100)
            # 生成假图像向量和触觉
            img_vec = np.random.randn(256)
            touch = np.random.rand()
            state = np.concatenate([img_vec, [touch], self.sim_angles])
            # 奖励：例如触觉高奖励
            reward = touch
            self.steps += 1
            done = self.steps >= MAX_STEPS
            return state, reward, done

    def reset(self):
        self.steps = 0
        if USE_REAL_HARDWARE:
            # 发送复位指令（假设有）
            self.sock.send(b'RESET')
            self.sock.recv(1024)
            # 获取初始状态
            self.sock.send(b'status')
            status_data = self.sock.recv(4096).decode()
            try:
                status = json.loads(status_data)
                angles = status.get('angles', [0]*ACTION_DIM)
            except:
                angles = [0]*ACTION_DIM
            img_vec = np.random.randn(256)
            touch = np.random.rand()
            state = np.concatenate([img_vec, [touch], angles])
        else:
            self.sim_angles = np.zeros(ACTION_DIM)
            img_vec = np.random.randn(256)
            touch = np.random.rand()
            state = np.concatenate([img_vec, [touch], self.sim_angles])
        return state

    def close(self):
        if self.sock:
            self.sock.close()

# 简单的DQN网络（可替换为PPO等）
class DQN(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        )
    def forward(self, x):
        return self.net(x)

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.pos = 0
    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.pos] = (state, action, reward, next_state, done)
        self.pos = (self.pos + 1) % self.capacity
    def sample(self, batch_size):
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        batch = [self.buffer[i] for i in indices]
        states = torch.FloatTensor([b[0] for b in batch])
        actions = torch.LongTensor([b[1] for b in batch])
        rewards = torch.FloatTensor([b[2] for b in batch])
        next_states = torch.FloatTensor([b[3] for b in batch])
        dones = torch.FloatTensor([b[4] for b in batch])
        return states, actions, rewards, next_states, dones
    def __len__(self):
        return len(self.buffer)

def train_dqn(env):
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]  # 连续动作，但DQN需要离散化，这里简化为连续值直接用DDPG
    # 为了简化，使用DDPG或SAC更好，这里仅做示例，实际推荐使用Stable-Baselines3
    # 我们简单使用随机策略作为占位
    print("训练开始，使用随机策略（请替换为实际强化学习算法）")
    for episode in range(MAX_EPISODES):
        state = env.reset()
        total_reward = 0
        for step in range(MAX_STEPS):
            action = np.random.uniform(ACTION_LOW, ACTION_HIGH, size=ACTION_DIM)  # 随机动作
            next_state, reward, done = env.send_action(action)
            total_reward += reward
            state = next_state
            if done:
                break
        print(f"Episode {episode}, 总奖励: {total_reward:.2f}")

def main():
    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    model_dir = world_path / "MODELS"
    model_dir.mkdir(parents=True, exist_ok=True)

    env = HandEnv()
    env.connect()
    try:
        train_dqn(env)
    finally:
        env.close()

if __name__ == "__main__":
    main()