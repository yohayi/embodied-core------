#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
多世界多媒体自动导入守护进程
- 定期扫描源文件夹（图片、音频、视频），将新文件导入到所有现有世界
- 按世界记录已处理文件，避免重复
- 支持格式：图片（jpg/jpeg/png/bmp）、音频（wav/mp3）、视频（mp4/avi/mov）
"""

import os
import time
import json
import subprocess
import argparse
from pathlib import Path
import logging

# ========== 配置 ==========
SCAN_INTERVAL = 3600          # 扫描间隔（秒），默认1小时
SOURCE_DIRS = [
    "E:/文档与学习与实践",
    "E:/徒弟游-我的书籍副本"
]
STATE_FILE = "D:/AI_MEMORY/auto_doc_importer_per_world_state.json"
IMPORT_SCRIPT = "ingest_any_doc.py"   # 导入脚本文件名

# 日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("auto_doc_importer_per_world.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

def get_all_worlds():
    """获取所有世界ID"""
    try:
        from world_manager import WorldManager
        wm = WorldManager()
        return list(wm.index["worlds"].keys())
    except Exception as e:
        logging.error(f"获取世界列表失败: {e}")
        return []

def load_state():
    """加载全局状态（按世界存储）"""
    if Path(STATE_FILE).exists():
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"worlds": {}}

def save_state(state):
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)

def is_processed(world_id, file_path, state):
    """判断文件在指定世界中是否已处理"""
    world_state = state["worlds"].get(world_id, {})
    file_path_str = str(file_path)
    if file_path_str not in world_state:
        return False
    stored_mtime = world_state[file_path_str].get("mtime")
    try:
        current_mtime = os.path.getmtime(file_path)
        return current_mtime == stored_mtime
    except:
        return False

def mark_processed(world_id, file_path, state):
    """标记文件在指定世界中为已处理"""
    if world_id not in state["worlds"]:
        state["worlds"][world_id] = {}
    file_path_str = str(file_path)
    try:
        mtime = os.path.getmtime(file_path)
        state["worlds"][world_id][file_path_str] = {"mtime": mtime}
        save_state(state)
    except Exception as e:
        logging.error(f"标记处理失败 {world_id} {file_path}: {e}")

def scan_and_import():
    """扫描源文件夹，将所有新多媒体文件导入到所有世界"""
    state = load_state()
    worlds = get_all_worlds()
    if not worlds:
        logging.warning("没有找到任何世界，跳过导入")
        return

    # 收集所有源文件（仅图片、音频、视频）
    all_files = []
    for src in SOURCE_DIRS:
        src_path = Path(src)
        if not src_path.exists():
            logging.warning(f"源目录不存在: {src_path}")
            continue
        # 图片扩展名
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
            all_files.extend(src_path.rglob(ext))
        # 音频扩展名
        for ext in ['*.wav', '*.mp3']:
            all_files.extend(src_path.rglob(ext))
        # 视频扩展名
        for ext in ['*.mp4', '*.avi', '*.mov']:
            all_files.extend(src_path.rglob(ext))

    logging.info(f"发现 {len(all_files)} 个多媒体源文件，待检查各世界处理状态")

    # 对每个世界，找出该世界尚未处理的新文件
    for world_id in worlds:
        world_new_files = [f for f in all_files if not is_processed(world_id, f, state)]
        if not world_new_files:
            logging.info(f"世界 {world_id} 没有新文件")
            continue

        logging.info(f"世界 {world_id} 发现 {len(world_new_files)} 个新文件，开始导入...")
        for f in world_new_files:
            try:
                cmd = [
                    "python", IMPORT_SCRIPT,
                    "--world", world_id,
                    "--input", str(f)
                ]
                logging.debug(f"执行命令: {' '.join(cmd)}")
                subprocess.run(cmd, check=True, timeout=600)  # 每个文件10分钟超时
                mark_processed(world_id, f, state)
                logging.info(f"世界 {world_id} 导入成功: {f.name}")
            except subprocess.TimeoutExpired:
                logging.error(f"世界 {world_id} 处理超时: {f.name}")
            except subprocess.CalledProcessError as e:
                logging.error(f"世界 {world_id} 处理失败: {f.name}, 返回码 {e.returncode}")
            except Exception as e:
                logging.error(f"世界 {world_id} 处理异常: {f.name}, {e}")

def main():
    parser = argparse.ArgumentParser(description="多世界多媒体自动导入守护进程")
    parser.add_argument('--interval', type=int, default=SCAN_INTERVAL,
                        help=f'扫描间隔（秒），默认 {SCAN_INTERVAL}')
    parser.add_argument('--once', action='store_true',
                        help='只运行一次，不循环')
    args = parser.parse_args()

    logging.info(f"多世界多媒体导入守护进程启动")
    logging.info(f"扫描目录: {SOURCE_DIRS}")
    logging.info(f"扫描间隔: {args.interval} 秒")
    logging.info(f"状态文件: {STATE_FILE}")

    while True:
        try:
            scan_and_import()
        except Exception as e:
            logging.exception(f"扫描过程发生异常: {e}")
        if args.once:
            break
        time.sleep(args.interval)

if __name__ == "__main__":
    main()