#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
download_images_for_world.py - 为指定世界自动下载图片（Pixabay API）
使用 Pixabay 免费 API，需提前获取 API Key。
用法：
    python download_images_for_world.py --world world_001 --keyword outdoor --count 30
"""

import os
import time
import random
import threading
import requests
import argparse
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
PIXABAY_API_KEY = "55114386-ec6f09a2a8244618159097fa1"
PIXABAY_API_URL = "https://pixabay.com/api/"
# 速率限制：每分钟最多 100 次请求，约 0.6 秒/次
RATE_LIMIT_INTERVAL = 0.6  # 秒

# 全局速率控制
_last_request_time = 0
_request_lock = threading.Lock()

def _rate_limited_sleep():
    """确保请求间隔不小于 RATE_LIMIT_INTERVAL 秒"""
    global _last_request_time
    with _request_lock:
        now = time.time()
        elapsed = now - _last_request_time
        if elapsed < RATE_LIMIT_INTERVAL:
            time.sleep(RATE_LIMIT_INTERVAL - elapsed)
        _last_request_time = time.time()

def download_pixabay_images(keyword, save_dir, count=30):
    """从 Pixabay 下载关键词相关的图片（带全局速率限制）"""
    os.makedirs(save_dir, exist_ok=True)
    params = {
        "key": PIXABAY_API_KEY,
        "q": keyword,
        "image_type": "photo",
        "per_page": 200,          # 每页最多200
        "page": 1
    }
    downloaded = 0
    page = 1
    while downloaded < count:
        params["page"] = page
        # 速率限制：请求元数据前
        _rate_limited_sleep()
        try:
            resp = requests.get(PIXABAY_API_URL, params=params, timeout=10)
            if resp.status_code != 200:
                print(f"请求失败，状态码 {resp.status_code}，等待后重试...")
                time.sleep(5)
                continue
            data = resp.json()
            hits = data.get("hits", [])
            if not hits:
                print("没有更多图片了")
                break
            for item in hits:
                if downloaded >= count:
                    break
                img_url = item["webformatURL"]   # 中等尺寸图片
                # 速率限制：下载图片前
                _rate_limited_sleep()
                img_data = requests.get(img_url).content
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
                filename = f"{keyword}_{timestamp}.jpg"
                filepath = os.path.join(save_dir, filename)
                with open(filepath, 'wb') as f:
                    f.write(img_data)
                print(f"下载 {filename}")
                downloaded += 1
            page += 1
        except Exception as e:
            print(f"下载出错: {e}")
            time.sleep(5)
    print(f"完成，共下载 {downloaded} 张图片到 {save_dir}")

def main():
    parser = argparse.ArgumentParser(description="为指定世界自动下载图片（Pixabay）")
    parser.add_argument('--world', required=True, help='世界ID，如 world_001')
    parser.add_argument('--keyword', required=True, help='搜索关键词，如 outdoor')
    parser.add_argument('--count', type=int, default=30, help='下载数量，默认30')
    args = parser.parse_args()

    # 获取世界路径
    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    raw_image_dir = world_path / "RAW" / "image"
    raw_image_dir.mkdir(parents=True, exist_ok=True)

    print(f"为世界 {args.world} 下载图片，关键词：{args.keyword}，数量：{args.count}")
    download_pixabay_images(args.keyword, str(raw_image_dir), args.count)

if __name__ == "__main__":
    main()