#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
generate_triplets.py - 自动生成多模态配对文件 triplets.txt
扫描当前世界 MODELS/ 下的 per_image_vectors, per_audio_vectors, per_text_vectors 目录，
根据文件名中的数字序号（或相同前缀）自动配对，生成 triplets.txt 保存在 ALIGNED/ 目录。
"""

import os
import re
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

def extract_number(filename):
    """从文件名中提取第一个数字串，作为配对键"""
    match = re.search(r'(\d+)', filename)
    return int(match.group(1)) if match else None

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    img_dir = world_path / "MODELS" / "per_image_vectors"
    aud_dir = world_path / "MODELS" / "per_audio_vectors"
    txt_dir = world_path / "MODELS" / "per_text_vectors"
    aligned_dir = world_path / "ALIGNED"
    aligned_dir.mkdir(parents=True, exist_ok=True)

    # 收集各模态文件及其数字键
    img_files = {extract_number(f.name): f.name for f in img_dir.glob("*.npy") if extract_number(f.name) is not None}
    aud_files = {extract_number(f.name): f.name for f in aud_dir.glob("*.npy") if extract_number(f.name) is not None}
    txt_files = {extract_number(f.name): f.name for f in txt_dir.glob("*.npy") if extract_number(f.name) is not None}

    # 求所有键的并集，但至少有两种模态存在才保留
    all_keys = set(img_files.keys()) | set(aud_files.keys()) | set(txt_files.keys())
    triplets = []
    for key in sorted(all_keys):
        img = img_files.get(key, "")
        aud = aud_files.get(key, "")
        txt = txt_files.get(key, "")
        # 至少有两种模态
        if (img or aud or txt) and not (img == "" and aud == "" and txt == ""):
            triplets.append(f"{img},{aud},{txt}")

    triplet_path = aligned_dir / "triplets.txt"
    with open(triplet_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(triplets))
    print(f"已生成 {len(triplets)} 条配对记录，保存至 {triplet_path}")

if __name__ == "__main__":
    main()