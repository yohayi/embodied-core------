import subprocess
from pathlib import Path
from world_manager import WorldManager

wm = WorldManager()
worlds = wm.list_worlds()

for wid, info in worlds:
    world_path = Path(info["path"])
    print(f"处理世界 {wid}...")
    
    # 1. 图片预处理（若 RAW/image 有文件但 PROCESSED/image 为空）
    raw_img = world_path / "RAW" / "image"
    proc_img = world_path / "PROCESSED" / "image"
    if raw_img.exists() and any(raw_img.glob("*")) and (not proc_img.exists() or not any(proc_img.glob("*.jpg"))):
        print(f"  预处理图片...")
        subprocess.run(["python", "preprocess_world.py", wid], check=False)
    
    # 2. 训练图像自编码器（若模型不存在）
    model_dir = world_path / "MODELS"
    if not any(model_dir.glob("image_ae_epoch_*.pth")):
        print(f"  训练图像自编码器...")
        subprocess.run(["python", "train_from_processed.py", "--world", wid], check=False)
    
    # 3. 训练音频自编码器（若模型不存在）
    if not any(model_dir.glob("audio_ae_epoch_*.pth")):
        print(f"  训练音频自编码器...")
        subprocess.run(["python", "train_audio_from_folder.py", "--world", wid], check=False)
    
    print(f"世界 {wid} 处理完成")