#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
observation_natural.py - 自然语言观测模块
为当前世界的最新图像和音频生成自然语言描述，保存到 RAW/text。
"""

import json
import time
from pathlib import Path
import easyocr
import whisper
import cv2
from PIL import Image

try:
    from world_manager import WorldManager
    from teacher_guide import Teacher
except ImportError:
    print("错误：无法导入 WorldManager 或 Teacher")
    exit(1)

# 全局懒加载
_easyocr_reader = None
_whisper_model = None
_teacher = None

def get_easyocr():
    global _easyocr_reader
    if _easyocr_reader is None:
        print("加载 EasyOCR（中英文）...")
        _easyocr_reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)
    return _easyocr_reader

def get_whisper():
    global _whisper_model
    if _whisper_model is None:
        print("加载 Whisper medium 模型...")
        _whisper_model = whisper.load_model("medium", device="cpu")
    return _whisper_model

def get_teacher():
    global _teacher
    if _teacher is None:
        _teacher = Teacher()
    return _teacher

def get_latest_image(world_path):
    """获取当前世界 RAW/image 目录中最新的一张图片路径"""
    img_dir = world_path / "RAW" / "image"
    if not img_dir.exists():
        return None
    images = sorted(img_dir.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    return images[0] if images else None

def get_latest_audio(world_path):
    """获取当前世界 RAW/audio 目录中最新的一段音频路径"""
    audio_dir = world_path / "RAW" / "audio"
    if not audio_dir.exists():
        return None
    audios = sorted(audio_dir.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    return audios[0] if audios else None

def describe_image(image_path, teacher):
    """使用 EasyOCR 提取文字，再让教师模型生成描述"""
    reader = get_easyocr()
    # 读取图片
    img = cv2.imread(str(image_path))
    if img is None:
        return None
    # OCR
    result = reader.readtext(img, detail=0, paragraph=True)
    ocr_text = "\n".join(result) if result else "未检测到文字"
    # 构建提示
    prompt = f"""你是一个观察者，看到一张图片。图片中的文字内容如下：
{ocr_text}

请用中文简要描述这张图片可能的内容（例如场景、物体、氛围等），2-3句话。"""
    # 调用教师模型生成描述
    description = teacher._generate_text(prompt)  # 需要 Teacher 类暴露生成方法
    return description

def describe_audio(audio_path, teacher):
    """使用 Whisper 转写音频，再让教师模型生成描述"""
    model = get_whisper()
    result = model.transcribe(str(audio_path), language="zh")
    transcript = result["text"].strip()
    if not transcript:
        transcript = "未检测到语音"
    prompt = f"""你是一个观察者，听到一段音频。音频中的内容如下：
{transcript}

请用中文简要描述这段音频的环境和声音特点（例如背景噪音、人声、动物声等），2-3句话。"""
    description = teacher._generate_text(prompt)
    return description

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界")
        return

    world_path = Path(current["path"])
    teacher = get_teacher()

    # 处理最新图片
    img_path = get_latest_image(world_path)
    if img_path:
        print(f"处理图片: {img_path.name}")
        desc = describe_image(img_path, teacher)
        if desc:
            timestamp = int(time.time())
            text_dir = world_path / "RAW" / "text"
            text_dir.mkdir(parents=True, exist_ok=True)
            filename = f"image_desc_{timestamp}.txt"
            with open(text_dir / filename, 'w', encoding='utf-8') as f:
                f.write(desc)
            print(f"图像描述已保存: {filename}\n{desc}")
    else:
        print("当前世界没有图片")

    # 处理最新音频
    audio_path = get_latest_audio(world_path)
    if audio_path:
        print(f"处理音频: {audio_path.name}")
        desc = describe_audio(audio_path, teacher)
        if desc:
            timestamp = int(time.time())
            text_dir = world_path / "RAW" / "text"
            text_dir.mkdir(parents=True, exist_ok=True)
            filename = f"audio_desc_{timestamp}.txt"
            with open(text_dir / filename, 'w', encoding='utf-8') as f:
                f.write(desc)
            print(f"音频描述已保存: {filename}\n{desc}")
    else:
        print("当前世界没有音频")

if __name__ == "__main__":
    main()