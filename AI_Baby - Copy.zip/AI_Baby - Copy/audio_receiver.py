#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
audio_receiver.py - 音频数据接收器（多世界版）
监听端口，接收树莓派发送的音频数据（WAV格式），
按时间戳保存到当前世界的 RAW/audio 目录。
"""

import socket
import os
import struct
from pathlib import Path
import threading

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
HOST = '0.0.0.0'
PORT = 8890
SAMPLE_RATE = 16000
CHANNELS = 1
SAMPLE_WIDTH = 2  # 16-bit

def recvall(sock, size):
    data = b''
    while len(data) < size:
        packet = sock.recv(size - len(data))
        if not packet:
            return None
        data += packet
    return data

def handle_client(conn, addr, audio_dir):
    print(f"音频客户端 {addr} 已连接")
    try:
        while True:
            # 接收文件名长度（4字节）
            name_len_data = recvall(conn, 4)
            if not name_len_data:
                break
            name_len = struct.unpack('>I', name_len_data)[0]
            # 接收文件名（忽略，使用自己的时间戳）
            filename = recvall(conn, name_len).decode()
            # 接收音频数据长度（4字节）
            data_len_data = recvall(conn, 4)
            if not data_len_data:
                break
            data_len = struct.unpack('>I', data_len_data)[0]
            # 接收音频数据
            audio_data = recvall(conn, data_len)
            if not audio_data:
                break

            # 生成时间戳文件名
            from datetime import datetime
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]
            out_filename = f"{timestamp}.wav"
            out_path = audio_dir / out_filename

            # 保存WAV文件（需要添加WAV头）
            import wave
            with wave.open(str(out_path), 'wb') as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(SAMPLE_WIDTH)
                wf.setframerate(SAMPLE_RATE)
                wf.writeframes(audio_data)
            print(f"已接收音频: {out_filename}")
            conn.send(b'OK')
    except Exception as e:
        print(f"连接异常: {e}")
    finally:
        conn.close()

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    audio_dir = world_path / "RAW" / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"音频接收器启动，监听 {HOST}:{PORT}")
    print(f"音频将保存到: {audio_dir}")

    try:
        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr, audio_dir))
            thread.daemon = True
            thread.start()
    except KeyboardInterrupt:
        print("音频接收器停止")
    finally:
        server.close()

if __name__ == '__main__':
    main()