#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
dht_receiver_robust.py - 温湿度数据接收器（多世界版）
接收树莓派发送的 DHT22 温湿度数据，保存为 CSV 文件到当前世界的 RAW/sensor 目录。

使用说明：
    python dht_receiver_robust.py [--port PORT] [--world world_id]

如果不指定 --world，则使用当前活动世界。
数据格式：温度,湿度（例如 23.5,60.2）
"""

import socket
import os
import csv
import logging
import argparse
from datetime import datetime
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ===================== 配置项 =====================
DEFAULT_PORT = 8889  # 温湿度传输端口
LOG_FILE = r"D:\AI_MEMORY\dht_receiver.log"  # 日志文件（可保持全局）
CSV_FILE_NAME = "dht22_data.csv"  # 数据保存为CSV文件
# ==================================================

def setup_logging():
    """初始化日志"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def get_csv_path(world_path):
    """获取当前世界下的 CSV 文件路径"""
    sensor_dir = world_path / "RAW" / "sensor"
    sensor_dir.mkdir(parents=True, exist_ok=True)
    return sensor_dir / CSV_FILE_NAME

def init_csv(csv_path):
    """初始化CSV文件（添加表头）"""
    if not csv_path.exists():
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["时间戳", "温度(°C)", "湿度(%)"])
        logging.info(f"📄 已创建CSV文件：{csv_path}")

def safe_save_dht_data(csv_path, temp, humi):
    """安全保存温湿度数据到CSV"""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(csv_path, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, temp, humi])
        return True
    except PermissionError:
        logging.error(f"❌ 没有权限写入CSV文件：{csv_path}")
        return False
    except Exception as e:
        logging.error(f"❌ 保存温湿度数据失败：{str(e)}")
        return False

def parse_dht_data(data_str):
    """解析温湿度数据（容错处理）"""
    try:
        temp_str, humi_str = data_str.split(',')
        temp = round(float(temp_str), 1)
        humi = round(float(humi_str), 1)
        
        # 数据合理性校验（DHT22范围：温度-40~80°C，湿度0~100%）
        if not (-40 <= temp <= 80) or not (0 <= humi <= 100):
            logging.warning(f"⚠️ 数据超出合理范围：温度={temp}°C，湿度={humi}%")
            return None, None
        return temp, humi
    except ValueError:
        logging.error(f"❌ 数据格式错误：{data_str}（预期格式：温度,湿度）")
        return None, None
    except Exception as e:
        logging.error(f"❌ 解析数据失败：{str(e)}")
        return None, None

def main():
    parser = argparse.ArgumentParser(description="温湿度数据接收器（多世界版）")
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help=f'监听端口，默认 {DEFAULT_PORT}')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    # 初始化日志
    setup_logging()

    # 获取目标世界
    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            logging.error(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            logging.error("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    csv_path = get_csv_path(world_path)
    init_csv(csv_path)

    logging.info(f"✅ 温湿度接收器初始化完成，目标世界: {current['world_id']} - {current['name']}")
    logging.info(f"📁 CSV文件路径: {csv_path}")

    # 创建TCP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        server_socket.bind(('0.0.0.0', args.port))
        server_socket.listen(5)
        logging.info(f"🔍 开始监听温湿度端口 {args.port}...")
        
        while True:
            try:
                conn, addr = server_socket.accept()
                logging.info(f"📡 接收到温湿度连接：{addr}")
                conn.settimeout(5)  # 5秒超时
                
                # 接收数据
                data = conn.recv(1024).decode('utf-8', errors='ignore').strip()
                if not data:
                    logging.warning(f"⚠️ {addr} 未发送任何数据")
                    conn.close()
                    continue
                
                # 解析并保存数据
                temp, humi = parse_dht_data(data)
                if temp is not None and humi is not None:
                    if safe_save_dht_data(csv_path, temp, humi):
                        logging.info(f"✅ 温湿度保存成功：{temp}°C, {humi}%")
                        conn.send(b'OK')
                    else:
                        conn.send(b'ER')
                else:
                    conn.send(b'ER')
                
            except socket.timeout:
                logging.warning(f"⚠️ 温湿度连接超时")
            except Exception as e:
                logging.error(f"❌ 处理温湿度连接出错：{str(e)}")
            finally:
                if 'conn' in locals():
                    conn.close()
    
    except PermissionError:
        logging.error(f"❌ 无权限监听端口 {args.port}")
    except OSError as e:
        logging.error(f"❌ 端口 {args.port} 已被占用：{str(e)}")
    except KeyboardInterrupt:
        logging.info("🛑 用户手动停止温湿度接收器")
    finally:
        server_socket.close()
        logging.info("✅ 温湿度接收器已关闭")

if __name__ == "__main__":
    main()