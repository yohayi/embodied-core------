import subprocess
import sys
import json
from pathlib import Path

# 获取已存在的世界名称（可选，避免重复创建同名世界）
def get_existing_world_names():
    try:
        result = subprocess.run(["python", "world_manager.py", "list"], capture_output=True, text=True, check=True)
        lines = result.stdout.split('\n')
        names = set()
        for line in lines:
            if "名称:" in line:
                name = line.split("名称:")[-1].strip()
                names.add(name)
        return names
    except:
        return set()

existing_names = get_existing_world_names()
print(f"已存在的世界名称: {existing_names}")

keywords = [
    "indoor", "city", "forest", "ocean", "mountain", "river", "lake", "desert", "grassland",
    "beach", "island", "volcano", "cave", "waterfall", "sunset", "sunrise", "night", "sky", "cloud",
    "rain", "snow", "storm", "wind", "fire", "earth", "space", "galaxy", "star", "moon",
    "plant", "flower", "tree", "grass", "leaf", "garden", "farm", "field", "forest", "jungle",
    "animal", "dog", "cat", "bird", "fish", "horse", "cow", "sheep", "lion", "tiger",
    "elephant", "monkey", "bear", "wolf", "fox", "rabbit", "deer", "insect", "butterfly", "dragonfly",
    "car", "truck", "bus", "train", "airplane", "boat", "ship", "bicycle", "motorcycle", "scooter",
    "road", "highway", "bridge", "tunnel", "building", "house", "apartment", "castle", "palace", "tower",
    "church", "temple", "mosque", "school", "hospital", "library", "museum", "theater", "cinema", "stadium",
    "park", "playground", "zoo", "aquarium", "market", "shop", "restaurant", "cafe", "bar", "hotel"
]

for kw in keywords:
    if kw in existing_names:
        print(f"⏭️ 世界 '{kw}' 已存在，跳过")
        continue
    print(f"\n=== 正在创建世界：{kw} ===")
    try:
        # 只创建空壳世界（设置 keyword 但不自动初始化）
        subprocess.run([
            "python", "world_manager.py", "create",
            "--name", kw,
            "--desc", f"自动创建的{kw}世界",
            "--keyword", kw,      # 只记录 keyword，不自动下载训练
            "--count", "30"       # count 在无 --auto 时无效，但可保留
        ], check=True, timeout=60)  # 创建空世界很快，60秒足够
        print(f"✅ 世界 {kw} 创建成功（空壳）")
    except subprocess.TimeoutExpired:
        print(f"⏰ 世界 {kw} 创建超时，继续下一个")
    except subprocess.CalledProcessError as e:
        print(f"❌ 世界 {kw} 创建失败，错误码 {e.returncode}，继续下一个")
    except Exception as e:
        print(f"❌ 世界 {kw} 发生未知异常: {e}，继续下一个")

print("\n🎉 批量创建完成！守护进程将自动为这些世界下载图片并训练。")