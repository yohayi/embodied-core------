#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train_sensor_ae.py - 传感器自编码器训练（多世界版，CPU 版）
从当前世界的 RAW/sensor 目录读取所有 JSON 传感器数据，
提取数值特征构建向量，训练全连接自编码器，
保存模型到 MODELS/，向量保存到 MODELS/per_sensor_vectors/。
"""

import os
import json
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import glob

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
LATENT_DIM = 32               # 传感器潜在向量维度
HIDDEN_DIM = 64               # 隐藏层维度
BATCH_SIZE = 128
EPOCHS = 50
LEARNING_RATE = 0.001
SAVE_MODEL_EVERY = 5

def sensor_json_to_vector(json_path):
    """从 JSON 文件提取数值特征，返回一维 numpy 数组"""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    # 提取所有数值字段（根据实际传感器配置调整）
    vec = []
    # IMU
    vec.extend([data['imu']['ax'], data['imu']['ay'], data['imu']['az'],
                data['imu']['gx'], data['imu']['gy'], data['imu']['gz']])
    # 环境
    vec.extend([data['environment']['temperature'],
                data['environment']['humidity'],
                data['environment']['pressure'],
                data['environment']['distance']])
    # 触觉
    vec.append(data['touch'])
    # 电池
    vec.append(data['battery'])
    return np.array(vec, dtype=np.float32)

class SensorDataset(Dataset):
    def __init__(self, sensor_dir):
        self.files = list(Path(sensor_dir).glob("*.json"))
        if not self.files:
            raise RuntimeError(f"在 {sensor_dir} 中没有找到 JSON 文件")
        # 预加载所有向量到内存（假设数据量不大，否则可改成惰性加载）
        self.vectors = []
        for f in self.files:
            try:
                vec = sensor_json_to_vector(f)
                self.vectors.append(vec)
            except Exception as e:
                print(f"警告：处理文件 {f} 时出错: {e}，已跳过")
        print(f"加载了 {len(self.vectors)} 条传感器数据，向量维度 {self.vectors[0].shape[0]}")

    def __len__(self):
        return len(self.vectors)

    def __getitem__(self, idx):
        return torch.tensor(self.vectors[idx], dtype=torch.float32)

class Autoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        recon = self.decoder(latent)
        return recon, latent

def main():
    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界，请先用 world_manager.py switch 切换")
        return

    world_path = Path(current["path"])
    sensor_dir = world_path / "RAW" / "sensor"
    model_dir = world_path / "MODELS"
    vector_dir = model_dir / "per_sensor_vectors"
    model_dir.mkdir(parents=True, exist_ok=True)
    vector_dir.mkdir(parents=True, exist_ok=True)

    if not sensor_dir.exists():
        print(f"错误：传感器数据目录不存在 {sensor_dir}")
        return

    # 加载数据
    dataset = SensorDataset(sensor_dir)
    if len(dataset) == 0:
        print("错误：没有有效传感器数据")
        return
    input_dim = dataset[0].shape[0]
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    # 初始化模型，强制使用 CPU
    device = torch.device('cpu')
    model = Autoencoder(input_dim, HIDDEN_DIM, LATENT_DIM).to(device)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()

    # 尝试加载已有模型（按世界内最新）
    model_files = sorted(model_dir.glob("sensor_ae_epoch_*.pth"))
    if model_files:
        latest = model_files[-1]
        model.load_state_dict(torch.load(latest, map_location='cpu'))
        print(f"已加载模型: {latest}")

    print(f"开始训练，设备 {device}，输入维度 {input_dim}，样本数 {len(dataset)}")
    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0
        for batch in dataloader:
            batch = batch.to(device)
            recon, latent = model(batch)
            loss = criterion(recon, batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(batch)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            model_path = model_dir / f"sensor_ae_epoch_{epoch}.pth"
            torch.save(model.state_dict(), model_path)
            print(f"模型已保存: {model_path}")

    # 保存所有传感器数据的潜在向量
    print("正在保存传感器向量...")
    model.eval()
    with torch.no_grad():
        for i, file in enumerate(dataset.files):
            vec = dataset.vectors[i]
            x = torch.tensor(vec, dtype=torch.float32).unsqueeze(0).to(device)
            _, latent = model(x)
            # 文件名与原 JSON 对应（使用时间戳部分）
            stem = file.stem  # 例如 20250315_143022_123_sensor
            # 移除最后的 _sensor 以保持与图像可能的一致
            if stem.endswith("_sensor"):
                stem = stem[:-7]
            vec_path = vector_dir / f"{stem}.npy"
            np.save(vec_path, latent.cpu().numpy().flatten())
    print(f"所有传感器向量已保存至 {vector_dir}")

if __name__ == "__main__":
    main()