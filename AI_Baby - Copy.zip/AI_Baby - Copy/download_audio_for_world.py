#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
download_audio_for_world.py - 为指定世界自动下载音频（Freesound API）
使用 Freesound API，需提前获取 API Key。
用法：
    python download_audio_for_world.py --world world_001 --keyword outdoor --count 10
"""

import os
import time
import requests
import argparse
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# ========== 配置 ==========
FREESOUND_API_KEY = "kBop56m5PqP3JnoUkxIjeGyFEYnpUyTwLZUBgP23"  # 任选一个可用密钥
FREESOUND_API_URL = "https://freesound.org/apiv2/search/text/"
# 速率限制：每小时最多 2000 次请求，约 1.8 秒/次
RATE_LIMIT_INTERVAL = 1.8  # 秒

_last_request_time = 0
_request_lock = __import__('threading').Lock()

def _rate_limited_sleep():
    """确保请求间隔不小于 RATE_LIMIT_INTERVAL 秒"""
    global _last_request_time
    with _request_lock:
        now = time.time()
        elapsed = now - _last_request_time
        if elapsed < RATE_LIMIT_INTERVAL:
            time.sleep(RATE_LIMIT_INTERVAL - elapsed)
        _last_request_time = time.time()

def download_freesound_audio(keyword, save_dir, count=10):
    """从 Freesound 下载关键词相关的音频"""
    os.makedirs(save_dir, exist_ok=True)
    params = {
        "query": keyword,
        "fields": "id,name,previews",
        "page_size": 30,
        "page": 1
    }
    headers = {"Authorization": f"Token {FREESOUND_API_KEY}"}
    downloaded = 0
    page = 1
    while downloaded < count:
        params["page"] = page
        _rate_limited_sleep()
        try:
            resp = requests.get(FREESOUND_API_URL, params=params, headers=headers, timeout=10)
            if resp.status_code != 200:
                print(f"请求失败，状态码 {resp.status_code}，等待后重试...")
                time.sleep(5)
                continue
            data = resp.json()
            results = data.get("results", [])
            if not results:
                print("没有更多音频了")
                break
            for item in results:
                if downloaded >= count:
                    break
                # 获取预览音频 URL（通常为低质量 mp3）
                previews = item.get("previews", {})
                audio_url = previews.get("preview-hq-mp3") or previews.get("preview-lq-mp3")
                if not audio_url:
                    continue
                # 下载音频
                _rate_limited_sleep()
                audio_data = requests.get(audio_url).content
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
                filename = f"{keyword}_{timestamp}.mp3"
                filepath = os.path.join(save_dir, filename)
                with open(filepath, 'wb') as f:
                    f.write(audio_data)
                print(f"下载 {filename}")
                downloaded += 1
            page += 1
        except Exception as e:
            print(f"下载出错: {e}")
            time.sleep(5)
    print(f"完成，共下载 {downloaded} 个音频到 {save_dir}")

def main():
    parser = argparse.ArgumentParser(description="为指定世界自动下载音频（Freesound）")
    parser.add_argument('--world', required=True, help='世界ID，如 world_001')
    parser.add_argument('--keyword', required=True, help='搜索关键词，如 outdoor')
    parser.add_argument('--count', type=int, default=10, help='下载数量，默认10')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    audio_dir = world_path / "RAW" / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)

    print(f"为世界 {args.world} 下载音频，关键词：{args.keyword}，数量：{args.count}")
    download_freesound_audio(args.keyword, str(audio_dir), args.count)

if __name__ == "__main__":
    main()