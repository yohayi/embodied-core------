#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train_audio_from_folder.py - 音频自编码器（PyTorch CPU 版）
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import cv2
import librosa
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
import shutil

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    exit(1)

# ========== 配置 ==========
SAMPLE_RATE = 16000
N_MELS = 128
TIME_STEPS = 64
IMG_SIZE = 64
LATENT_DIM = 128
BATCH_SIZE = 32
LEARNING_RATE = 0.001
EPOCHS = 50
SAVE_MODEL_EVERY = 5
GLOBAL_MODEL_DIR = Path(r"D:\AI_MEMORY\MODELS")

class AudioDataset(Dataset):
    def __init__(self, audio_dir):
        self.files = list(Path(audio_dir).glob("*.wav")) + list(Path(audio_dir).glob("*.mp3"))
        if not self.files:
            raise RuntimeError(f"在 {audio_dir} 中没有找到音频文件")
        self.features = []
        for f in self.files:
            try:
                feat = self._audio_to_spectrogram(f)
                if feat is not None:
                    self.features.append(feat)
            except Exception as e:
                print(f"跳过 {f}: {e}")

    def _audio_to_spectrogram(self, path):
        y, sr = librosa.load(path, sr=SAMPLE_RATE)
        mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=N_MELS)
        log_mel = librosa.power_to_db(mel, ref=np.max)
        if log_mel.shape[1] < TIME_STEPS:
            pad_width = TIME_STEPS - log_mel.shape[1]
            log_mel = np.pad(log_mel, ((0, 0), (0, pad_width)), mode='constant')
        else:
            log_mel = log_mel[:, :TIME_STEPS]
        log_mel = (log_mel - log_mel.min()) / (log_mel.max() - log_mel.min() + 1e-8)
        resized = cv2.resize(log_mel, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_LINEAR)
        return resized.flatten().astype(np.float32)

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        return torch.tensor(self.features[idx], dtype=torch.float32)

class AudioAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        recon = self.decoder(latent)
        return recon, latent

def load_latest_model(model, model_dir):
    model_files = sorted(model_dir.glob("audio_ae_epoch_*.pth"))
    if model_files:
        latest = model_files[-1]
        model.load_state_dict(torch.load(latest, map_location='cpu'))
        print(f"已加载模型: {latest.name}")
        return True
    global_models = list(GLOBAL_MODEL_DIR.glob("audio_ae_epoch_*.pth"))
    if global_models:
        latest_global = max(global_models, key=lambda p: int(p.stem.split('_')[-1]))
        print(f"从全局复制 {latest_global.name}")
        shutil.copy(latest_global, model_dir / latest_global.name)
        model.load_state_dict(torch.load(model_dir / latest_global.name, map_location='cpu'))
        return True
    print("未找到任何模型，随机初始化")
    return False

def main():
    # 强制使用 CPU
    device = torch.device('cpu')
    print(f"使用设备: {device}")

    wm = WorldManager()
    current = wm.get_current_world()
    if not current:
        print("错误：没有当前世界")
        return
    world_path = Path(current["path"])
    audio_dir = world_path / "RAW" / "audio"
    model_dir = world_path / "MODELS"
    vector_dir = model_dir / "per_audio_vectors"
    model_dir.mkdir(parents=True, exist_ok=True)
    vector_dir.mkdir(parents=True, exist_ok=True)

    if not audio_dir.exists():
        print(f"错误：音频目录不存在 {audio_dir}")
        return

    dataset = AudioDataset(audio_dir)
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)

    input_dim = IMG_SIZE * IMG_SIZE
    model = AudioAutoencoder(input_dim, 256, LATENT_DIM).to(device)
    load_latest_model(model, model_dir)

    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()

    print(f"开始训练，设备 {device}，样本数 {len(dataset)}")
    for epoch in range(1, EPOCHS+1):
        model.train()
        total_loss = 0
        for batch in dataloader:
            batch = batch.to(device)
            recon, latent = model(batch)
            loss = criterion(recon, batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(batch)

        avg_loss = total_loss / len(dataset)
        print(f"Epoch {epoch:3d} 平均损失: {avg_loss:.6f}")

        if epoch % SAVE_MODEL_EVERY == 0:
            torch.save(model.state_dict(), model_dir / f"audio_ae_epoch_{epoch}.pth")

    # 保存所有音频向量
    print("正在保存音频向量...")
    model.eval()
    with torch.no_grad():
        for i, f in enumerate(dataset.files):
            x = dataset[i].unsqueeze(0).to(device)
            _, latent = model(x)
            vec_path = vector_dir / (f.stem + ".npy")
            np.save(vec_path, latent.cpu().numpy().flatten())
    print("音频向量保存完成")

if __name__ == "__main__":
    main()