from huggingface_hub import snapshot_download
import os

# 设置镜像
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

# 下载模型到本地目录
snapshot_download(
    repo_id="Qwen/Qwen2.5-3B-Instruct",
    local_dir="D:/AI_MEMORY/models/Qwen2.5-3B-Instruct",
    local_dir_use_symlinks=False,
    resume_download=True,
    ignore_patterns=["*.h5", "*.ot", "*.msgpack"]  # 忽略一些不需要的文件
)
print("下载完成！")