#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
auto_learner.py - 持续学习守护进程
自动扫描各世界的新数据，达到阈值后触发训练流水线。

使用方式：
    python auto_learner.py [--interval 300] [--threshold 50]

参数：
    --interval   扫描间隔（秒），默认 300 秒（5分钟）
    --threshold  触发训练的最小新图片数量，默认 50
"""

import os
import time
import json
import argparse
import subprocess
import threading
from pathlib import Path
from datetime import datetime, timedelta
import logging

# 导入世界管理器
try:
    from world_manager import WorldManager, load_index
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("auto_learner.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# 各模态的训练流水线（脚本名称列表）
MODALITIES = {
    'image': {
        'train_script': 'train_from_processed.py',
        'cluster_script': 'cluster_image_concepts.py',
        'raw_dir': 'RAW/image',
        'processed_dir': 'PROCESSED/image',
        'vectors_dir': 'MODELS/per_image_vectors',
    },
    'audio': {
        'train_script': 'train_audio_from_folder.py',
        'cluster_script': 'cluster_audio.py',
        'raw_dir': 'RAW/audio',
        'processed_dir': 'PROCESSED/audio',   # 音频处理脚本可能直接生成向量，但保持结构一致
        'vectors_dir': 'MODELS/per_audio_vectors',
    },
    # 可按需添加其他模态
}

class AutoLearner:
    def __init__(self, scan_interval=300, threshold=50):
        self.scan_interval = scan_interval
        self.threshold = threshold
        self.wm = WorldManager()
        self.lock = threading.Lock()  # 用于防止并发训练
        self.running = True

    def get_all_worlds(self):
        """返回所有世界ID及其路径"""
        index = load_index()
        worlds = []
        for wid, info in index['worlds'].items():
            worlds.append({
                'id': wid,
                'path': Path(info['path']),
                'name': info['name']
            })
        return worlds

    def count_new_files(self, world_path, modality):
        """
        统计自上次处理后新增的文件数量。
        简单实现：比较目录中所有文件的修改时间与上次处理时间。
        更复杂可实现状态文件记录。
        """
        raw_dir = world_path / modality['raw_dir']
        if not raw_dir.exists():
            return 0

        # 获取该世界该模态的最后处理时间（从状态文件读取）
        last_time = self.get_last_processed(world_path, modality)
        count = 0
        for f in raw_dir.glob('*'):
            if f.is_file() and f.stat().st_mtime > last_time:
                count += 1
        return count

    def get_last_processed(self, world_path, modality):
        """读取或创建状态文件，返回上次处理的时间戳"""
        state_file = world_path / '.auto_learner_state.json'
        if state_file.exists():
            with open(state_file, 'r') as f:
                state = json.load(f)
            # 返回该模态的最后处理时间，若不存在则返回纪元时间
            return state.get(modality, 0.0)
        else:
            return 0.0

    def update_last_processed(self, world_path, modality, timestamp=None):
        """更新该模态的最后处理时间为当前时间"""
        state_file = world_path / '.auto_learner_state.json'
        state = {}
        if state_file.exists():
            with open(state_file, 'r') as f:
                state = json.load(f)
        state[modality] = timestamp or time.time()
        with open(state_file, 'w') as f:
            json.dump(state, f)

    def train_world_modality(self, world_id, modality_name, modality):
        """执行特定世界特定模态的训练流水线"""
        with self.lock:
            logging.info(f"开始训练世界 {world_id} 的 {modality_name} 模态")
            try:
                # 1. 切换到该世界
                subprocess.run(["python", "world_manager.py", "switch", world_id], check=True)

                # 2. 训练自编码器
                if modality['train_script']:
                    subprocess.run(["python", modality['train_script']], check=True)

                # 3. 聚类概念中心
                if modality['cluster_script']:
                    subprocess.run(["python", modality['cluster_script']], check=True)

                # 4. 更新世界分类器（全局）
                subprocess.run(["python", "world_classifier.py", "--update"], check=True)

                # 更新状态
                self.update_last_processed(Path(world_id).parent if not isinstance(world_id, Path) else world_id, modality_name)
                logging.info(f"世界 {world_id} 的 {modality_name} 模态训练完成")
            except subprocess.CalledProcessError as e:
                logging.error(f"训练世界 {world_id} 的 {modality_name} 时出错: {e}")

    def scan_and_train(self):
        """主扫描逻辑：遍历所有世界和模态，检查是否需要训练"""
        worlds = self.get_all_worlds()
        for world in worlds:
            for mod_name, mod_config in MODALITIES.items():
                new_count = self.count_new_files(world['path'], mod_config)
                if new_count >= self.threshold:
                    logging.info(f"世界 {world['id']} 的 {mod_name} 有新数据 {new_count} 条，达到阈值，触发训练")
                    self.train_world_modality(world['id'], mod_name, mod_config)
                else:
                    logging.debug(f"世界 {world['id']} 的 {mod_name} 新数据 {new_count} 条，未达阈值")

    def run(self):
        """主循环"""
        logging.info(f"自动学习守护进程启动，扫描间隔 {self.scan_interval} 秒，阈值 {self.threshold}")
        while self.running:
            try:
                self.scan_and_train()
            except Exception as e:
                logging.error(f"扫描过程中发生异常: {e}")
            time.sleep(self.scan_interval)

    def stop(self):
        self.running = False

def main():
    parser = argparse.ArgumentParser(description="自动学习守护进程")
    parser.add_argument('--interval', type=int, default=300, help='扫描间隔（秒），默认300秒')
    parser.add_argument('--threshold', type=int, default=50, help='触发训练的最小新数据量，默认50')
    args = parser.parse_args()

    learner = AutoLearner(scan_interval=args.interval, threshold=args.threshold)
    try:
        learner.run()
    except KeyboardInterrupt:
        logging.info("用户手动停止守护进程")
        learner.stop()

if __name__ == "__main__":
    main()