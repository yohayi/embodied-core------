import whisper
from pathlib import Path

# 强制使用 CPU
model = whisper.load_model("medium", device="cpu")  # 可改为 large 或 base

def transcribe_audio(audio_path, text_dir):
    result = model.transcribe(str(audio_path), language="zh")  # 指定语言或设为 None 自动检测
    text = result["text"]
    if text.strip():
        out_path = text_dir / (audio_path.stem + ".txt")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        return True
    return False

# 用法示例
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--world", required=True)
    parser.add_argument("--audio_dir", default="RAW/audio")
    args = parser.parse_args()
    from world_manager import WorldManager
    wm = WorldManager()
    wm.switch_world(args.world)
    world_path = Path(wm.get_current_world()["path"])
    audio_dir = world_path / args.audio_dir
    text_dir = world_path / "RAW" / "text"
    text_dir.mkdir(parents=True, exist_ok=True)
    for audio_file in audio_dir.glob("*.wav"):
        transcribe_audio(audio_file, text_dir)