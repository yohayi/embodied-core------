#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
多模态文档导入工具（EasyOCR + Whisper + LibreOffice + 视频支持）
- 图片、PDF、Word、音频、视频 → 提取文字
- 视频：提取关键帧 OCR + 音频转写
- 输出：文本文件保存到世界 RAW/text
"""

import argparse
import sys
import subprocess
import tempfile
import os
import warnings
from pathlib import Path
import numpy as np
from PIL import Image
from pdf2image import convert_from_path
import cv2

warnings.filterwarnings("ignore")

# 检查必要依赖
try:
    import easyocr
    import whisper
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请安装: pip install easyocr openai-whisper pdf2image pillow opencv-python")
    sys.exit(1)

# 可选依赖：PyMuPDF（用于直接提取文字型 PDF）
try:
    import fitz  # PyMuPDF
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False
    print("警告：PyMuPDF 未安装，将无法直接提取文字型 PDF 文本，请运行 'pip install pymupdf' 获得更好体验")

# ==================== 全局配置 ====================
TMP_DIR = Path("D:/AI_MEMORY/tmp")
TMP_DIR.mkdir(parents=True, exist_ok=True)

_easyocr_reader = None
_whisper = None

def get_easyocr():
    global _easyocr_reader
    if _easyocr_reader is None:
        print("加载 EasyOCR 模型（支持中英文）...")
        # 强制 CPU 模式
        _easyocr_reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)
    return _easyocr_reader

def get_whisper():
    global _whisper
    if _whisper is None:
        print("加载 Whisper medium 模型...")
        # 强制 CPU 模式
        _whisper = whisper.load_model("medium", device="cpu")
    return _whisper

def easyocr_recognize(image):
    reader = get_easyocr()
    img_np = np.array(image)
    result = reader.readtext(img_np, detail=0, paragraph=True)
    return "\n".join(result) if result else ""

def process_image(image):
    return easyocr_recognize(image)

def extract_text_from_pdf_direct(pdf_path):
    """使用 PyMuPDF 直接提取文字型 PDF 的文本内容"""
    if not PYMUPDF_AVAILABLE:
        return None
    try:
        doc = fitz.open(pdf_path)
        full_text = []
        for page_num, page in enumerate(doc, 1):
            text = page.get_text()
            if text.strip():
                full_text.append(f"## 第 {page_num} 页\n\n{text}\n")
        doc.close()
        if full_text:
            return "\n".join(full_text)
        else:
            return None
    except Exception as e:
        print(f"PyMuPDF 提取文本失败: {e}")
        return None

def process_pdf(pdf_path):
    print(f"处理 PDF: {pdf_path.name}")

    # 1. 尝试直接提取文本（如果 PyMuPDF 可用）
    direct_text = None
    if PYMUPDF_AVAILABLE:
        direct_text = extract_text_from_pdf_direct(pdf_path)
        if direct_text and len(direct_text) > 200:  # 如果提取的文本足够长，视为文字型 PDF
            print("  识别为文字型 PDF，直接保存文本")
            return direct_text
        elif direct_text:
            print("  提取的文本较短，可能为扫描版 PDF，将使用 OCR")
        else:
            print("  未提取到文本，使用 OCR")

    # 2. 回退到 OCR
    try:
        images = convert_from_path(pdf_path, dpi=200)
    except Exception as e:
        print(f"PDF 转图片失败: {e}")
        return None
    full_text = []
    for i, img in enumerate(images):
        print(f"  第 {i+1}/{len(images)} 页")
        page_text = process_image(img)
        if page_text:
            full_text.append(f"## 第 {i+1} 页\n\n{page_text}\n")
    return "\n".join(full_text)

def process_video(video_path):
    """处理视频：提取帧 OCR + 音频转写"""
    print(f"处理视频: {video_path.name}")
    # 1. 提取音频
    audio_temp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    audio_temp.close()
    audio_text = ""
    try:
        subprocess.run([
            "ffmpeg", "-i", str(video_path), "-q:a", "0", "-map", "a",
            audio_temp.name, "-y", "-loglevel", "error"
        ], check=True, timeout=30)
        # 转写音频
        model = get_whisper()
        audio_text = model.transcribe(audio_temp.name)["text"]
    except Exception as e:
        print(f"视频音频提取失败: {e}")
    finally:
        if os.path.exists(audio_temp.name):
            os.unlink(audio_temp.name)

    # 2. 提取关键帧并 OCR
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"无法打开视频: {video_path}")
        return None
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_interval = max(1, int(fps))  # 每秒一帧
    frame_count = 0
    ocr_texts = []
    reader = get_easyocr()
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_count % frame_interval == 0:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(frame_rgb)
            text = reader.readtext(np.array(pil_img), detail=0, paragraph=True)
            if text:
                ocr_texts.extend(text)
        frame_count += 1
        if frame_count > 1000:  # 防止过长视频，可调整
            break
    cap.release()
    ocr_text = "\n".join(ocr_texts)

    result = f"## 视频音频转写\n\n{audio_text}\n\n## 视频画面文字\n\n{ocr_text}"
    return result

def convert_word_to_pdf(word_path):
    try:
        subprocess.run(['soffice', '--version'], capture_output=True, check=True)
    except:
        print("错误：未找到 LibreOffice，请安装并添加到 PATH")
        return None
    out_dir = TMP_DIR / "word2pdf"
    out_dir.mkdir(exist_ok=True)
    try:
        subprocess.run([
            'soffice', '--headless', '--convert-to', 'pdf',
            '--outdir', str(out_dir), str(word_path)
        ], check=True, timeout=60)
        pdf_path = out_dir / (word_path.stem + '.pdf')
        return pdf_path if pdf_path.exists() else None
    except Exception as e:
        print(f"Word 转 PDF 失败: {e}")
        return None

def process_word(word_path):
    print(f"处理 Word: {word_path.name}")
    pdf = convert_word_to_pdf(word_path)
    if pdf:
        text = process_pdf(pdf)
        try:
            pdf.unlink()
        except:
            pass
        return text
    return None

def process_audio(audio_path):
    model = get_whisper()
    result = model.transcribe(str(audio_path))
    return result["text"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--world', required=True, help='世界ID')
    parser.add_argument('--input', required=True, help='文件或目录路径')
    args = parser.parse_args()

    from world_manager import WorldManager
    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    text_dir = world_path / "RAW" / "text"
    text_dir.mkdir(parents=True, exist_ok=True)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：路径不存在 {input_path}")
        return

    files = []
    if input_path.is_file():
        files = [input_path]
    else:
        # 支持的扩展名
        for ext in ['*.pdf', '*.docx', '*.doc', '*.jpg', '*.jpeg', '*.png', '*.bmp',
                    '*.wav', '*.mp3', '*.mp4', '*.avi', '*.mov']:
            files.extend(input_path.rglob(ext))

    print(f"找到 {len(files)} 个文件，开始处理...")
    for f in files:
        suffix = f.suffix.lower()
        try:
            if suffix == '.pdf':
                text = process_pdf(f)
            elif suffix in ('.docx', '.doc'):
                text = process_word(f)
            elif suffix in ('.jpg', '.jpeg', '.png', '.bmp'):
                img = Image.open(f)
                text = process_image(img)
            elif suffix in ('.wav', '.mp3'):
                text = process_audio(f)
            elif suffix in ('.mp4', '.avi', '.mov'):
                text = process_video(f)
            else:
                continue

            if text and text.strip():
                out_name = f.stem + '.txt'
                out_path = text_dir / out_name
                cnt = 1
                while out_path.exists():
                    out_path = text_dir / f"{f.stem}_{cnt}.txt"
                    cnt += 1
                with open(out_path, 'w', encoding='utf-8') as out:
                    out.write(text)
                print(f"已保存: {out_path}")
            else:
                print(f"未提取到文本: {f.name}")
        except Exception as e:
            print(f"处理 {f.name} 时出错: {e}")

    print("所有文件处理完成！")

if __name__ == "__main__":
    main()