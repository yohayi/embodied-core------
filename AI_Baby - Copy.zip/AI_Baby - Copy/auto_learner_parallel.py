#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
auto_learner_parallel.py - 并行持续学习守护进程（含教师模型）
自动监控各世界新数据，并发触发训练流水线，并定期为当前世界生成教师指导。

使用方式：
    python auto_learner_parallel.py [--interval 300] [--threshold 50] [--workers 4] [--teacher_interval 300]
"""

import os
import time
import json
import argparse
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import logging

try:
    from world_manager import WorldManager, load_index
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# 导入教师模块
try:
    from teacher_guide import Teacher
except ImportError:
    print("警告：无法导入 Teacher，教师指导功能将禁用")
    Teacher = None

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("auto_learner_parallel.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# 各模态的训练流水线（脚本名称列表）
MODALITIES = {
    'image': {
        'train_script': 'train_from_processed.py',
        'cluster_script': 'cluster_image_concepts.py',
        'raw_dir': 'RAW/image',
        'processed_dir': 'PROCESSED/image',
        'vectors_dir': 'MODELS/per_image_vectors',
    },
    'audio': {
        'train_script': 'train_audio_from_folder.py',
        'cluster_script': 'cluster_audio.py',
        'raw_dir': 'RAW/audio',
        'processed_dir': 'PROCESSED/audio',
        'vectors_dir': 'MODELS/per_audio_vectors',
    },
    'video': {
        'train_script': 'extract_video_features.py',
        'cluster_script': 'cluster_motion_concepts.py',
        'raw_dir': 'RAW/video',
        'processed_dir': 'PROCESSED/video',
        'vectors_dir': 'MODELS/per_video_vectors',
    },
    # 可按需添加其他模态，例如 'text': {...}
}

class ParallelAutoLearner:
    def __init__(self, scan_interval=300, threshold=50, max_workers=4, teacher_interval=300):
        self.scan_interval = scan_interval
        self.threshold = threshold
        self.max_workers = max_workers
        self.teacher_interval = teacher_interval
        self.wm = WorldManager()
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.running = True
        self.lock = threading.Lock()

        # 初始化教师模型（仅当 Teacher 可用时）
        if Teacher is not None:
            self.teacher = Teacher()
            self.teacher_thread = threading.Thread(target=self.teacher_loop)
            self.teacher_thread.daemon = True
            self.teacher_thread.start()
        else:
            self.teacher = None
            logging.warning("教师模型未加载，将不生成指导")

    def get_all_worlds(self):
        """返回所有世界ID及其路径"""
        index = load_index()
        worlds = []
        for wid, info in index['worlds'].items():
            worlds.append({
                'id': wid,
                'path': Path(info['path']),
                'name': info['name']
            })
        return worlds

    def count_new_files(self, world_path, modality_name, modality_config):
        """统计自上次处理后新增的文件数量"""
        raw_dir = world_path / modality_config['raw_dir']
        if not raw_dir.exists():
            return 0

        last_time = self.get_last_processed(world_path, modality_name)
        count = 0
        for f in raw_dir.iterdir():
            if f.is_file() and f.stat().st_mtime > last_time:
                count += 1
        return count

    def get_last_processed(self, world_path, modality_name):
        """读取或创建状态文件，返回上次处理的时间戳"""
        state_file = world_path / '.auto_learner_state.json'
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            return state.get(modality_name, 0.0)
        else:
            return 0.0

    def update_last_processed(self, world_path, modality_name, timestamp=None):
        """更新该模态的最后处理时间为当前时间"""
        state_file = world_path / '.auto_learner_state.json'
        state = {}
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
        state[modality_name] = timestamp or time.time()
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state, f)

    def train_world_modality(self, world_id, modality_name, modality_config):
        """执行特定世界特定模态的训练流水线（线程内运行）"""
        logging.info(f"[线程] 开始训练世界 {world_id} 的 {modality_name} 模态")
        try:
            # 1. 训练自编码器（直接使用 --world 参数）
            if modality_config['train_script']:
                subprocess.run(["python", modality_config['train_script'], "--world", world_id], check=True)

            # 2. 聚类概念中心
            if modality_config['cluster_script']:
                subprocess.run(["python", modality_config['cluster_script'], "--world", world_id], check=True)

            # 3. 更新世界分类器（需加全局锁，只能一个线程执行）
            with self.lock:
                subprocess.run(["python", "world_classifier.py", "--update"], check=True)

            # 更新状态
            world_path = Path(f"D:/AI_MEMORY/worlds/{world_id}")
            self.update_last_processed(world_path, modality_name)
            logging.info(f"[线程] 世界 {world_id} 的 {modality_name} 模态训练完成")
        except subprocess.CalledProcessError as e:
            logging.error(f"[线程] 训练世界 {world_id} 的 {modality_name} 时出错: {e}")

    def scan_and_train(self):
        """扫描所有世界，提交达到阈值的训练任务"""
        worlds = self.get_all_worlds()
        futures = []
        for world in worlds:
            for mod_name, mod_config in MODALITIES.items():
                new_count = self.count_new_files(world['path'], mod_name, mod_config)
                if new_count >= self.threshold:
                    logging.info(f"世界 {world['id']} 的 {mod_name} 有新数据 {new_count} 条，提交训练任务")
                    future = self.executor.submit(self.train_world_modality, world['id'], mod_name, mod_config)
                    futures.append(future)

        # 等待所有提交的任务完成
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                logging.error(f"训练任务异常: {e}")

    def teacher_loop(self):
        """定期为当前世界生成教师指导"""
        while self.running:
            try:
                current = self.wm.get_current_world()
                if current:
                    logging.info(f"为当前世界 {current['world_id']} 生成教师指导")
                    self.teacher.save_guide(current['world_id'])
                else:
                    logging.debug("没有当前世界，跳过教师指导")
            except Exception as e:
                logging.error(f"教师指导生成失败: {e}")
            time.sleep(self.teacher_interval)

    def run(self):
        """主循环（启动后立即扫描一次）"""
        logging.info(f"并行守护进程启动，扫描间隔 {self.scan_interval} 秒，阈值 {self.threshold}，并发数 {self.max_workers}")
        if self.teacher:
            logging.info(f"教师指导间隔 {self.teacher_interval} 秒")
        # 启动后立即执行一次扫描
        self.scan_and_train()
        while self.running:
            time.sleep(self.scan_interval)
            try:
                self.scan_and_train()
            except Exception as e:
                logging.error(f"扫描过程中发生异常: {e}")

    def stop(self):
        self.running = False
        self.executor.shutdown(wait=True)

def main():
    parser = argparse.ArgumentParser(description="并行自动学习守护进程（含教师）")
    parser.add_argument('--interval', type=int, default=300, help='扫描间隔（秒）')
    parser.add_argument('--threshold', type=int, default=50, help='触发训练的最小新数据量')
    parser.add_argument('--workers', type=int, default=4, help='并发工作线程数')
    parser.add_argument('--teacher_interval', type=int, default=300, help='教师指导生成间隔（秒）')
    args = parser.parse_args()

    learner = ParallelAutoLearner(
        scan_interval=args.interval,
        threshold=args.threshold,
        max_workers=args.workers,
        teacher_interval=args.teacher_interval
    )
    try:
        learner.run()
    except KeyboardInterrupt:
        logging.info("用户手动停止守护进程")
        learner.stop()

if __name__ == "__main__":
    main()