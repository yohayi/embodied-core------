import subprocess

for i in range(2, 101):  # 从 2 到 100
    world_id = f"world_{i:03d}"
    print(f"正在删除 {world_id}...")
    try:
        subprocess.run(
            ["python", "world_manager.py", "delete", world_id, "--force"],
            check=True,
            timeout=10
        )
        print(f"✅ 删除 {world_id} 成功")
    except Exception as e:
        print(f"❌ 删除 {world_id} 失败: {e}")