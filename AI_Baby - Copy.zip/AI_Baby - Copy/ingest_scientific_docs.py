#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ingest_scientific_docs.py - 使用 Nougat 将科学 PDF 转为 Markdown 文本，保存到世界 RAW/text 目录。
支持单个文件或目录批量处理。
"""

import argparse
import subprocess
import sys
import shutil
from pathlib import Path

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager")
    sys.exit(1)

def convert_pdf_to_markdown(pdf_path, tmp_dir):
    """
    调用 Nougat 将 PDF 转换为 Markdown 文件。
    返回生成的 .mmd 文件路径，失败返回 None。
    """
    try:
        # 确定 nougat 命令（优先使用系统路径中的 nougat，否则尝试 python -m nougat）
        nougat_cmd = shutil.which("nougat")
        if not nougat_cmd:
            # 尝试用 python -m nougat 运行
            nougat_cmd = [sys.executable, "-m", "nougat"]
        else:
            nougat_cmd = [nougat_cmd]

        # 调用 nougat 命令行，输出到临时目录
        result = subprocess.run(
            nougat_cmd + [str(pdf_path), "-o", str(tmp_dir)],
            capture_output=True,
            text=True,
            timeout=300  # 5分钟超时，可根据文档大小调整
        )
        if result.returncode != 0:
            print(f"错误：Nougat 处理 {pdf_path} 失败，返回码 {result.returncode}")
            print(f"stderr: {result.stderr}")
            return None

        # 查找生成的 .mmd 文件（Nougat 默认输出为 pdf_stem.mmd）
        out_file = tmp_dir / (pdf_path.stem + ".mmd")
        if out_file.exists():
            return out_file
        else:
            # 如果没找到，尝试搜索所有 .mmd
            mmd_files = list(tmp_dir.glob("*.mmd"))
            if mmd_files:
                return mmd_files[0]
            else:
                print(f"警告：未找到输出文件，PDF: {pdf_path}")
                return None
    except subprocess.TimeoutExpired:
        print(f"超时：处理 {pdf_path} 超过 5 分钟")
        return None
    except Exception as e:
        print(f"异常：{e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="使用 Nougat 将科学文档导入世界")
    parser.add_argument('--world', required=True, help='目标世界ID')
    parser.add_argument('--input', required=True, help='输入文件或目录（PDF）')
    parser.add_argument('--tmp', default='D:/AI_MEMORY/tmp', help='临时目录，用于存放中间文件')
    args = parser.parse_args()

    # 获取世界路径
    wm = WorldManager()
    if args.world not in wm.index["worlds"]:
        print(f"错误：世界 {args.world} 不存在")
        return
    world_path = Path(wm.index["worlds"][args.world]["path"])
    text_dir = world_path / "RAW" / "text"
    text_dir.mkdir(parents=True, exist_ok=True)

    # 创建临时目录
    tmp_dir = Path(args.tmp)
    tmp_dir.mkdir(parents=True, exist_ok=True)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：输入路径不存在 {input_path}")
        return

    # 收集所有 PDF 文件
    if input_path.is_file():
        pdf_files = [input_path] if input_path.suffix.lower() == '.pdf' else []
    else:
        pdf_files = list(input_path.rglob("*.pdf")) + list(input_path.rglob("*.PDF"))

    if not pdf_files:
        print(f"在 {input_path} 中未找到 PDF 文件")
        return

    print(f"找到 {len(pdf_files)} 个 PDF 文件，开始处理...")

    for pdf in pdf_files:
        print(f"处理: {pdf.name}")
        mmd_file = convert_pdf_to_markdown(pdf, tmp_dir)
        if mmd_file:
            # 读取生成的 Markdown 文本
            with open(mmd_file, 'r', encoding='utf-8') as f:
                content = f.read()
            if content.strip():
                # 保存到世界的 RAW/text 目录
                out_name = pdf.stem + '.txt'
                out_path = text_dir / out_name
                # 避免文件名冲突
                counter = 1
                while out_path.exists():
                    out_path = text_dir / f"{pdf.stem}_{counter}.txt"
                    counter += 1
                with open(out_path, 'w', encoding='utf-8') as f_out:
                    f_out.write(content)
                print(f"  已保存: {out_path}")
            else:
                print(f"  警告：转换后文本为空")
        else:
            print(f"  跳过 {pdf.name}")

    print("所有文档处理完成！")

if __name__ == "__main__":
    main()