import socket
import os

def send_image(file_path, host='127.0.0.1', port=8888):
    with open(file_path, 'rb') as f:
        img_data = f.read()
    filename = os.path.basename(file_path).encode()
    file_size = len(img_data)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        s.send(len(filename).to_bytes(4, 'big'))
        s.send(filename)
        s.send(file_size.to_bytes(4, 'big'))
        s.send(img_data)
        response = s.recv(1024)
        print('Response:', response)

send_image(r'D:\test.jpg')  # 替换为你的测试图片路径