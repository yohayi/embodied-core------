#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
hand_controller.py - 手部控制器（树莓派端）
监听端口，接收电脑发送的动作指令，驱动舵机/电机，
并可返回当前关节角度（如果有编码器）。
指令格式：MOTOR1:10, MOTOR2:-5 等，多个指令用逗号分隔。
"""

import socket
import time
import threading
import json
import RPi.GPIO as GPIO  # 如果真实硬件，需要安装RPi.GPIO；这里作为示例，实际使用时可根据硬件调整

# ========== 配置 ==========
HOST = '0.0.0.0'
PORT = 8891
NUM_MOTORS = 4  # 假设有4个电机/舵机
# 电机引脚定义（示例）
MOTOR_PINS = [17, 18, 22, 23]  # 根据实际连接修改

# 初始化GPIO（仅当真实硬件）
def init_gpio():
    GPIO.setmode(GPIO.BCM)
    for pin in MOTOR_PINS:
        GPIO.setup(pin, GPIO.OUT)
        # 如果是舵机，可能需要PWM，这里简化

def set_motor(motor_id, value):
    """控制电机，value 范围 -100 到 100，表示速度或角度"""
    # 实际硬件控制代码，这里用打印模拟
    print(f"电机 {motor_id} 设置为 {value}")
    # 示例：如果是直流电机，可通过PWM输出
    # pwm = GPIO.PWM(pin, 1000)
    # pwm.start(abs(value))
    # 方向控制需额外引脚

class HandController:
    def __init__(self):
        self.current_angles = [0] * NUM_MOTORS  # 当前关节角度（模拟）
        self.running = True

    def parse_command(self, cmd_str):
        """解析指令字符串，返回动作字典"""
        actions = {}
        parts = cmd_str.strip().split(',')
        for p in parts:
            if ':' in p:
                motor, val = p.split(':')
                try:
                    motor_id = int(motor.replace('MOTOR', '')) - 1  # 假设MOTOR1对应索引0
                    value = int(val)
                    if 0 <= motor_id < NUM_MOTORS:
                        actions[motor_id] = value
                except:
                    pass
        return actions

    def execute_actions(self, actions):
        """执行动作，更新关节角度（模拟）"""
        for mid, val in actions.items():
            set_motor(mid, val)
            self.current_angles[mid] = val  # 实际应从编码器读取，这里简单设为设定值

    def get_status(self):
        """返回当前状态（关节角度）"""
        return {"angles": self.current_angles}

    def handle_client(self, conn):
        try:
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                cmd = data.decode().strip()
                print(f"收到指令: {cmd}")
                if cmd.lower() == 'status':
                    # 返回状态
                    status = self.get_status()
                    conn.send(json.dumps(status).encode())
                else:
                    # 执行动作
                    actions = self.parse_command(cmd)
                    if actions:
                        self.execute_actions(actions)
                        conn.send(b"OK")
                    else:
                        conn.send(b"ERROR: invalid command")
        except Exception as e:
            print(f"处理客户端异常: {e}")
        finally:
            conn.close()

    def run(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        print(f"手部控制器启动，监听 {HOST}:{PORT}")
        try:
            while self.running:
                conn, addr = server.accept()
                print(f"客户端 {addr} 连接")
                thread = threading.Thread(target=self.handle_client, args=(conn,))
                thread.daemon = True
                thread.start()
        except KeyboardInterrupt:
            print("控制器停止")
        finally:
            server.close()
            if 'GPIO' in dir():
                GPIO.cleanup()

if __name__ == '__main__':
    # 如果有真实硬件，取消下面注释
    # init_gpio()
    controller = HandController()
    controller.run()