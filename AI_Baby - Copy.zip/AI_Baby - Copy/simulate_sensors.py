#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
simulate_sensors.py - 模拟传感器数据生成（多世界版）
生成符合物理规律的模拟传感器数据（IMU、温度、距离、触觉等），
以 JSON 格式保存到当前世界的 RAW/sensor/ 目录，文件名包含时间戳，与图像/音频对齐。
同时更新 latest_sensor.json 供教师模型实时读取。
"""

import os
import json
import time
import random
import math
import argparse
from pathlib import Path
from datetime import datetime

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

def generate_sensor_data(t):
    """根据时间 t 生成模拟传感器值，t 为 Unix 时间戳"""
    # IMU 加速度 (ax, ay, az) 单位 g，模拟静止但有微小振动
    ax = 0.1 * math.sin(2*math.pi*0.5*t) + random.gauss(0, 0.05)
    ay = 0.1 * math.cos(2*math.pi*0.5*t) + random.gauss(0, 0.05)
    az = 9.8 + 0.05 * math.sin(2*math.pi*1*t) + random.gauss(0, 0.02)

    # IMU 角速度 (gx, gy, gz) 单位 rad/s
    gx = 0.02 * math.sin(2*math.pi*0.2*t) + random.gauss(0, 0.01)
    gy = 0.02 * math.cos(2*math.pi*0.2*t) + random.gauss(0, 0.01)
    gz = 0.01 * math.sin(2*math.pi*0.3*t) + random.gauss(0, 0.005)

    # 环境传感器
    temperature = 25.0 + 5 * math.sin(2*math.pi*0.001*t) + random.gauss(0, 0.2)   # 缓慢日周期
    humidity = 60 + 10 * math.sin(2*math.pi*0.001*t + 1) + random.gauss(0, 1)
    pressure = 1013 + 2 * math.sin(2*math.pi*0.001*t + 2) + random.gauss(0, 0.5)

    # 距离传感器（模拟物体靠近/远离）
    distance = 100 + 50 * math.sin(2*math.pi*0.1*t) + random.gauss(0, 2)

    # 触觉传感器（大部分时间为0，偶尔触发）
    touch = 1.0 if random.random() < 0.01 else 0.0

    # 电池电压（缓慢下降）
    base_voltage = 12.0 - 0.0001 * t   # 放电速率 0.0001 V/s（约 8.64 V/天）
    battery_voltage = max(10.5, min(12.6, base_voltage + random.gauss(0, 0.05)))

    data = {
        "timestamp": t,
        "datetime": datetime.fromtimestamp(t).strftime("%Y%m%d_%H%M%S_%f")[:-3],
        "imu": {
            "ax": round(ax, 4),
            "ay": round(ay, 4),
            "az": round(az, 4),
            "gx": round(gx, 4),
            "gy": round(gy, 4),
            "gz": round(gz, 4)
        },
        "environment": {
            "temperature": round(temperature, 2),
            "humidity": round(humidity, 2),
            "pressure": round(pressure, 2),
            "distance": round(distance, 2)
        },
        "touch": round(touch, 2),
        "battery": round(battery_voltage, 3)
    }
    return data

def main():
    parser = argparse.ArgumentParser(description="模拟传感器数据生成器")
    parser.add_argument('--interval', type=float, default=0.1, help='数据生成间隔（秒），默认 0.1 秒 (10Hz)')
    parser.add_argument('--duration', type=int, default=None, help='运行时长（秒），默认无限运行')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    sensor_dir = world_path / "RAW" / "sensor"
    sensor_dir.mkdir(parents=True, exist_ok=True)

    print(f"开始生成模拟传感器数据，间隔 {args.interval} 秒，保存至 {sensor_dir}")
    print("按 Ctrl+C 停止")

    start_time = time.time()
    try:
        while True:
            t = time.time()
            data = generate_sensor_data(t)
            # 保存历史文件
            filename = f"{data['datetime']}_sensor.json"
            filepath = sensor_dir / filename
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"已保存: {filename}")

            # 更新最新状态文件
            latest_path = sensor_dir / "latest_sensor.json"
            with open(latest_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)

            time.sleep(args.interval)
            if args.duration and (time.time() - start_time) > args.duration:
                break
    except KeyboardInterrupt:
        print("停止生成")

if __name__ == "__main__":
    main()