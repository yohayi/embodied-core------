#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
batch_ocr.py - 批量 OCR 图片类书籍（使用 EasyOCR）
将图片或扫描版 PDF 中的文字提取为纯文本，保存到当前世界的 RAW/text 目录。
依赖：
    pip install easyocr pdf2image pillow
"""

import os
import argparse
from pathlib import Path
import easyocr
from pdf2image import convert_from_path
import numpy as np
import traceback

# 导入世界管理 API
try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# 初始化 EasyOCR（中英文，强制 CPU）
reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)

def ocr_image(image_path):
    """对单张图片进行 OCR，返回识别出的文本"""
    try:
        result = reader.readtext(image_path, detail=0, paragraph=True)
        return '\n'.join(result)
    except Exception as e:
        print(f"OCR 失败 {image_path}: {e}")
        traceback.print_exc()
        return ""

def process_pdf(pdf_path, output_dir, dpi=200):
    """处理 PDF 文件：将每一页转换为图片后 OCR，保存为一个文本文件"""
    print(f"正在处理 PDF: {pdf_path}")
    try:
        images = convert_from_path(pdf_path, dpi=dpi)
        full_text = []
        for i, img in enumerate(images):
            print(f"  处理第 {i+1}/{len(images)} 页...")
            # 将 PIL 图像转为 numpy 数组
            img_np = np.array(img)
            result = reader.readtext(img_np, detail=0, paragraph=True)
            page_text = '\n'.join(result)
            full_text.append(page_text)
        base_name = os.path.splitext(os.path.basename(pdf_path))[0]
        out_path = os.path.join(output_dir, base_name + '.txt')
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(full_text))
        print(f"  ✅ 已保存: {out_path}")
    except Exception as e:
        print(f"处理 PDF 失败 {pdf_path}: {e}")

def process_image_file(img_path, output_dir):
    """处理单个图片文件"""
    print(f"处理图片: {img_path}")
    text = ocr_image(img_path)
    if text.strip():
        base_name = os.path.splitext(os.path.basename(img_path))[0]
        out_path = os.path.join(output_dir, base_name + '.txt')
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(text)
        print(f"  ✅ 已保存: {out_path}")
    else:
        print(f"  ⚠️ 未识别出文字: {img_path}")

def main():
    parser = argparse.ArgumentParser(description="批量 OCR 图片类书籍 (EasyOCR)")
    parser.add_argument('--input', '-i', required=True, help='输入文件或目录（支持 PDF 或常见图片格式）')
    parser.add_argument('--dpi', type=int, default=200, help='PDF 转图片的 DPI（默认 200）')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请先用 world_manager.py switch 切换或指定 --world")
            return

    world_path = Path(current["path"])
    output_dir = world_path / "RAW" / "text"
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"输出目录: {output_dir}")

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误：输入路径不存在 {input_path}")
        return

    # 收集文件
    files_to_process = []
    if input_path.is_file():
        files_to_process.append(input_path)
    else:
        for ext in ['.pdf', '.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp']:
            files_to_process.extend(input_path.rglob(f'*{ext}'))
            files_to_process.extend(input_path.rglob(f'*{ext.upper()}'))

    print(f"找到 {len(files_to_process)} 个文件待处理")
    for file_path in files_to_process:
        if file_path.suffix.lower() == '.pdf':
            process_pdf(str(file_path), str(output_dir), args.dpi)
        else:
            process_image_file(str(file_path), str(output_dir))

    print("批量 OCR 处理完成！")

if __name__ == '__main__':
    main()