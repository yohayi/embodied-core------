#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
extract_video_pairs.py - 从视频提取同步图像帧和音频片段（多世界版）
支持单视频文件或整个目录。
"""

import os
import cv2
import librosa
import soundfile as sf
import numpy as np
import argparse
from pathlib import Path
from tqdm import tqdm

try:
    from world_manager import WorldManager
except ImportError:
    print("错误：无法导入 WorldManager，请确保 world_manager.py 在当前目录")
    exit(1)

# 配置参数
SAMPLE_RATE = 16000
AUDIO_SEGMENT_DURATION = 1.0
FPS_SAMPLING = 1
IMG_EXT = '.jpg'
AUDIO_EXT = '.wav'
DEFAULT_VIDEO_DIR = Path(r"D:\AI_MEMORY\RAW_VIDEOS")

def extract_frames_and_audio(video_path, output_dir,
                             fps_sampling=FPS_SAMPLING,
                             audio_duration=AUDIO_SEGMENT_DURATION,
                             sr=SAMPLE_RATE):
    """从单个视频提取帧和音频"""
    video_name = Path(video_path).stem
    out_subdir = Path(output_dir) / video_name
    out_subdir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"无法打开视频: {video_path}")
        return

    video_fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / video_fps

    try:
        audio, orig_sr = librosa.load(str(video_path), sr=None)
        if orig_sr != sr:
            audio = librosa.resample(audio, orig_sr=orig_sr, target_sr=sr)
    except Exception as e:
        print(f"音频提取失败 {video_path}: {e}")
        cap.release()
        return

    audio_len = len(audio)
    audio_time = audio_len / sr
    if abs(duration - audio_time) > 0.1:
        effective_duration = min(duration, audio_time)
    else:
        effective_duration = duration

    time_points = np.arange(0, effective_duration, 1.0/fps_sampling)
    frame_indices = (time_points * video_fps).astype(int)
    frame_indices = np.unique(frame_indices)
    frame_indices = frame_indices[frame_indices < total_frames]

    pbar = tqdm(total=len(frame_indices), desc=f"处理 {video_name}")
    for i, frame_idx in enumerate(frame_indices, start=1):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        if not ret:
            continue

        img_path = out_subdir / f"frame_{i:04d}{IMG_EXT}"
        cv2.imwrite(str(img_path), frame)

        time_sec = frame_idx / video_fps
        start_sample = int(time_sec * sr)
        end_sample = int((time_sec + audio_duration) * sr)
        if start_sample >= audio_len:
            continue
        if end_sample > audio_len:
            seg = audio[start_sample:]
            seg = np.pad(seg, (0, end_sample - audio_len), mode='constant')
        else:
            seg = audio[start_sample:end_sample]

        audio_path = out_subdir / f"audio_{i:04d}{AUDIO_EXT}"
        sf.write(str(audio_path), seg, sr)
        pbar.update(1)

    pbar.close()
    cap.release()
    print(f"完成: {video_name}，共提取 {len(frame_indices)} 对数据")

def main():
    parser = argparse.ArgumentParser(description="从视频提取同步图像帧和音频片段")
    parser.add_argument('--video', help='单个视频文件路径')
    parser.add_argument('--output', help='输出目录（与--video配合）')
    parser.add_argument('--video_dir', type=str, default=str(DEFAULT_VIDEO_DIR),
                        help='存放原始视频的文件夹')
    parser.add_argument('--world', help='指定世界ID（若不指定则使用当前世界）')
    args = parser.parse_args()

    if args.video:
        # 单视频模式
        if not Path(args.video).exists():
            print(f"错误：视频文件不存在 {args.video}")
            return
        output_dir = Path(args.output) if args.output else Path(args.video).parent / "extracted"
        extract_frames_and_audio(args.video, output_dir)
        return

    # 目录模式（原有逻辑）
    wm = WorldManager()
    if args.world:
        wm.switch_world(args.world)
        current = wm.get_current_world()
        if not current:
            print(f"错误：世界 {args.world} 不存在")
            return
    else:
        current = wm.get_current_world()
        if not current:
            print("错误：没有当前世界，请指定 --world 或先用 world_manager.py switch 切换")
            return

    world_path = Path(current["path"])
    output_dir = world_path / "SYNC_DATA"
    output_dir.mkdir(parents=True, exist_ok=True)

    video_dir = Path(args.video_dir)
    if not video_dir.exists():
        print(f"错误：视频目录不存在 {video_dir}")
        return

    video_exts = ('.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv')
    video_files = [f for f in video_dir.iterdir() if f.is_file() and f.suffix.lower() in video_exts]
    if not video_files:
        print(f"在 {video_dir} 中未找到视频文件")
        return

    print(f"找到 {len(video_files)} 个视频文件，开始处理...")
    for vfile in video_files:
        extract_frames_and_audio(vfile, output_dir)
    print("所有视频处理完毕！")

if __name__ == '__main__':
    main()